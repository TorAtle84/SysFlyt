
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
    console.log("Analyzing component positions vs polygon assignments...\n");

    const docId = "cmiy592ay02ehgnkdh40nrxve";

    // Get all components
    const components = await prisma.documentComponent.findMany({
        where: { documentId: docId },
        orderBy: { code: "asc" },
    });

    // Get all system polygons
    const polygons = await prisma.systemAnnotation.findMany({
        where: {
            documentId: docId,
            type: "SYSTEM",
            systemCode: { not: null }
        },
        select: {
            systemCode: true,
            pageNumber: true,
            points: true,
        },
    });

    console.log(`Found ${components.length} components and ${polygons.length} polygons\n`);

    // Show polygon bounds
    console.log("=== POLYGON BOUNDS ===");
    for (const p of polygons) {
        const points = (p.points as any[]) || [];
        if (points.length > 0) {
            const minX = Math.min(...points.map(pt => pt.x));
            const maxX = Math.max(...points.map(pt => pt.x));
            const minY = Math.min(...points.map(pt => pt.y));
            const maxY = Math.max(...points.map(pt => pt.y));
            console.log(`${p.systemCode}: X[${minX.toFixed(1)}-${maxX.toFixed(1)}] Y[${minY.toFixed(1)}-${maxY.toFixed(1)}]`);
        }
    }

    // Check specific components the user mentioned
    console.log("\n=== SPECIFIC COMPONENTS ===");
    const targetCodes = ["JVZ0025", "JVZ0026", "KAA0024", "KAA0025", "KAA0026", "LRA0042"];

    for (const code of targetCodes) {
        const comp = components.find(c => c.code === code);
        if (comp) {
            const centerX = (comp.x ?? 0) + ((comp.width ?? 0) / 2);
            const centerY = (comp.y ?? 0) + ((comp.height ?? 0) / 2);
            console.log(`${code}: pos(${centerX.toFixed(1)}, ${centerY.toFixed(1)}) -> system: ${comp.system || "NONE"}`);

            // Check which polygons this component is inside
            console.log(`  Polygon check:`);
            for (const p of polygons) {
                const points = (p.points as any[]) || [];
                if (points.length >= 3) {
                    const inside = pointInPolygon({ x: centerX, y: centerY }, points);
                    const minX = Math.min(...points.map(pt => pt.x));
                    const maxX = Math.max(...points.map(pt => pt.x));
                    const minY = Math.min(...points.map(pt => pt.y));
                    const maxY = Math.max(...points.map(pt => pt.y));
                    console.log(`    ${p.systemCode}: ${inside ? "INSIDE" : "outside"} (bounds: ${minX.toFixed(1)}-${maxX.toFixed(1)}, ${minY.toFixed(1)}-${maxY.toFixed(1)})`);
                }
            }
        } else {
            console.log(`${code}: NOT FOUND`);
        }
    }

    // Summary of all system assignments
    console.log("\n=== ALL SYSTEM ASSIGNMENTS ===");
    const bySys = new Map<string, string[]>();
    for (const c of components) {
        const sys = c.system || "NONE";
        if (!bySys.has(sys)) bySys.set(sys, []);
        bySys.get(sys)!.push(c.code);
    }
    for (const [sys, codes] of bySys) {
        console.log(`${sys} (${codes.length}): ${codes.slice(0, 5).join(", ")}${codes.length > 5 ? "..." : ""}`);
    }
}

function pointInPolygon(point: { x: number; y: number }, polygon: { x: number; y: number }[]): boolean {
    if (polygon.length < 3) return false;

    let inside = false;
    const n = polygon.length;

    for (let i = 0, j = n - 1; i < n; j = i++) {
        const xi = polygon[i].x;
        const yi = polygon[i].y;
        const xj = polygon[j].x;
        const yj = polygon[j].y;

        if (
            yi > point.y !== yj > point.y &&
            point.x < ((xj - xi) * (point.y - yi)) / (yj - yi) + xi
        ) {
            inside = !inside;
        }
    }

    return inside;
}

main()
    .catch((e) => {
        console.error("Error:", e);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
