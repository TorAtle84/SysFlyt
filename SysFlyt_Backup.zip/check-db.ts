
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

async function main() {
    console.log("Checking MassList systems...");
    const massListItems = await prisma.massList.findMany({
        take: 10,
        select: { system: true, tfm: true, projectId: true }
    });
    console.log("Sample MassList items:", massListItems);

    console.log("\nSearching for TFM containing '3601' or '3200'...");
    const specificItems = await prisma.massList.findMany({
        where: {
            OR: [
                { tfm: { contains: '3601' } },
                { tfm: { contains: '3200' } }
            ]
        },
        take: 5,
        select: { system: true, tfm: true }
    });
    console.log("Found specific items:", specificItems);

    const distinctSystems = await prisma.massList.groupBy({
        by: ['system'],
        _count: true,
    });
    console.log("Distinct Systems:", distinctSystems);

    console.log("\nChecking MC Protocols...");
    const protocols = await prisma.mCProtocol.findMany({
        include: { items: true }
    });
    console.log("Found Protocols:", protocols.length);
    if (protocols.length > 0) {
        console.log("First Protocol:", JSON.stringify(protocols[0], null, 2));
    }

    console.log("\nChecking System Tags...");
    const tags = await prisma.systemTag.findMany({ take: 10 });
    console.log("System Tags:", tags);
}

main()
    .catch(e => console.error(e))
    .finally(async () => {
        await prisma.$disconnect();
    });
