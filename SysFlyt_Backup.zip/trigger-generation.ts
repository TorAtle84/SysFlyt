
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function triggerGeneration() {
    const projectId = "cmix5xzut0001s5uo1tq2lrbx";
    const documentId = "cmiy592ay02ehgnkdh40nrxve";

    console.log(`Simulating POST /api/projects/${projectId}/mc-protocols`);

    // 1. Fetch components
    const docComponents = await prisma.documentComponent.findMany({
        where: {
            documentId,
            system: { not: null }
        }
    });

    console.log(`[SIM] Found ${docComponents.length} components with system`);

    if (docComponents.length === 0) {
        console.log("No components found.");
        return;
    }

    // 2. Group by System
    const componentsBySystem: Record<string, typeof docComponents> = {};
    docComponents.forEach(comp => {
        if (comp.system) {
            if (!componentsBySystem[comp.system]) {
                componentsBySystem[comp.system] = [];
            }
            componentsBySystem[comp.system].push(comp);
        }
    });

    console.log(`[SIM] grouped into ${Object.keys(componentsBySystem).length} systems`);

    let createdProtocols = 0;
    let createdItems = 0;

    // 3. Process each System
    for (const [systemCode, components] of Object.entries(componentsBySystem)) {
        console.log(`[SIM] Processing System ${systemCode} (${components.length} components)`);

        // Create/Get Protocol
        const protocol = await prisma.mCProtocol.upsert({
            where: {
                projectId_systemCode: {
                    projectId,
                    systemCode,
                },
            },
            update: {},
            create: {
                projectId,
                systemCode,
                systemName: `System ${systemCode}`,
                status: "IN_PROGRESS",
            },
        });

        console.log(`[SIM] Protocol ID: ${protocol.id}`);

        // Process Components
        for (const comp of components) {
            const tfmCode = `=${systemCode}-${comp.code}`;

            let massListItem = await prisma.massList.findFirst({
                where: {
                    projectId,
                    system: systemCode,
                    component: comp.code
                }
            });

            if (!massListItem) {
                console.log(`[SIM] Creating MassList item for ${tfmCode}`);
                massListItem = await prisma.massList.create({
                    data: {
                        projectId,
                        system: systemCode,
                        component: comp.code,
                        tfm: tfmCode,
                        description: `Generert fra PDF (DokID: ${documentId})`,
                    }
                });
            } else {
                console.log(`[SIM] Found MassList item ${massListItem.id} for ${tfmCode}`);
            }

            const existingItem = await prisma.mCProtocolItem.findUnique({
                where: {
                    protocolId_massListId: {
                        protocolId: protocol.id,
                        massListId: massListItem.id,
                    },
                },
            });

            if (!existingItem) {
                console.log(`[SIM] Creating Protocol Item linked to MassList ${massListItem.id}`);
                await prisma.mCProtocolItem.create({
                    data: {
                        protocolId: protocol.id,
                        massListId: massListItem.id,
                        columnA: "NOT_STARTED",
                        columnB: "NOT_STARTED",
                        columnC: "NOT_STARTED",
                    },
                });
                createdItems++;
            } else {
                console.log(`[SIM] Protocol Item already exists for ${massListItem.id}`);
            }
        }
    }

    console.log(`[SIM] Finished. Created ${createdItems} new items.`);
}

triggerGeneration()
    .catch(console.error)
    .finally(async () => {
        await prisma.$disconnect();
    });
