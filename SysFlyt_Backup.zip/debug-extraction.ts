
import { extractTextFromPDF } from "./src/lib/pdf-text-extractor";
import { readFile } from "fs/promises";
import path from "path";

async function main() {
    // Relative path from CWD (root)
    const filePath = "uploads/cmix5xzut0001s5uo1tq2lrbx/1765226058314_1764921562046_524-XXX-C-XX-70-360-009_Systemskjema_-_Ventilasjon_-_Klatrehall.pdf";
    console.log(`Reading PDF from ${filePath}...`);
    const buffer = await readFile(filePath);

    console.log("Extracting text...");
    try {
        const { items, text } = await extractTextFromPDF(buffer);
        console.log(`Success! Extracted ${items.length} items.`);
        if (items.length > 0) {
            console.log(`First item: ${JSON.stringify(items[0])}`);
        } else {
            console.log("Items array is empty.");
        }
    } catch (e) {
        console.error("Extraction failed:", e);
    }
}

main().catch(console.error);
