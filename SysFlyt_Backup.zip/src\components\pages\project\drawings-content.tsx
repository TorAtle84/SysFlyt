"use client";

import { useState } from "react";
import Link from "next/link";
import { format } from "date-fns";
import { nb } from "date-fns/locale";
import {
  FileText,
  Upload,
  Search,
  Eye,
  Tag,
  CheckCircle2,
  Box,
  Filter,
  Trash2,
  AlertCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { toast } from "sonner";

interface SystemAnnotation {
  id: string;
  systemCode?: string | null;
  createdBy?: { firstName: string; lastName: string } | null;
}

interface SystemTag {
  id: string;
  code: string;
  description?: string | null;
}

interface Document {
  id: string;
  title: string;
  url: string;
  createdAt: Date;
  systemAnnotations: SystemAnnotation[];
  tags: { systemTag: SystemTag }[];
  annotations?: { id: string; status: string }[];
}

interface DrawingsContentProps {
  project: { id: string; name: string };
  documents: Document[];
  systemTags: SystemTag[];
  canUpload: boolean;
}

export function DrawingsContent({
  project,
  documents,
  systemTags,
  canUpload,
}: DrawingsContentProps) {
  const [search, setSearch] = useState("");
  const [uploading, setUploading] = useState(false);
  const [selectedTag, setSelectedTag] = useState<string>("all");
  const [showTagDialog, setShowTagDialog] = useState(false);
  const [newTagCode, setNewTagCode] = useState("");
  const [newTagDescription, setNewTagDescription] = useState("");
  const [creatingTag, setCreatingTag] = useState(false);

  const allTags = [...new Set(documents.flatMap((doc) => doc.tags.map((t) => t.systemTag.code)))];

  const filteredDocuments = documents.filter((doc) => {
    const matchesSearch =
      doc.title.toLowerCase().includes(search.toLowerCase()) ||
      doc.tags.some((t) =>
        t.systemTag.code.toLowerCase().includes(search.toLowerCase())
      );

    const matchesTag =
      selectedTag === "all" ||
      doc.tags.some((t) => t.systemTag.code === selectedTag);

    return matchesSearch && matchesTag;
  });

  async function handleUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("title", file.name.replace(/\.[^/.]+$/, ""));
      formData.append("type", "DRAWING");

      const res = await fetch(`/api/projects/${project.id}/documents`, {
        method: "POST",
        body: formData,
      });

      if (res.ok) {
        window.location.reload();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
    }
  }

  async function handleCreateTag() {
    if (!newTagCode.trim()) return;

    setCreatingTag(true);
    try {
      const res = await fetch(`/api/system-tags`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          code: newTagCode.toUpperCase(),
          description: newTagDescription || null,
        }),
      });

      if (res.ok) {
        setNewTagCode("");
        setNewTagDescription("");
        setShowTagDialog(false);
        window.location.reload();
      }
    } catch (err) {
      console.error(err);
    } finally {
      setCreatingTag(false);
    }
  }

  async function handleDelete(docId: string) {
    if (!confirm("Er du sikker på at du vil slette denne tegningen?")) return;

    try {
      const res = await fetch(`/api/projects/${project.id}/documents/${docId}`, {
        method: "DELETE",
      });
      if (res.ok) {
        toast.success("Tegning slettet");
        window.location.reload();
      } else {
        toast.error("Kunne ikke slette tegning");
      }
    } catch (err) {
      console.error(err);
      toast.error("Feil ved sletting");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Arbeidstegninger</h1>
          <p className="text-muted-foreground">
            {documents.length} dokument{documents.length !== 1 ? "er" : ""}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {canUpload && (
            <>
              <Dialog open={showTagDialog} onOpenChange={setShowTagDialog}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="sm">
                    <Tag size={16} className="mr-2" />
                    Ny systemkode
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Opprett ny systemkode</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4 pt-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Systemkode</label>
                      <Input
                        placeholder="F.eks. 360, VVS, EL"
                        value={newTagCode}
                        onChange={(e) => setNewTagCode(e.target.value.toUpperCase())}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Beskrivelse (valgfritt)</label>
                      <Input
                        placeholder="F.eks. Ventilasjon, Sanitær, Elektro"
                        value={newTagDescription}
                        onChange={(e) => setNewTagDescription(e.target.value)}
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button variant="outline" onClick={() => setShowTagDialog(false)}>
                        Avbryt
                      </Button>
                      <Button onClick={handleCreateTag} disabled={creatingTag || !newTagCode.trim()}>
                        {creatingTag ? "Oppretter..." : "Opprett"}
                      </Button>
                    </div>
                  </div>
                </DialogContent>
              </Dialog>
              <input
                type="file"
                id="drawing-upload"
                accept=".pdf"
                className="hidden"
                onChange={handleUpload}
                disabled={uploading}
              />
              <Button
                type="button"
                disabled={uploading}
                onClick={() => document.getElementById("drawing-upload")?.click()}
              >
                <Upload size={16} className="mr-2" />
                {uploading ? "Laster opp..." : "Last opp"}
              </Button>
            </>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search
            size={16}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
          />
          <Input
            placeholder="Søk etter dokument eller systemkode..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={selectedTag} onValueChange={setSelectedTag}>
          <SelectTrigger className="w-full sm:w-48">
            <Filter size={16} className="mr-2" />
            <SelectValue placeholder="Alle systemer" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Alle systemer</SelectItem>
            {allTags.map((tag) => (
              <SelectItem key={tag} value={tag}>
                {tag}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {filteredDocuments.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12 text-center">
            <FileText size={48} className="mb-4 text-muted-foreground/50" />
            <h3 className="text-lg font-medium text-foreground">
              Ingen tegninger
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">
              {search || selectedTag !== "all"
                ? "Ingen tegninger matcher filteret"
                : "Last opp arbeidstegninger for å komme i gang"}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="rounded-md border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-[40%]">Dokument</TableHead>
                <TableHead>System</TableHead>
                <TableHead className="text-center">Rev</TableHead>
                <TableHead className="text-center">Boksing</TableHead>
                <TableHead className="text-center">Avvik</TableHead>
                <TableHead>Oppdatert</TableHead>
                <TableHead className="text-right">Handlinger</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredDocuments.map((doc) => {
                const totalBoxed = doc.systemAnnotations?.filter((a) => a.systemCode).length || 0;
                const openIssues = doc.annotations?.filter((a) => a.status === "OPEN").length || 0;
                const closedIssues = doc.annotations?.filter((a) => a.status === "CLOSED").length || 0;

                return (
                  <TableRow key={doc.id} className="group">
                    <TableCell>
                      <div className="space-y-1">
                        <Link
                          href={`/projects/${project.id}/documents/${doc.id}`}
                          className="font-medium hover:underline line-clamp-2"
                        >
                          {doc.title}
                        </Link>
                        <p className="text-xs text-muted-foreground truncate max-w-md">
                          {doc.url.split("/").pop()}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      {doc.tags.length > 0 ? (
                        <div className="flex flex-wrap gap-1">
                          {doc.tags.slice(0, 2).map((tag, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {tag.systemTag.code}
                            </Badge>
                          ))}
                          {doc.tags.length > 2 && (
                            <Badge variant="outline" className="text-xs">
                              +{doc.tags.length - 2}
                            </Badge>
                          )}
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      <Badge variant="secondary" className="text-xs">
                        1
                      </Badge>
                    </TableCell>
                    <TableCell className="text-center">
                      {totalBoxed > 0 ? (
                        <Badge variant="secondary" className="gap-1">
                          <Box size={12} />
                          {totalBoxed}
                        </Badge>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="text-center">
                      {openIssues > 0 ? (
                        <Badge variant="destructive" className="gap-1">
                          <AlertCircle size={12} />
                          {openIssues}
                        </Badge>
                      ) : (
                        <CheckCircle2 size={16} className="mx-auto text-green-500" />
                      )}
                    </TableCell>
                    <TableCell>
                      <span className="text-sm text-muted-foreground whitespace-nowrap">
                        {format(new Date(doc.createdAt), "d. MMM yyyy", { locale: nb })}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center justify-end gap-1">
                        <Link href={`/projects/${project.id}/documents/${doc.id}`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8" title="Vis">
                            <Eye size={16} />
                          </Button>
                        </Link>
                        <Link href={`/projects/${project.id}/documents/${doc.id}?mode=tag`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8" title="Tag">
                            <Tag size={16} />
                          </Button>
                        </Link>
                        <Link href={`/projects/${project.id}/documents/${doc.id}?mode=box`}>
                          <Button variant="ghost" size="icon" className="h-8 w-8" title="Boks">
                            <Box size={16} />
                          </Button>
                        </Link>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-8 w-8 text-destructive hover:text-destructive"
                          title="Slett"
                          onClick={() => handleDelete(doc.id)}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
