
import { PrismaClient } from "@prisma/client";
import { pointInPolygon } from "./src/lib/geometry-utils";

const prisma = new PrismaClient();

async function main() {
    const ann = await prisma.systemAnnotation.findFirst({
        where: {
            type: 'SYSTEM',
            systemCode: { not: null }
        },
        orderBy: { createdAt: 'desc' }
    });

    if (!ann) return;

    const comps = await prisma.documentComponent.findMany({
        where: { documentId: ann.documentId }
    });

    const validCoords = comps.filter(c => c.x !== null && c.y !== null && c.page !== null);
    console.log(`Total Components: ${comps.length}`);
    console.log(`Components with Valid Coords: ${validCoords.length}`);

    if (validCoords.length > 0) {
        console.log(`First Valid: Page=${validCoords[0].page} x=${validCoords[0].x?.toFixed(1)}`);
    }
}

main()
    .catch(console.error)
    .finally(() => prisma.$disconnect());
