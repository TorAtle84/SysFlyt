import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/db";
import { requireProjectAccess } from "@/lib/auth-helpers";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function GET(
    request: NextRequest,
    { params }: { params: Promise<{ projectId: string; protocolId: string; itemId: string }> }
) {
    try {
        const { projectId, itemId } = await params;

        const authResult = await requireProjectAccess(projectId);
        if (!authResult.success) {
            return authResult.error;
        }

        const comments = await prisma.mCItemComment.findMany({
            where: { itemId },
            include: {
                user: {
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true,
                        email: true, // For avatar/gravatar if needed
                    }
                }
            },
            orderBy: { createdAt: 'asc' }
        });

        return NextResponse.json({ comments });
    } catch (error) {
        console.error("Error fetching comments:", error);
        return NextResponse.json(
            { error: "Kunne ikke hente kommentarer" },
            { status: 500 }
        );
    }
}

export async function POST(
    request: NextRequest,
    { params }: { params: Promise<{ projectId: string; protocolId: string; itemId: string }> }
) {
    try {
        const { projectId, protocolId, itemId } = await params;
        const session = await getServerSession(authOptions);

        if (!session?.user?.id) {
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const authResult = await requireProjectAccess(projectId);
        if (!authResult.success) {
            return authResult.error;
        }

        const body = await request.json();
        const { content, mentions } = body;
        // mentions: array of userIds mentioned. We can handle notifications here.

        if (!content) {
            return NextResponse.json({ error: "Mangler innhold" }, { status: 400 });
        }

        // Create comment
        const comment = await prisma.mCItemComment.create({
            data: {
                content,
                itemId,
                userId: session.user.id
            },
            include: {
                user: {
                    select: {
                        id: true,
                        firstName: true,
                        lastName: true
                    }
                }
            }
        });

        // Handle Notifications
        if (Array.isArray(mentions) && mentions.length > 0) {
            // Filter out self-mentions
            const targets = mentions.filter(id => id !== session.user.id);

            if (targets.length > 0) {
                // Get Protocol System Code/Name for context
                const protocol = await prisma.mCProtocol.findUnique({
                    where: { id: protocolId },
                    select: { systemCode: true, systemName: true }
                });

                const systemInfo = protocol ? (protocol.systemName || protocol.systemCode) : "MC-protokoll";

                await prisma.notification.createMany({
                    data: targets.map(userId => ({
                        userId,
                        type: "MENTION", // Ensure this enum exists or use allowed type
                        metadata: {
                            message: `${session.user.firstName} ${session.user.lastName} nevnte deg i ${systemInfo}`,
                            link: `/projects/${projectId}/protocols/${protocolId}?item=${itemId}`
                        },
                        read: false
                    }))
                });
            }
        }

        return NextResponse.json({ comment });
    } catch (error) {
        console.error("Error creating comment:", error);
        return NextResponse.json(
            { error: "Kunne ikke lagre kommentar" },
            { status: 500 }
        );
    }
}
