
import { parseComponentIds, parseTFMCode, TFMComponents } from "../src/lib/id-pattern";

const testCases = [
    // Full TFM
    { input: "+100=360.001-RT001%EF", description: "Full TFM: Byggnr+System+Component+Type" },
    { input: "+200=5400.001-KA001", description: "Byggnr+System+Component (No Type)" },

    // System + Component
    { input: "=360.001-RT001", description: "System+Component (No Byggnr/Type)" },
    { input: "360.001-RT001", description: "System+Component (No prefixes)" },
    { input: "360.001 RT001", description: "System+Component (Space separator)" },

    // Variations
    { input: "=360.001:02-RT001", description: "System with version suffix" },
    { input: "360.001.002-RT001", description: "System with extra dots (should fail system regex probably, or match partial)" },

    // Standalone Components (Context test)
    { input: "RT001", description: "Standalone component" },

    // Invalid
    { input: "NOT_A_CODE", description: "Invalid code" },
];

console.log("Starting TFM Verification...\n");

testCases.forEach(({ input, description }) => {
    console.log(`--- Test: ${description} ---`);
    console.log(`Input: "${input}"`);

    // Test parseTFMCode
    const tfm = parseTFMCode(input);
    if (tfm) {
        console.log("parseTFMCode match:");
        console.log(JSON.stringify(tfm, null, 2));
    } else {
        console.log("parseTFMCode: No strict match");
    }

    // Test parseComponentIds (Context aware)
    const components = parseComponentIds(input);
    if (components.length > 0) {
        console.log(`parseComponentIds found ${components.length} components:`);
        components.forEach((c) => {
            console.log(JSON.stringify(c, null, 2));
        });
    } else {
        console.log("parseComponentIds: No components found");
    }
    console.log("\n");
});
