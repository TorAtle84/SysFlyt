
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const projectId = "cmix5xzut0001s5uo1tq2lrbx"; // From user's browser URL

async function main() {
    console.log("Connect to DB...");

    // 1. Find a document to delete (Systemskjema = SCHEMA)
    const doc = await prisma.document.findFirst({
        where: {
            projectId: projectId,
            type: "SCHEMA"
        },
        include: {
            _count: {
                select: {
                    annotations: true,
                    components: true,
                    tags: true,
                    systemAnnotations: true
                }
            }
        }
    });

    if (!doc) {
        console.log("No SCHEMA document found in project.");
        return;
    }

    console.log("Found document:", doc.id, doc.title);
    console.log("Relations count:", doc._count);

    console.log("Attempting to delete...");
    try {
        await prisma.document.delete({
            where: { id: doc.id }
        });
        console.log("Successfully deleted document!");
    } catch (e: any) {
        console.error("DELETE FAILED!");
        console.error("Error code:", e.code);
        console.error("Message:", e.message);
        console.error("Meta:", e.meta);
    }
}

main()
    .catch(e => console.error(e))
    .finally(() => prisma.$disconnect());
