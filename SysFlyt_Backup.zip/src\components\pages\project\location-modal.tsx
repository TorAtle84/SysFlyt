"use client"

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { FileText, Map, Box } from "lucide-react"

interface LinkedDoc {
    docId: string
    page: number
    x: number
    y: number
    docTitle: string
    docType: "DRAWING" | "SCHEMA" | "MASSLIST" | "OTHER"
}

interface LocationModalProps {
    open: boolean
    onOpenChange: (open: boolean) => void
    documents: LinkedDoc[]
    project: { id: string }
    componentName: string
}

export function LocationModal({ open, onOpenChange, documents, project, componentName }: LocationModalProps) {

    // Group by type
    const drawings = documents.filter(d => d.docType === "DRAWING")
    const schemas = documents.filter(d => d.docType === "SCHEMA")
    // Assuming "Model" is a future feature, we just show a placeholder or nothing for now?
    // User asked: "Modell: 'Kommer'"

    const handleOpen = (doc: LinkedDoc) => {
        // Use the correct route: /projects/[id]/documents/[docId]
        // Add query params for deep linking
        const url = `/projects/${project.id}/documents/${doc.docId}?page=${doc.page}&highlight=${componentName}` /* &x=${doc.x}&y=${doc.y} */
        window.open(url, '_blank')
        onOpenChange(false)
    }

    return (
        <Dialog open={open} onOpenChange={onOpenChange}>
            <DialogContent className="sm:max-w-[600px]">
                <DialogHeader>
                    <DialogTitle>Velg visning for {componentName}</DialogTitle>
                </DialogHeader>
                <div className="grid gap-4 py-4">

                    {/* Arbeidstegning */}
                    <div className="space-y-2">
                        <h4 className="font-medium text-sm flex items-center gap-2">
                            <Map size={16} /> Arbeidstegning
                        </h4>
                        {drawings.length > 0 ? (
                            <div className="grid gap-2">
                                {drawings.map((doc, i) => (
                                    <Button key={i} variant="outline" className="justify-start w-full text-left font-normal h-auto whitespace-normal break-words p-3 leading-normal" onClick={() => handleOpen(doc)}>
                                        {doc.docTitle}
                                    </Button>
                                ))}
                            </div>
                        ) : (
                            <p className="text-muted-foreground text-xs italic ml-6">Ingen tegninger funnet</p>
                        )}
                    </div>

                    {/* Systemskjema */}
                    <div className="space-y-2">
                        <h4 className="font-medium text-sm flex items-center gap-2">
                            <FileText size={16} /> Systemskjema
                        </h4>
                        {schemas.length > 0 ? (
                            <div className="grid gap-2">
                                {schemas.map((doc, i) => (
                                    <Button key={i} variant="outline" className="justify-start w-full text-left font-normal h-auto whitespace-normal break-words p-3 leading-normal" onClick={() => handleOpen(doc)}>
                                        {doc.docTitle}
                                    </Button>
                                ))}
                            </div>
                        ) : (
                            <p className="text-muted-foreground text-xs italic ml-6">Ingen skjema funnet</p>
                        )}
                    </div>

                    {/* Modell */}
                    <div className="space-y-2 opacity-50">
                        <h4 className="font-medium text-sm flex items-center gap-2">
                            <Box size={16} /> 3D Modell
                        </h4>
                        <p className="text-muted-foreground text-xs italic ml-6">Kommer snart...</p>
                    </div>

                </div>
            </DialogContent>
        </Dialog>
    )
}
