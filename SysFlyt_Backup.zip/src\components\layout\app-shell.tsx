"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import {
  LayoutDashboard,
  FolderKanban,
  User,
  Shield,
  LogOut,
  Menu,
  X,
  ChevronRight,
  ChevronLeft,
  PanelLeftClose,
  PanelLeftOpen,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { TotpWarningBanner } from "@/components/totp/totp-warning-banner";
import { ThemeToggle } from "@/components/ui/theme-toggle";
import { NotificationDropdown } from "@/components/layout/notification-dropdown";

interface TotpWarning {
  daysRemaining: number;
  deadline: string;
  expired: boolean;
  message: string;
}

interface AppShellProps {
  children: React.ReactNode;
  sidebar?: React.ReactNode;
}

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/profile", label: "Profil", icon: User },
];

const adminItems = [
  { href: "/admin/approvals", label: "Godkjenninger", icon: Shield },
];

export function AppShell({ children, sidebar }: AppShellProps) {
  const pathname = usePathname();
  const { data: session } = useSession();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [totpWarning, setTotpWarning] = useState<TotpWarning | null>(null);

  // Collapsible sidebar states with localStorage persistence
  const [leftSidebarCollapsed, setLeftSidebarCollapsed] = useState(false);
  const [secondarySidebarCollapsed, setSecondarySidebarCollapsed] = useState(false);

  const isAdmin = session?.user?.role === "ADMIN";

  // Load sidebar states from localStorage on mount
  useEffect(() => {
    const savedLeft = localStorage.getItem("leftSidebarCollapsed");
    const savedSecondary = localStorage.getItem("secondarySidebarCollapsed");
    if (savedLeft !== null) setLeftSidebarCollapsed(savedLeft === "true");
    if (savedSecondary !== null) setSecondarySidebarCollapsed(savedSecondary === "true");
  }, []);

  // Save sidebar states to localStorage when changed
  const toggleLeftSidebar = () => {
    const newState = !leftSidebarCollapsed;
    setLeftSidebarCollapsed(newState);
    localStorage.setItem("leftSidebarCollapsed", String(newState));
  };

  const toggleSecondarySidebar = () => {
    const newState = !secondarySidebarCollapsed;
    setSecondarySidebarCollapsed(newState);
    localStorage.setItem("secondarySidebarCollapsed", String(newState));
  };

  useEffect(() => {
    async function checkTotpStatus() {
      try {
        const res = await fetch("/api/totp/status");
        if (res.ok) {
          const data = await res.json();
          if (data.warning && !data.totpEnabled) {
            setTotpWarning(data.warning);
          }
        }
      } catch (error) {
        console.error("Failed to check TOTP status:", error);
      }
    }

    if (session?.user) {
      checkTotpStatus();
    }
  }, [session?.user]);

  useEffect(() => {
    if (mobileMenuOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [mobileMenuOpen]);

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setMobileMenuOpen(false);
      }
    };
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  return (
    <div className="flex min-h-screen bg-background">
      <button
        type="button"
        className="fixed left-4 top-4 z-50 flex h-11 w-11 items-center justify-center rounded-lg bg-card shadow-lg lg:hidden touch-manipulation"
        onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        aria-label={mobileMenuOpen ? "Lukk meny" : "Åpne meny"}
        aria-expanded={mobileMenuOpen}
      >
        {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
      </button>

      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-40 flex flex-col border-r border-border bg-card transition-all duration-300 ease-in-out",
          "pb-[env(safe-area-inset-bottom)]",
          // Desktop: show based on collapse state
          leftSidebarCollapsed ? "lg:w-16 overflow-hidden" : "lg:w-64",
          // Mobile: full width or hidden
          "w-[280px] sm:w-64",
          mobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className={cn(
          "flex h-16 items-center border-b border-border transition-all",
          leftSidebarCollapsed ? "justify-center px-2" : "justify-between px-6"
        )}>
          <Link href="/dashboard" className="flex items-center gap-2">
            {leftSidebarCollapsed ? (
              <LayoutDashboard size={24} className="text-foreground" />
            ) : (
              <span className="text-xl font-bold text-foreground">SysLink</span>
            )}
          </Link>
          {!leftSidebarCollapsed && (
            <div className="flex items-center gap-2">
              <NotificationDropdown />
              <ThemeToggle />
            </div>
          )}
        </div>

        <nav className={cn(
          "flex-1 space-y-1 overflow-y-auto transition-all",
          leftSidebarCollapsed ? "p-2" : "p-4"
        )}>
          {navItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <Link
                key={item.href}
                href={item.href}
                className={cn(
                  "flex min-h-[44px] items-center rounded-lg text-sm font-medium transition-colors touch-manipulation",
                  leftSidebarCollapsed ? "justify-center px-2 py-2" : "gap-3 px-3 py-2",
                  isActive
                    ? "bg-primary/10 text-primary"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground active:bg-muted/80"
                )}
                onClick={() => setMobileMenuOpen(false)}
                title={leftSidebarCollapsed ? item.label : undefined}
              >
                <item.icon size={20} />
                {!leftSidebarCollapsed && item.label}
              </Link>
            );
          })}

          {isAdmin && (
            <>
              <div className="my-4 border-t border-border" />
              {!leftSidebarCollapsed && (
                <p className="mb-2 px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                  Admin
                </p>
              )}
              {adminItems.map((item) => {
                const isActive = pathname === item.href;
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={cn(
                      "flex min-h-[44px] items-center rounded-lg text-sm font-medium transition-colors touch-manipulation",
                      leftSidebarCollapsed ? "justify-center px-2 py-2" : "gap-3 px-3 py-2",
                      isActive
                        ? "bg-primary/10 text-primary"
                        : "text-muted-foreground hover:bg-muted hover:text-foreground active:bg-muted/80"
                    )}
                    onClick={() => setMobileMenuOpen(false)}
                    title={leftSidebarCollapsed ? item.label : undefined}
                  >
                    <item.icon size={20} />
                    {!leftSidebarCollapsed && item.label}
                  </Link>
                );
              })}
            </>
          )}
        </nav>

        <div className={cn(
          "border-t border-border transition-all",
          leftSidebarCollapsed ? "p-2" : "p-4"
        )}>
          {!leftSidebarCollapsed && (
            <div className="mb-3 rounded-lg bg-muted/50 px-3 py-2">
              <p className="text-sm font-medium text-foreground truncate">
                {session?.user?.email}
              </p>
              <p className="text-xs text-muted-foreground">
                {session?.user?.role}
              </p>
            </div>
          )}
          <Button
            type="button"
            variant="ghost"
            className={cn(
              "min-h-[44px] text-muted-foreground hover:text-foreground touch-manipulation",
              leftSidebarCollapsed ? "w-full justify-center p-2" : "w-full justify-start gap-2"
            )}
            onClick={() => signOut({ callbackUrl: "/login" })}
            title={leftSidebarCollapsed ? "Logg ut" : undefined}
          >
            <LogOut size={20} />
            {!leftSidebarCollapsed && "Logg ut"}
          </Button>
        </div>
      </aside>

      {/* Left sidebar toggle - ALWAYS visible, positioned at right edge of sidebar */}
      <button
        type="button"
        onClick={toggleLeftSidebar}
        className={cn(
          "fixed top-0 bottom-0 z-50 hidden lg:flex w-4 items-center justify-center",
          "hover:bg-muted/30 transition-all duration-300 group",
          leftSidebarCollapsed ? "left-16" : "left-64"
        )}
        aria-label={leftSidebarCollapsed ? "Utvid meny" : "Skjul meny"}
      >
        <div className="flex flex-col items-center opacity-60 group-hover:opacity-100 transition-opacity">
          <ChevronRight size={14} strokeWidth={3} className={cn(
            "text-orange-500 transition-transform duration-200",
            leftSidebarCollapsed ? "" : "rotate-180"
          )} />
          <ChevronRight size={14} strokeWidth={3} className={cn(
            "text-orange-500 transition-transform duration-200 -mt-2",
            leftSidebarCollapsed ? "" : "rotate-180"
          )} />
        </div>
      </button>

      <div className={cn(
        "flex flex-1 transition-all duration-300",
        leftSidebarCollapsed ? "lg:pl-16" : "lg:pl-64"
      )}>
        {sidebar && (
          <aside className={cn(
            "fixed inset-y-0 hidden shrink-0 border-r border-border bg-card/50 lg:block transition-all duration-300",
            leftSidebarCollapsed ? "left-16" : "left-64",
            secondarySidebarCollapsed ? "w-16 overflow-hidden" : "w-72 overflow-y-auto"
          )}>
            <div>
              {sidebar}
            </div>
          </aside>
        )}

        {/* Secondary sidebar toggle - ALWAYS visible, positioned correctly */}
        {sidebar && (
          <button
            type="button"
            onClick={toggleSecondarySidebar}
            className={cn(
              "fixed top-0 bottom-0 z-40 hidden lg:flex w-4 items-center justify-center",
              "hover:bg-muted/30 transition-all duration-300 group",
              // Position based on both sidebars' collapsed states
              // Left sidebar: 16 or 64. Secondary sidebar: 16 (collapsed) or 288 (expanded)
              leftSidebarCollapsed
                ? (secondarySidebarCollapsed ? "left-[128px]" : "left-[352px]")  // 16 + 16 + toggle or 16 + 288 + toggle
                : (secondarySidebarCollapsed ? "left-[320px]" : "left-[544px]")  // 64 + 16 + toggle or 64 + 288 + toggle
            )}
            aria-label={secondarySidebarCollapsed ? "Utvid meny" : "Skjul meny"}
          >
            <div className="flex flex-col items-center opacity-60 group-hover:opacity-100 transition-opacity">
              <ChevronRight size={14} strokeWidth={3} className={cn(
                "text-orange-500 transition-transform duration-200",
                secondarySidebarCollapsed ? "" : "rotate-180"
              )} />
              <ChevronRight size={14} strokeWidth={3} className={cn(
                "text-orange-500 transition-transform duration-200 -mt-2",
                secondarySidebarCollapsed ? "" : "rotate-180"
              )} />
            </div>
          </button>
        )}

        <main className={cn(
          "flex-1 p-4 pt-16 sm:p-6 sm:pt-6 lg:pt-6 transition-all duration-300",
          sidebar ? (secondarySidebarCollapsed ? "lg:pl-16" : "lg:pl-72") : "",
          totpWarning && totpWarning.daysRemaining >= 0 ? "pb-32" : ""
        )}>
          <div className="mx-auto max-w-6xl">
            {children}
          </div>
        </main>
      </div>

      {totpWarning && totpWarning.daysRemaining >= 0 && (
        <TotpWarningBanner
          daysRemaining={totpWarning.daysRemaining}
          onDismiss={() => setTotpWarning(null)}
        />
      )}

      {mobileMenuOpen && (
        <div
          className="fixed inset-0 z-30 bg-black/50 lg:hidden touch-manipulation"
          onClick={() => setMobileMenuOpen(false)}
          aria-hidden="true"
        />
      )}
    </div>
  );
}
