
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
    console.log("Connecting to database...");

    // Check ALL components for the specific document
    const docId = "cmiy592ay02ehgnkdh40nrxve";

    const allComps = await prisma.documentComponent.findMany({
        where: { documentId: docId },
    });

    console.log(`Total components for doc ${docId}: ${allComps.length}`);

    const withPage1 = allComps.filter(c => c.page === 1);
    console.log(`Components with page=1: ${withPage1.length}`);

    const withCoords = allComps.filter(c => c.x !== null && c.y !== null);
    console.log(`Components with valid coords: ${withCoords.length}`);

    console.log("\nFirst 5 components:");
    for (const c of allComps.slice(0, 5)) {
        console.log(`  ${c.code}: x=${c.x}, y=${c.y}, page=${c.page}`);
    }

    // Find the RTD0011 specifically
    const rtd = allComps.find(c => c.code === "RTD0011");
    if (rtd) {
        console.log("\nRTD0011 specifically:", JSON.stringify(rtd, null, 2));
    } else {
        console.log("\nRTD0011 NOT FOUND");
    }
}

main()
    .catch((e) => {
        console.error("Error running script:", e);
    })
    .finally(async () => {
        await prisma.$disconnect();
    });
