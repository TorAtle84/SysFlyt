import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/db";
import { requireProjectAccess } from "@/lib/auth-helpers";

export async function GET(
    request: NextRequest,
    {
        params,
    }: {
        params: Promise<{
            projectId: string;
            protocolId: string;
        }>;
    }
) {
    try {
        const { projectId, protocolId } = await params;

        const authResult = await requireProjectAccess(projectId);
        if (!authResult.success) {
            return authResult.error;
        }

        const protocol = await prisma.mCProtocol.findUnique({
            where: { id: protocolId },
            include: {
                documents: true, // System documents
                items: {
                    orderBy: [
                        { massList: { system: "asc" } },
                        { massList: { component: "asc" } },
                    ],
                    include: {
                        massList: true, // Component info
                        responsible: {
                            select: { id: true, firstName: true, lastName: true },
                        },
                        executor: {
                            select: { id: true, firstName: true, lastName: true },
                        },
                        product: {
                            include: {
                                supplier: true,
                                datasheets: true,
                            },
                        },
                        photos: true,
                    },
                },
            },
        });

        if (!protocol) {
            return NextResponse.json({ error: "Protokoll ikke funnet" }, { status: 404 });
        }

        return NextResponse.json({ protocol });
    } catch (error) {
        console.error("Error fetching protocol:", error);
        return NextResponse.json(
            { error: "Kunne ikke hente protokoll" },
            { status: 500 }
        );
    }
}

export async function PUT(
    request: NextRequest,
    {
        params,
    }: {
        params: Promise<{
            projectId: string;
            protocolId: string;
        }>;
    }
) {
    try {
        const { projectId, protocolId } = await params;

        const authResult = await requireProjectAccess(projectId);
        if (!authResult.success) {
            return authResult.error;
        }

        const body = await request.json();
        const { systemOwnerId, status } = body;

        const updatedProtocol = await prisma.mCProtocol.update({
            where: { id: protocolId },
            data: {
                systemOwnerId: systemOwnerId,
                status: status,
            },
        });

        return NextResponse.json({ protocol: updatedProtocol });
    } catch (error) {
        console.error("Error updating protocol:", error);
        return NextResponse.json(
            { error: "Kunne ikke oppdatere protokoll" },
            { status: 500 }
        );
    }
}

export async function DELETE(
    request: NextRequest,
    {
        params,
    }: {
        params: Promise<{
            projectId: string;
            protocolId: string;
        }>;
    }
) {
    try {
        const { projectId, protocolId } = await params;

        const authResult = await requireProjectAccess(projectId);
        if (!authResult.success) {
            return authResult.error;
        }

        await prisma.mCProtocol.delete({
            where: { id: protocolId },
        });

        return NextResponse.json({ message: "Protokoll slettet" });
    } catch (error) {
        console.error("Error deleting protocol:", error);
        return NextResponse.json(
            { error: "Kunne ikke slette protokoll" },
            { status: 500 }
        );
    }
}
