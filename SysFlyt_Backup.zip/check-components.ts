
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function checkComponents() {
    const documentId = "cmiy592ay02ehgnkdh40nrxve"; // From logs
    console.log(`Checking components for document: ${documentId}`);

    const components = await prisma.documentComponent.findMany({
        where: { documentId },
    });

    console.log(`Total components found: ${components.length}`);

    const withSystem = components.filter(c => c.system !== null);
    console.log(`Components with system assigned: ${withSystem.length}`);

    if (withSystem.length > 0) {
        console.log("Sample component with system:", withSystem[0]);
    } else {
        console.log("No components have system assigned.");
    }

    const doc = await prisma.document.findUnique({ where: { id: documentId } });
    if (doc) {
        console.log(`Document belongs to project: ${doc.projectId}`);
        const protocols = await prisma.mCProtocol.findMany({
            where: { projectId: doc.projectId },
            include: { items: true }
        });
        console.log(`MC Protocols count: ${protocols.length}`);

        for (const p of protocols) {
            console.log(`Protocol: ${p.systemCode} (ID: ${p.id}) - Items: ${p.items.length}`);
            if (p.items.length > 0) {
                console.log("Sample Item:", p.items[0]);
            } else {
                console.log("  [EMPTY PROTOCOL]");
            }
        }

        // Check MassList for RTD0011
        console.log("Checking MassList matches for 'RTD0011'...");
        const exactMass = await prisma.massList.findMany({
            where: { projectId: doc.projectId, component: "RTD0011" }
        });
        console.log("MassList matches:", exactMass);
    }
}

checkComponents()
    .catch(console.error)
    .finally(async () => {
        await prisma.$disconnect();
    });
