
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const email = "flytlink.app@gmail.com";

async function main() {
    const user = await prisma.user.findUnique({
        where: { email }
    });

    if (!user) {
        console.log(`User ${email} NOT FOUND.`);
    } else {
        console.log(`User found: ${user.email}`);
        console.log(`Role: ${user.role}`);
        console.log(`Status: ${user.status}`);
    }
}

main()
    .catch(e => console.error(e))
    .finally(() => prisma.$disconnect());
