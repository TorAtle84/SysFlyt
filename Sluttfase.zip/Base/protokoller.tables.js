// Fil: app/static/js/protokoller.tables.js

// ============================================================================ 
// PROTOKOLLER • TABLES (Komplett, med korrekt system-parser og konsistent visning)
// ============================================================================ 

import {
  showMessage, addAutoHeightListeners, autosizeNow, autosizeAll,
  applyColorCoding, STATUS_COLORS, INTEGRERT_TEST_COLORS,
  td, tdText, dropdown,
  ALL_GROUPED_COMPONENTS, ALL_IDENTIFIED_SYSTEMS, SELECTED_SYSTEM_NUMBERS,
  FUNKSJONSBANK
} from "./protokoller.core.js";

const bootstrap = window.bootstrap; // Access Bootstrap globally

const TAB_CONTEXTS = {
  FUNKSJONSTEST: "FUNKSJONSTEST",
  FUNCTIONAL_DESCRIPTION: "FUNCTIONAL_DESCRIPTION",
};
let CURRENT_TAB_CONTEXT = TAB_CONTEXTS.FUNKSJONSTEST;

export function setTabContext(mode) {
  CURRENT_TAB_CONTEXT = TAB_CONTEXTS[mode] || TAB_CONTEXTS.FUNKSJONSTEST;
}

function getActiveTableBuilder() {
  return CURRENT_TAB_CONTEXT === TAB_CONTEXTS.FUNCTIONAL_DESCRIPTION
    ? buildFuncDescTable
    : buildFunksjonstestTable;
}

function wireTabLazyLoader(tabs, builder) {
  if (!tabs) return;
  if (tabs.lazyLoadListener) {
    tabs.removeEventListener('show.bs.tab', tabs.lazyLoadListener);
  }
  tabs.lazyLoadListener = function(event) {
    const targetSelector = event.target.getAttribute('href');
    const tabPane = targetSelector ? document.querySelector(targetSelector) : null;
    const host = tabPane?.querySelector('[data-role="ft-table-host"]');
    if (tabPane && host && tabPane.dataset.rendered === 'false') {
      const system_number = tabPane.dataset.systemName;
      const rowsForSystem = ALL_GROUPED_COMPONENTS[system_number] || [];
      host.innerHTML = '';
      host.appendChild(builder(rowsForSystem, system_number));
      tabPane.dataset.rendered = 'true';
      autosizeAll(host);
    }
  };
  tabs.addEventListener('show.bs.tab', tabs.lazyLoadListener);
}

// --- Fallback-export (beholdt for kompatibilitet) ---
export function openModalFor() { return; }

// ------------------------ System- og Komponent-parsing ------------------------

/**
 * Returnerer en kanonisk systemstreng (unik nøkkel + visningsnavn).
 * - Trimmer whitespace
 * - Stopper ved første kolon/slash/parantes/whitespace
 * - Erstatt komma/mellomrom med punktum
 * - Faller tilbake til første "tall(.tall)" fra start dersom fullt mønster mangler
 * - Returnerer "Uspesifisert" ved tom/ugyldig
 */
function canonicalSystem(raw) {
  if (raw == null) return "Uspesifisert";
  let s = String(raw).trim();
  if (!s) return "Uspesifisert";

  // erstatt komma/mellomrom med punktum for å unngå variasjoner som "4330,201" / "4330 201"
  s = s.replace(/[, ]+/g, ".");

  // kutt ved første kontrolltegn (kolon, slash, parentes, whitespace)
  s = s.split(/[:/()[\]\s]/)[0] || s;

  // forsøk å finne vanlig mønster: NNNN.NNN (1–4 siffer) . (1–3 siffer)
  const m = s.match(/\b(\d{1,4}\.\d{1,3})\b/);
  if (m) return m[1];

  // fallback: fra start – siffer + valgfri .siffer
  const m2 = s.match(/^\d+(?:\.\d+)?/);
  return m2 ? m2[0] : "Uspesifisert";
}

/** Systemnøkkel/label for rad */
export function getSystemKeyFromRow(r = {}) {
  const source = r.unique_system || r.system_number || r.system_full_name || "";
  return canonicalSystem(source);
}

/** Plukker komponent-ID fra full tag-streng, for eldre datakilder */
function parseComponentIdFromFullId(fullId) {
  if (!fullId || typeof fullId !== "string") return null;
  const m = fullId.match(/-(?:[A-Za-z]{2,3}\d{2,5}[^\s%]*)/);
  return m ? m[0].slice(1) : null;
}

// ------------------------ Hjelpere ------------------------
function el(tag, cls = "", html = "") {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (html) e.innerHTML = html;
  return e;
}
function makeStatusSelect(value = "Ikke startet") {
  const sel = dropdown(["Ikke startet", "Under arbeid", "Avvik", "Utført"], "");
  sel.value = value || "Ikke startet";
  applyColorCoding(sel, STATUS_COLORS);
  sel.addEventListener("change", () => applyColorCoding(sel, STATUS_COLORS));
  return sel;
}
function makeFunksjonsvalgSelect(value = "Øvrig") {
  const sel = dropdown(
    ["Start og Stopp funksjoner", "Reguleringsfunksjoner", "Sikkerhetsfunksjoner", "Øvrig"],
    ""
  );
  sel.value = value || "Øvrig";
  applyColorCoding(sel, INTEGRERT_TEST_COLORS);
  sel.addEventListener("change", () => applyColorCoding(sel, INTEGRERT_TEST_COLORS));
  return sel;
}
const SECTION_ORDER = [
  "Start og Stopp funksjoner",
  "Reguleringsfunksjoner",
  "Sikkerhetsfunksjoner",
  "Øvrig",
];

const ml = (lines) => lines.join("\n");

// ------------------------ Predefinerte rader ------------------------
const PREDEF = {
  "Start og Stopp funksjoner": [
    {
      komponent: "Nettstrøm",
      test: ml([
        "1. Systemet gjøres spenningsløst ved hjelp av sikkerhetsbryter tilhørende system/komponent, evt. sikring i forsyningstavle levert av elektro",
        "",
        "2. Kontroller at eventuelle sikkerhetsfunksjoner stenger ned og at alt ser spenningsløst",
        "",
        "3. Innkoble strøm igjen og kontroller at systemet starter opp som normal, i den driftsmodusen den skal være i"
      ]),
      aksept: ml([
        "1. Systemet er spenningsløst",
        "",
        "2. Alle komponenter er stengt ned som tiltenkt",
        "",
        "3. Strøm er tilbake og systemet er tilbake til normal drift, og uten alarmer"
      ])
    },
    {
      komponent: "LAN, SD",
      test: ml([
        "1. Verifiser at SD-anlegget har kontakt med regulator/kontroller",
        "",
        "2. Koble fra kommunikasjon mellom enhetene",
        "",
        "3. Verifiser at evt. endringer gjort fra SD-anlegget forblir i kontroller",
        "",
        "4. Koble tilbake, og verifiser normal drift"
      ]),
      aksept: ml([
        "1. Aggregatet er i kommunikasjon OK med SD-anlegget",
        "",
        "2. Begge enhetene mistet kontakten",
        "",
        "3. Alle settpunkter og endringer fungerer som normalt",
        "",
        "4. Enhetene kommuniserer som normalt, og uten alarmer",
        "",
        "Blir testet under IT-test, i regi av rITB evt. annen stedfortreder."
      ])
    },
    {
      komponent: "Program-vender, SD",
      test: ml([
        "Av:",
        "Betjen programvender i Av.",
        "",
        "På:",
        "Betjen programvender i På.",
        "",
        "Auto:",
        "Betjen programvender i Auto."
      ]),
      aksept: ml([
        "Av:",
        "Kontroller at systemet slår seg av på normal måte, og forblir avslått. Systemet påvirkes heller ikke av aktiv brannalarm",
        "",
        "På:",
        "Kontroller at systemet går kontinuerlig.",
        "",
        "Auto:",
        "Kontroller at anlegget er i drift iht. innstilt tidsprogram i SD-anlegg. Endringer slår inn. Brann/tidsprogram ellers testes i IT-test."
      ])
    }
  ],
  "Sikkerhetsfunksjoner": [
    {
      komponent: "Brannsignal",
      test: ml([
        "1. Stopp systemet",
        "2. Koble fra brannsignal (NC) fra IO på regulator",
        "3. Ved aktivt brannsignal aktiver frost",
        "4. Ved aktivt brannsignal, aktiver røykmelder i aggregatet",
        "5. Returner anlegget til normal drift",
        "",
        "Aktivt brannsignal testes i IT-test (rITB/avtalt)."
      ]),
      aksept: ml([
        "1. Systemet er stanset",
        "2. Aggregatet starter opp etter styring for brannscenario",
        "3. Systemet registrerer frost, men forsetter i brannmodus",
        "4. Systemet stanser, og røykmelder må resettes før restart",
        "5. Systemet er i normal drift"
      ])
    }
  ],
  "Øvrig": [
    {
      komponent: "SFP",
      test: ml([
        "1. Start aggregat i normal drift med prosjektert luftmengde. Mål luftmengde (m³/s) og total effekt til vifter (kW)",
        "2. Beregn SFP = effekt / luftmengde (evt. les HMI/SD). Sammenlign mot krav",
        "3. Endre luftmengde og gjenta for å se forventet endring i SFP",
        "4. Dokumenter måledata (tid, måleutstyr, luftmengde, effekt, metode)"
      ]),
      aksept: ml([
        "1. Stabil drift uten alarmer; målinger gir rimelige verdier",
        "2. SFP ≤ prosjektert (f.eks. ≤ 1,8 kW/(m³/s))",
        "3. SFP følger lastendring",
        "4. Full sporbar dokumentasjon"
      ])
    },
    {
      komponent: "-Logg/Alarm, SD",
      test: ml([
        "1. Verifiser at alle relevante punkter har logging aktivert og riktige alarmoppsett/tekster"
      ]),
      aksept: ml([
        "1. Logger og alarmer er aktive og trender som krav"
      ])
    }
  ]
};

// ------------------------ Filfilter ------------------------
export function renderFileFilter(files = [], refreshCallback) {
  const c = document.getElementById("fileFilterContainer");
  if (!c) return;
  c.innerHTML = "";
  if (!files.length) return;

  const label = document.createElement("label");
  label.className = "form-label";
  label.textContent = "Filfilter (vis/skjul):";
  c.appendChild(label);

  files.forEach(f => {
    const safeId = `file-chk-${String(f).replace(/[^a-zA-Z0-9_-]/g, "_")}`;
    const wrap = document.createElement("div");
    wrap.className = "form-check";
    wrap.innerHTML = `<input class="form-check-input" type="checkbox" checked data-filename="${f}" id="${safeId}"><label class="form-check-label" for="${safeId}">${f}</label>`;
    c.appendChild(wrap);
  });

  c.querySelectorAll('input[type="checkbox"]').forEach(chk => {
    chk.onchange = () => {
      const active = Array.from(c.querySelectorAll("input:checked")).map(i => i.dataset.filename);
      const filtered = (window.allRows || []).filter(r => active.includes(r.source));
      if (typeof refreshCallback === "function") refreshCallback(filtered);
      const tabContent = document.getElementById('systemTabContent');
      if (tabContent) autosizeAll(tabContent);
    };
  });
}

// ------------------------ MC Display ------------------------
export function renderMCProtocolDisplay(rows = []) {
  const systemTabs = document.getElementById("systemTabs");
  const systemTabContent = document.getElementById("systemTabContent");
  const protocolTable = document.getElementById("protocol-table");
  const filterBox = document.getElementById("system-filter-container");
  if (!systemTabs || !systemTabContent || !protocolTable) return;

  // ---- Gruppér rader på kanonisk nøkkel ----
  const grouped = {};
  rows.forEach(r => {
    const key = (r.unique_system || "Uspesifisert").toString();
    (grouped[key] = grouped[key] || []).push(r);
  });

  // Speil til global state (samme som FT)
  Object.keys(ALL_GROUPED_COMPONENTS).forEach(k => delete ALL_GROUPED_COMPONENTS[k]);
  Object.assign(ALL_GROUPED_COMPONENTS, grouped);

  ALL_IDENTIFIED_SYSTEMS.length = 0;
  Object.keys(grouped).sort().forEach(s => {
    ALL_IDENTIFIED_SYSTEMS.push({ number: s, full_name: s });
  });

  // Default: velg alle
  SELECTED_SYSTEM_NUMBERS.clear();
  ALL_IDENTIFIED_SYSTEMS.forEach(sys => SELECTED_SYSTEM_NUMBERS.add(sys.number));

  // intern renderer som respekterer valgt filter
  function renderTabs() {
    systemTabs.innerHTML = "";
    systemTabContent.innerHTML = "";
    systemTabs.style.display = "flex";
    systemTabContent.style.display = "block";
    protocolTable.style.display = "table";

    const systems = Object.keys(grouped)
      .filter(s => SELECTED_SYSTEM_NUMBERS.has(s))
      .sort((a, b) => a.localeCompare(b, "nb"));

    systems.forEach((sys, idx) => {
      const count = grouped[sys].length;

      const li = document.createElement("li");
      li.className = "nav-item";
      const a = document.createElement("a");
      a.className = "nav-link" + (idx === 0 ? " active" : "");
      a.setAttribute("data-bs-toggle", "tab");
      a.setAttribute("href", `#pane-mc-${idx}`);
      a.innerHTML = `<span class="tab-label">${sys}</span>
                     <span class="badge bg-secondary ms-2">${count}</span>`;
      li.appendChild(a);
      systemTabs.appendChild(li);

      const pane = document.createElement("div");
      pane.className = "tab-pane fade" + (idx === 0 ? " show active" : "");
      pane.id = `pane-mc-${idx}`;
      pane.dataset.systemName = sys;

      // Bygg MC-tabellen for dette systemet
      const tbl = document.createElement("table");
      tbl.className = "table table-sm align-middle";
      tbl.innerHTML = `
        <thead>
          <tr>
            <th style="width:56px;">Rekkefølge</th>
            <th>System</th>
            <th>Komponent ID</th>
            <th>Beskrivelse</th>
            <th>Montasjestatus</th>
            <th>Kablet og koblet</th>
            <th>Merket</th>
            <th>Tilordnet til</th>
            <th>Utført av</th>
            <th>Dato utført</th>
            <th>Kommentar</th>
            <th style="width:48px;">Slett</th>
          </tr>
        </thead>
        <tbody></tbody>`;
      const tbody = tbl.querySelector("tbody");

      // Hjelpere til radkontroll (opp/ned)
      function makeMoveButtons() {
        const tdCtl = document.createElement('td');
        tdCtl.style.verticalAlign = 'middle';
        tdCtl.style.textAlign = 'center';
        const group = document.createElement('div');
        group.className = 'btn-group-vertical btn-group-sm';
        const up = document.createElement('button');
        up.className = 'btn btn-light';
        up.title = 'Flytt opp';
        up.innerHTML = '<i class="bi bi-arrow-up"></i>';
        up.onclick = function () {
          const row = this.closest('tr');
          const prev = row?.previousElementSibling;
          if (prev) prev.before(row);
        };
        const down = document.createElement('button');
        down.className = 'btn btn-light';
        down.title = 'Flytt ned';
        down.innerHTML = '<i class="bi bi-arrow-down"></i>';
        down.onclick = function () {
          const row = this.closest('tr');
          const next = row?.nextElementSibling;
          if (next) next.after(row);
        };
        group.append(up, down);
        tdCtl.appendChild(group);
        return tdCtl;
      }

      // Sletteknapp
      function makeDeleteButton() {
        const tdBtn = document.createElement('td');
        tdBtn.className = 'text-center';
        tdBtn.style.verticalAlign = 'middle';
        const btn = document.createElement('button');
        btn.className = 'btn btn-sm btn-outline-danger';
        btn.title = 'Slett denne linjen';
        btn.innerHTML = '<i class="bi bi-trash"></i>';
        btn.onclick = () => {
          const tr = btn.closest('tr');
          if (tr && confirm('Er du sikker på at du vil slette denne linjen?')) tr.remove();
        };
        tdBtn.appendChild(btn);
        return tdBtn;
      }

      // Enkle cellehjelpere
      function cellSelect(options) {
        const td = document.createElement("td");
        const sel = document.createElement("select");
        sel.className = "form-select form-select-sm";
        sel.innerHTML = options.map(v => `<option>${v}</option>`).join("");
        td.appendChild(sel);
        return td;
      }
      function cellInput() {
        const td = document.createElement("td");
        td.innerHTML = `<input class="form-control form-control-sm">`;
        return td;
      }

      for (const r of grouped[sys]) {
        const tr = document.createElement("tr");

        // 1) Rekkefølge (opp/ned)
        tr.appendChild(makeMoveButtons());

        // 2) System
        const tdSystem = document.createElement("td");
        tdSystem.innerHTML = `<input class="form-control form-control-sm" data-col="system" value="${sys}">`;
        tr.appendChild(tdSystem);

        // 3) Komponent ID (inkluderer typekode hvis den finnes i full_id)
        const tdKomp = document.createElement("td");
        const kompOnly =
          (r.komponent && String(r.komponent).trim()) ||
          parseComponentIdFromFullId(r.full_id || "") || "";
        tdKomp.appendChild(tdText(kompOnly));
        tr.appendChild(tdKomp);

        // 4) Beskrivelse
        const tdDesc = document.createElement("td");
        tdDesc.appendChild(tdText(r.desc || "Ukjent beskrivelse"));
        tr.appendChild(tdDesc);

        // 5) Montasjestatus (bruk fargekodet velger som i Excel/FT)
        const tdStatus = document.createElement('td');
        tdStatus.appendChild(makeStatusSelect("Ikke startet"));
        tr.appendChild(tdStatus);

        // 6) Kablet og koblet
        tr.appendChild(cellSelect(["", "Ja", "Nei"]));

        // 7) Merket
        tr.appendChild(cellSelect(["", "Ja", "Nei"]));

        // 8) Tilordnet til
        tr.appendChild(cellInput());

        // 9) Utført av
        tr.appendChild(cellInput());

        // 10) Dato utført
        const tdDato = document.createElement("td");
        tdDato.innerHTML = `<input type="date" class="form-control form-control-sm">`;
        tr.appendChild(tdDato);

        // 11) Kommentar
        const tdKomm = document.createElement("td");
        tdKomm.innerHTML = `<textarea class="form-control form-control-sm" rows="1"></textarea>`;
        tr.appendChild(tdKomm);

        // 12) Slett
        tr.appendChild(makeDeleteButton());

        tbody.appendChild(tr);
      }

      pane.appendChild(tbl);
      systemTabContent.appendChild(pane);
    });
  }

  // Vis filteret (med riktig callback) og første render
  if (filterBox) filterBox.style.display = "block";
  renderSystemFilter(renderTabs);
  renderTabs();

  // Autosize/tilpasning
  try { autosizeAll?.(); } catch {}
}

// --- Globale variabler for flytting av rader ---
let _moveRowModalInstance;
let _rowToMoveElement = null; // Reference to the DOM tr element
let _rowToMoveData = null;    // Reference to the data object in ALL_GROUPED_COMPONENTS
let _sourceSystemKey = null;

function showMoveRowModal(rowElement, rowData, currentSystemKey) {
    _rowToMoveElement = rowElement;
    _rowToMoveData = rowData;
    _sourceSystemKey = currentSystemKey;

    const moveRowSystemSelect = document.getElementById('moveRowSystemSelect');
    moveRowSystemSelect.innerHTML = ''; // Clear previous options

    // Populate dropdown with available system tabs
    const availableSystems = Object.keys(ALL_GROUPED_COMPONENTS)
        .filter(sysKey => sysKey !== currentSystemKey) // Exclude current system
        .sort((a, b) => a.localeCompare(b, "nb"));

    if (availableSystems.length === 0) {
        showMessage("Ingen andre systemer å flytte til.", "warning");
        // Optionally hide the modal if no options
        return;
    }

    availableSystems.forEach(sysKey => {
        const option = document.createElement('option');
        option.value = sysKey;
        option.textContent = sysKey;
        moveRowSystemSelect.appendChild(option);
    });

    if (!_moveRowModalInstance) {
        _moveRowModalInstance = new bootstrap.Modal(document.getElementById('moveRowModal'));
        document.getElementById('confirmMoveRowBtn').addEventListener('click', handleMoveRowConfirmation);
    }
    _moveRowModalInstance.show();
}

function handleMoveRowConfirmation() {
    const destinationSystemKey = document.getElementById('moveRowSystemSelect').value;
    if (!destinationSystemKey || !_rowToMoveElement || !_rowToMoveData || !_sourceSystemKey) {
        showMessage("Feil ved flytting av rad: Ugyldig destinasjon eller raddata.", "error");
        _moveRowModalInstance.hide();
        return;
    }

    // 1. Extract current values from the DOM row before moving
    // This ensures any unsaved user input is captured
    const inputs = _rowToMoveElement.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        const name = input.name || input.dataset.col;
        if (name) {
            if (input.type === 'checkbox') {
                _rowToMoveData[name] = input.checked;
            } else if (input.tagName === 'SELECT') {
                _rowToMoveData[name] = input.value;
            } else {
                _rowToMoveData[name] = input.value;
            }
        }
    });
    // Special handling for funksjonsvalg select, if its name/data-col isn't caught above
    const funksjonsvalgSelect = _rowToMoveElement.querySelector('[data-role="funksjonsvalg"]');
    if (funksjonsvalgSelect) {
        _rowToMoveData.funksjonsvalg = funksjonsvalgSelect.value;
    }


    // 2. Remove from source system's data array
    let sourceSystemRows = ALL_GROUPED_COMPONENTS[_sourceSystemKey];
    const indexInSource = sourceSystemRows.indexOf(_rowToMoveData);
    if (indexInSource > -1) {
        sourceSystemRows.splice(indexInSource, 1);
    } else {
        // Fallback: if direct reference is lost (e.g., due to previous re-render), find by unique properties
        const kompId = _rowToMoveData.komponent;
        const testUtfoerelse = _rowToMoveData.testutfoerelse || _rowToMoveData.test;
        const foundIndex = sourceSystemRows.findIndex(r => 
            r.komponent === kompId && 
            (r.testutfoerelse || r.test) === testUtfoerelse &&
            r.system_number === _sourceSystemKey
        );
        if (foundIndex > -1) {
            sourceSystemRows.splice(foundIndex, 1);
        } else {
            showMessage("Klarte ikke å finne raden i kildesystemets data for fjerning.", "error");
            _moveRowModalInstance.hide();
            return;
        }
    }

    // 3. Add to destination system's data array and update system_number
    _rowToMoveData.system_number = destinationSystemKey;
    _rowToMoveData.unique_system = destinationSystemKey; // Ensure unique_system is also updated for consistency
    ALL_GROUPED_COMPONENTS[destinationSystemKey] = ALL_GROUPED_COMPONENTS[destinationSystemKey] || [];
    ALL_GROUPED_COMPONENTS[destinationSystemKey].push(_rowToMoveData);

    // 4. Re-render all tabs to reflect changes and sorting
    updateFilteredTabs();
    showMessage(`Linje flyttet til system ${destinationSystemKey}`, "success");
    _moveRowModalInstance.hide();

    // Reset global state
    _rowToMoveElement = null;
    _rowToMoveData = null;
    _sourceSystemKey = null;
}

// Helper to extract data from a DOM row
export function extractRowDataFromDom(rowElement, rowDataTemplate) {
    const extractedData = { ...rowDataTemplate }; // Start with existing data as template

    // Extract values from inputs, textareas, selects
    const inputs = rowElement.querySelectorAll('input, textarea, select');
    inputs.forEach(input => {
        const name = input.name || input.dataset.col;
        if (name) {
            if (input.type === 'checkbox') {
                extractedData[name] = input.checked;
            } else if (input.tagName === 'SELECT') {
                extractedData[name] = input.value;
            } else {
                extractedData[name] = input.value;
            }
        }
    });

    // Special handling for funksjonsvalg select, if its name/data-col isn't caught above
    const funksjonsvalgSelect = rowElement.querySelector('[data-role="funksjonsvalg"]');
    if (funksjonsvalgSelect) {
        extractedData.funksjonsvalg = funksjonsvalgSelect.value;
    }
    
    // Ensure system_number and unique_system are correctly set from the current tab's context
    const currentSystemKey = rowElement.closest('.tab-pane')?.dataset.systemName;
    if (currentSystemKey) {
        extractedData.system_number = currentSystemKey;
        extractedData.unique_system = currentSystemKey;
    }

    return extractedData;
}

// ------------------------ FUNKSJONSTEST ------------------------
export function renderFunksjonstestDisplay(rows = []) {
  const tabs = document.getElementById('systemTabs');
  const content = document.getElementById('systemTabContent');
  const table = document.getElementById('protocol-table');
  if (!tabs || !content || !table) return;

  // Gruppér rader på KANONISK nøkkel og skriv samtidig kanonisk system_number inn i radobjektet
  const grouped = {};
  rows.forEach(r => {
    const key = getSystemKeyFromRow(r); // KANONISK
    const obj = {
      ...r,
      system_number: key, // tving visning i tabell til kanonisk
      komponent: parseComponentIdFromFullId(r.full_id) || r.komponent,
      funksjonsvalg: r.funksjonsvalg || r.integrert || "Øvrig"
    };
    (grouped[key] = grouped[key] || []).push(obj);
  });

  // Speil til global state
  Object.keys(ALL_GROUPED_COMPONENTS).forEach(k => delete ALL_GROUPED_COMPONENTS[k]);
  Object.assign(ALL_GROUPED_COMPONENTS, grouped);

  // Bygg filterlisten med *samme* kanoniske tekst for både number og label
  ALL_IDENTIFIED_SYSTEMS.length = 0;
  Object.keys(grouped).sort().forEach(s => {
    ALL_IDENTIFIED_SYSTEMS.push({ number: s, full_name: s }); // label = key (kanonisk)
  });

  // Velg alt som default
  SELECTED_SYSTEM_NUMBERS.clear();
  ALL_IDENTIFIED_SYSTEMS.forEach(sys => SELECTED_SYSTEM_NUMBERS.add(sys.number));

  tabs.style.display = 'flex';
  content.style.display = 'block';
  table.style.display = 'none';

  setTabContext("FUNKSJONSTEST");
  wireTabLazyLoader(tabs, buildFunksjonstestTable);

  renderSystemFilter(updateFilteredTabs);
  updateFilteredTabs();
}

// ------------------------ Filter UI + Tab-render ------------------------
export function renderSystemFilter(onChange) {
  const filterContainer = document.getElementById('system-filter-container');
  if (!filterContainer) return;
  filterContainer.innerHTML = '<h6>Filtrer systemer:</h6>';

  const selectAllBtn = document.createElement('button');
  selectAllBtn.className = 'btn btn-sm btn-outline-secondary me-2 mb-2';
  selectAllBtn.textContent = 'Velg alle';
  selectAllBtn.onclick = () => {
    SELECTED_SYSTEM_NUMBERS.clear();
    ALL_IDENTIFIED_SYSTEMS.forEach(sys => SELECTED_SYSTEM_NUMBERS.add(sys.number));
    if (typeof onChange === 'function') onChange();
    renderSystemFilter();
  };

  const clearAllBtn = document.createElement('button');
  clearAllBtn.className = 'btn btn-sm btn-outline-secondary mb-2';
  clearAllBtn.textContent = 'Fjern alle';
  clearAllBtn.onclick = () => {
    SELECTED_SYSTEM_NUMBERS.clear();
    if (typeof onChange === 'function') onChange();
    renderSystemFilter();
  };

  filterContainer.append(selectAllBtn, clearAllBtn);

  const box = document.createElement('div');
  box.className = 'd-flex flex-wrap';
  filterContainer.appendChild(box);

  ALL_IDENTIFIED_SYSTEMS.forEach(sys => {
    const safe = sys.number ? String(sys.number).replace(/[^a-zA-Z0-9]/g, '_') : 'uspesifisert';
    const id = `sys-filter-${safe}`;
    const wrap = document.createElement('div');
    wrap.className = 'form-check form-check-inline';

    const input = document.createElement('input');
    input.type = 'checkbox';
    input.className = 'form-check-input';
    input.id = id;
    input.value = sys.number;
    input.checked = SELECTED_SYSTEM_NUMBERS.has(sys.number);
    input.onchange = e => {
      e.target.checked ? SELECTED_SYSTEM_NUMBERS.add(sys.number) : SELECTED_SYSTEM_NUMBERS.delete(sys.number);
      if (typeof onChange === 'function') onChange();
    };

    const label = document.createElement('label');
    label.className = 'form-check-label';
    label.htmlFor = id;
    label.textContent = sys.full_name; // = kanonisk

    wrap.append(input, label);
    box.appendChild(wrap);
  });

  filterContainer.style.display = 'block';
}

function createSectionHeaderRow(title, colSpan = 8) {
  const tr = document.createElement('tr');
  tr.className = 'table-primary section-row';
  tr.dataset.role = 'section-header';
  tr.dataset.section = title;
  const tdHdr = document.createElement('td');
  tdHdr.colSpan = colSpan;
  tdHdr.textContent = title;
  tdHdr.style.textAlign = "center";
  tdHdr.style.fontWeight = "600";
  tr.appendChild(tdHdr);
  return tr;
}

function insertAfterHeader(tbody, rowEl, sectionName) {
  const header = tbody.querySelector(`tr.section-row[data-section="${sectionName}"]`);
  if (!header) { tbody.appendChild(rowEl); return; }
  let before = null;
  for (let n = header.nextElementSibling; n; n = n.nextElementSibling) {
    if (n.classList?.contains('section-row')) { before = n; break; }
  }
  tbody.insertBefore(rowEl, before);
}

function buildComponentRow(obj, system_number) {
  const tr = document.createElement("tr");
  tr.dataset.komponentId = obj.komponent; // Store Komponent ID for sorting
  // Store a reference to the original data object for direct manipulation
  tr.rowData = obj; 

  const td0 = document.createElement('td');
  td0.style.verticalAlign = 'middle';
  td0.style.textAlign = 'center';
  const btnGroup = document.createElement('div');
  btnGroup.className = 'btn-group-vertical btn-group-sm';
  td0.classList.add('col-order-cell', 'sticky-col-left');
  const upBtn = document.createElement('button');
  upBtn.className = 'btn btn-light';
  upBtn.innerHTML = '<i class="bi bi-arrow-up"></i>';
  upBtn.title = 'Flytt opp';
  upBtn.onclick = function () {
    const currentRow = this.closest('tr');
    const prev = currentRow.previousElementSibling;
    if (prev && !prev.classList.contains('section-row')) prev.before(currentRow);
  };
  const downBtn = document.createElement('button');
  downBtn.className = 'btn btn-light';
  downBtn.innerHTML = '<i class="bi bi-arrow-down"></i>';
  downBtn.title = 'Flytt ned';
  downBtn.onclick = function () {
    const currentRow = this.closest('tr');
    const next = currentRow.nextElementSibling;
    if (next && !next.classList.contains('section-row')) next.after(currentRow);
  };
  btnGroup.append(upBtn, downBtn);
  td0.appendChild(btnGroup);
  tr.appendChild(td0);

  const sysInput = document.createElement("input");
  sysInput.type = "text";
  sysInput.className = "form-control form-control-sm";
  sysInput.value = system_number || obj.system_number || "";
  sysInput.readOnly = true;
  sysInput.setAttribute("data-col", "system");
  sysInput.setAttribute("name", "system_number");
  tr.appendChild(td(sysInput, "align-top-left"));

  const kompInput = document.createElement("input");
  kompInput.type = "text";
  kompInput.className = "form-control form-control-sm";
  kompInput.value = obj.komponent || "";
  kompInput.readOnly = true;
  tr.appendChild(td(kompInput, "align-top-left"));

  const tfm = (obj.komponent || "").substring(0, 2).toUpperCase();
  const forslagForTFM = FUNKSJONSBANK[tfm] || [];
  const forslagSel = document.createElement("select");
  forslagSel.className = "form-select form-select-sm";
  forslagSel.innerHTML = `<option value="">-- Velg funksjon --</option>`;
  forslagForTFM.forEach((f, i) => {
    const opt = document.createElement("option");
    opt.value = String(i);
    opt.textContent = f.navn || `(Uten navn ${i + 1})`;
    forslagSel.appendChild(opt);
  });
  if (!forslagForTFM.length) forslagSel.disabled = true;
  tr.appendChild(td(forslagSel, "align-top-left"));

  const testArea = document.createElement("textarea");
  testArea.className = "form-control form-control-sm autosize";
  testArea.value = obj.testutfoerelse || obj.test || "";
  testArea.rows = 2;
  tr.appendChild(td(testArea, "align-top-left"));

  const expArea = document.createElement("textarea");
  expArea.className = "form-control form-control-sm autosize";
  expArea.value = obj.aksept || "";
  expArea.rows = 2;
  tr.appendChild(td(expArea, "align-top-left"));

  forslagSel.onchange = () => {
    const i = Number(forslagSel.value);
    const f = forslagForTFM[i];
    if (!f) return;
    testArea.value = f.test || "";
    expArea.value = f.aksept || "";
    autosizeNow(testArea);
    autosizeNow(expArea);
  };

  const funksjonsvalgSel = makeFunksjonsvalgSelect(obj.funksjonsvalg || obj.integrert || "Øvrig");
  funksjonsvalgSel.dataset.role = "funksjonsvalg";
  tr.appendChild(td(funksjonsvalgSel));

  const btnTd = document.createElement("td");
  btnTd.className = 'text-center col-actions-cell sticky-col-right';
  btnTd.style.verticalAlign = 'middle';
  const funksjonerBtnGroup = document.createElement('div');
  funksjonerBtnGroup.className = 'btn-group';
  funksjonerBtnGroup.setAttribute('role', 'group');

  const lagreBtn = document.createElement("button");
  lagreBtn.className = "btn btn-sm btn-outline-primary";
  lagreBtn.innerHTML = '<i class="bi bi-save"></i>';
  lagreBtn.title = "Lagre test som mal i funksjonsbanken";
  lagreBtn.onclick = async () => {
    const navn = prompt("Gi funksjonen et visningsnavn:", forslagSel.options[forslagSel.selectedIndex].text);
    if (!navn || !navn.trim()) return;
    const payload = { tfm, navn: navn.trim(), test: testArea.value, aksept: expArea.value };
    try {
      const res = await fetch("/protokoller/lagre_funksjonstest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (res.ok) {
        showMessage("Ny funksjon lagret!", "success");
        const bank = FUNKSJONSBANK[tfm] = FUNKSJONSBANK[tfm] || [];
        bank.push(payload);
        const opt = document.createElement("option");
        opt.value = String(bank.length - 1);
        opt.textContent = payload.navn;
        forslagSel.appendChild(opt);
        forslagSel.disabled = false;
        forslagSel.value = String(bank.length - 1);
      } else {
        showMessage(`Feil: ${await res.text()}`, "error");
      }
    } catch (e) {
      showMessage(`Nettverksfeil: ${e.message}`, "error");
    }
  };

  const deleteBtn = document.createElement("button");
  deleteBtn.type = "button";
  deleteBtn.className = "btn btn-sm btn-outline-danger";
  deleteBtn.innerHTML = '<i class="bi bi-trash"></i>';
  deleteBtn.title = "Slett denne linjen";
  deleteBtn.onclick = () => { if (confirm("Er du sikker?")) tr.remove(); };

  const duplicateBtn = document.createElement('button');
  duplicateBtn.type = "button";
  duplicateBtn.className = 'btn btn-sm btn-outline-secondary';
  duplicateBtn.innerHTML = '<i class="bi bi-copy"></i>';
  duplicateBtn.title = 'Dupliser denne linjen';
  duplicateBtn.onclick = () => {
    const currentData = extractRowDataFromDom(tr, obj); // Extract current data from DOM
    const newRow = buildComponentRow(currentData, system_number);
    tr.after(newRow);
    autosizeAll(tr.closest('table'));
  };

  const moveBtn = document.createElement('button');
  moveBtn.type = "button";
  moveBtn.className = 'btn btn-sm btn-outline-info';
  moveBtn.innerHTML = '<i class="bi bi-arrow-right-square"></i>'; // Forward icon
  moveBtn.title = 'Flytt linje til et annet system';
  moveBtn.onclick = () => {
      showMoveRowModal(tr, obj, system_number);
  };

  funksjonerBtnGroup.append(lagreBtn, duplicateBtn, moveBtn, deleteBtn);
  btnTd.appendChild(funksjonerBtnGroup);
  tr.appendChild(btnTd);

  addAutoHeightListeners(testArea);
  addAutoHeightListeners(expArea);

  funksjonsvalgSel.addEventListener('change', () => {
    const table = tr.closest('table');
    const tbody = table?.querySelector('tbody');
    if (!tbody) return;
    const target = funksjonsvalgSel.value || "Øvrig";
    // Extract current data from DOM before re-rendering the row
    const currentData = extractRowDataFromDom(tr, obj);
    // Remove from current position in DOM
    tr.remove();
    // Find the correct section header and insert
    insertAfterHeader(tbody, buildComponentRow(currentData, system_number), target);
    autosizeAll(table);
  });

  return tr;
}

export function buildFunksjonstestTable(rows = [], systemTabKey = "") {
  const system_number = systemTabKey || getSystemKeyFromRow(rows?.[0] || {}) || "";
  const tbl = document.createElement("table");
  tbl.className = "table table-bordered table-sm table-ft";
  tbl.innerHTML = `<thead><tr>
    <th class="col-order" style="width: 5%;">Rekkefølge</th>
    <th style="width: 10%;">System</th>
    <th style="width: 10%;">Komponent ID</th>
    <th style="width: 5%;">Forslag</th>
    <th style="width: 25%;">Testutførelse</th>
    <th style="width: 25%;">Forventet resultat</th>
    <th style="width: 15%;">Funksjonsvalg</th>
    <th class="col-actions" style="width: 5%;">Funksjoner</th>
  </tr></thead><tbody></tbody>`;
  const tbody = tbl.querySelector("tbody");
  const renderedIdentifiers = new Set(); // For de-duplication

  // Group dynamic rows by section
  const groupedBySection = {};
  SECTION_ORDER.forEach(sec => groupedBySection[sec] = []);
  rows.forEach(rad => {
    const sec = rad.funksjonsvalg || rad.integrert || "Øvrig";
    if (SECTION_ORDER.includes(sec)) {
        groupedBySection[sec].push(rad);
    } else {
        groupedBySection["Øvrig"].push(rad);
    }
  });

  SECTION_ORDER.forEach(sec => {
    tbody.appendChild(createSectionHeaderRow(sec));
    
    // 1. Render PREDEF rows and record their identifiers
    const predefRows = (PREDEF[sec] || []).sort((a, b) => (a.komponent || "").localeCompare(b.komponent || ""));
    predefRows.forEach(p => {
      const identifier = `${p.komponent}|${sec}|${p.testutfoerelse || p.test}`;
      if (!renderedIdentifiers.has(identifier)) {
        const tr = buildComponentRow({ ...p, funksjonsvalg: sec }, system_number);
        tbody.appendChild(tr);
        renderedIdentifiers.add(identifier);
      }
    });

    // 2. Render dynamic rows (from DB and uploaded files), skipping duplicates
    const dynamicRows = groupedBySection[sec].sort((a, b) => (a.komponent || "").localeCompare(b.komponent || ""));
    dynamicRows.forEach(rad => {
      const identifier = `${rad.komponent}|${sec}|${rad.testutfoerelse || rad.test}`;
      if (!renderedIdentifiers.has(identifier)) {
        const tr = buildComponentRow(rad, system_number);
        tbody.appendChild(tr);
        renderedIdentifiers.add(identifier);
      }
    });
  });

  requestAnimationFrame(() => autosizeAll(tbl));
  return tbl;
}

export function renderInnreguleringDisplay(rows = []) {
  const table = document.getElementById("protocol-table");
  const tbody = document.getElementById("table-body");
  const thead = document.getElementById("table-head");
  const tabs = document.getElementById("systemTabs");
  const tabContent = document.getElementById("systemTabContent");
  if (!table || !tbody || !thead || !tabs || !tabContent) return;

  tabs.style.display = "none";
  tabContent.style.display = "none";
  table.style.display = "table";

  thead.innerHTML = `<tr><th>System</th><th>Komponent</th><th>vMin</th><th>vMid</th><th>vMaks</th><th>Kilde</th></tr>`;
  tbody.innerHTML = "";

  rows.forEach(r => {
    const tr = document.createElement("tr");
    tr.appendChild(td(getSystemKeyFromRow(r) || "")); // KANONISK
    tr.appendChild(td(r.komponent || ""));
    tr.appendChild(td(r.vMin || ""));
    tr.appendChild(td(r.vMid || ""));
    tr.appendChild(td(r.vMaks || ""));
    tr.appendChild(td(r.source || ""));
    tbody.appendChild(tr);
  });
}

// ------------------------ FUNKSJONSBESKRIVELSE (NY) ------------------------

function buildFuncDescRow(item, system_number) {
    const tr = document.createElement("tr");
    tr.rowData = item; // Store a reference to the original data object

    // Kolonne 1: Rekkefølge (Move buttons)
    const td0 = document.createElement('td');
    td0.style.verticalAlign = 'middle';
    td0.style.textAlign = 'center';
    const btnGroup = document.createElement('div');
    btnGroup.className = 'btn-group-vertical btn-group-sm';
    td0.classList.add('col-order-cell', 'sticky-col-left');
    const upBtn = document.createElement('button');
    upBtn.className = 'btn btn-light';
    upBtn.innerHTML = '<i class="bi bi-arrow-up"></i>';
    upBtn.title = 'Flytt opp';
    upBtn.onclick = function () {
      const currentRow = this.closest('tr');
      const prev = currentRow.previousElementSibling;
      if (prev && !prev.classList.contains('section-row')) prev.before(currentRow);
    };
    const downBtn = document.createElement('button');
    downBtn.className = 'btn btn-light';
    downBtn.innerHTML = '<i class="bi bi-arrow-down"></i>';
    downBtn.title = 'Flytt ned';
    downBtn.onclick = function () {
      const currentRow = this.closest('tr');
      const next = currentRow.nextElementSibling;
      if (next && !next.classList.contains('section-row')) next.after(currentRow);
    };
    btnGroup.append(upBtn, downBtn);
    td0.appendChild(btnGroup);
    tr.appendChild(td0);

    // Kolonne 2: Kategori (Dropdown)
    const kategoriSelect = makeFunksjonsvalgSelect(item.kategori || "Øvrig");
    kategoriSelect.dataset.role = "funksjonsvalg"; // Re-use funksjonsvalg role for consistency
    tr.appendChild(td(kategoriSelect, "align-top-left"));

    // Kolonne 3: Beskrivelse (Textarea)
    const beskrivelseArea = document.createElement("textarea");
    beskrivelseArea.className = "form-control form-control-sm autosize";
    beskrivelseArea.value = item.beskrivelse || "";
    beskrivelseArea.rows = 2;
    beskrivelseArea.setAttribute("data-col", "beskrivelse");
    tr.appendChild(td(beskrivelseArea, "align-top-left"));

    // Kolonne 4: Testutførelse (Textarea)
    const testutfoerelseArea = document.createElement("textarea");
    testutfoerelseArea.className = "form-control form-control-sm autosize";
    testutfoerelseArea.value = item.testutfoerelse || "";
    testutfoerelseArea.rows = 2;
    testutfoerelseArea.setAttribute("data-col", "testutfoerelse");
    tr.appendChild(td(testutfoerelseArea, "align-top-left"));

    // Kolonne 5: Akseptkriterie (Textarea)
    const akseptArea = document.createElement("textarea");
    akseptArea.className = "form-control form-control-sm autosize";
    akseptArea.value = item.aksept || "";
    akseptArea.rows = 2;
    akseptArea.setAttribute("data-col", "aksept");
    tr.appendChild(td(akseptArea, "align-top-left"));

    // Kolonne 6: Funksjoner (Slett, Dupliser, Flytt)
    const btnTd = document.createElement("td");
    btnTd.className = 'text-center col-actions-cell sticky-col-right';
    btnTd.style.verticalAlign = 'middle';
    const funksjonerBtnGroup = document.createElement('div');
    funksjonerBtnGroup.className = 'btn-group';
    funksjonerBtnGroup.setAttribute('role', 'group');

    const duplicateBtn = document.createElement('button');
    duplicateBtn.type = "button";
    duplicateBtn.className = 'btn btn-sm btn-outline-secondary';
    duplicateBtn.innerHTML = '<i class="bi bi-copy"></i>';
    duplicateBtn.title = 'Dupliser denne linjen';
    duplicateBtn.onclick = () => {
      const currentData = extractRowDataFromDom(tr, item); // Extract current data from DOM
      const newRow = buildFuncDescRow(currentData, system_number);
      tr.after(newRow);
      autosizeAll(tr.closest('table'));
    };

    const moveBtn = document.createElement('button');
    moveBtn.type = "button";
    moveBtn.className = 'btn btn-sm btn-outline-info';
    moveBtn.innerHTML = '<i class="bi bi-arrow-right-square"></i>'; // Forward icon
    moveBtn.title = 'Flytt linje til et annet system';
    moveBtn.onclick = () => {
        showMoveRowModal(tr, item, system_number);
    };

    const deleteBtn = document.createElement("button");
    deleteBtn.type = "button";
    deleteBtn.className = "btn btn-sm btn-outline-danger";
    deleteBtn.innerHTML = '<i class="bi bi-trash"></i>';
    deleteBtn.title = "Slett denne linjen";
    deleteBtn.onclick = () => { if (confirm("Er du sikker?")) tr.remove(); };

    funksjonerBtnGroup.append(duplicateBtn, moveBtn, deleteBtn);
    btnTd.appendChild(funksjonerBtnGroup);
    tr.appendChild(btnTd);

    addAutoHeightListeners(beskrivelseArea);
    addAutoHeightListeners(testutfoerelseArea);
    addAutoHeightListeners(akseptArea);

    kategoriSelect.addEventListener('change', () => {
        const table = tr.closest('table');
        const tbody = table?.querySelector('tbody');
        if (!tbody) return;
        const target = kategoriSelect.value || "Øvrig";
        // Update the rowData object directly
        tr.rowData.kategori = target;
        // Re-render the tab to reflect the change and resort
        updateFilteredTabs();
    });

    return tr;
}

export function buildFuncDescTable(rows = [], systemTabKey = "") {
    const system_number = systemTabKey; // System ID is passed directly
    const tbl = document.createElement("table");
    tbl.className = "table table-bordered table-sm table-ft"; // Reuse existing styles
    tbl.innerHTML = `<thead><tr>
      <th class="col-order" style="width: 5%;">Rekkefølge</th>
      <th style="width: 15%;">Kategori</th>
      <th style="width: 30%;">Beskrivelse</th>
      <th style="width: 25%;">Testutførelse</th>
      <th style="width: 20%;">Akseptkriterie</th>
      <th class="col-actions" style="width: 5%;">Funksjoner</th>
    </tr></thead><tbody></tbody>`;
    const tbody = tbl.querySelector("tbody");

    // Group rows by section (kategori)
    const groupedBySection = {};
    SECTION_ORDER.forEach(sec => groupedBySection[sec] = []);
    rows.forEach(item => {
        const sec = item.kategori || "Øvrig";
        if (SECTION_ORDER.includes(sec)) {
            groupedBySection[sec].push(item);
        } else {
            groupedBySection["Øvrig"].push(item);
        }
    });

    SECTION_ORDER.forEach(sec => {
        tbody.appendChild(createSectionHeaderRow(sec, 6));
        groupedBySection[sec].sort((a, b) => (a.beskrivelse || "").localeCompare(b.beskrivelse || "")).forEach(item => {
            const tr = buildFuncDescRow(item, system_number);
            tbody.appendChild(tr);
        });
    });

    requestAnimationFrame(() => autosizeAll(tbl));
    return tbl;
}


export function updateFilteredTabs() {
  const tabs = document.getElementById("systemTabs");
  const content = document.getElementById("systemTabContent");
  if (!tabs || !content) return;

  tabs.innerHTML = '';
  content.innerHTML = '';

  const toRender = Object.keys(ALL_GROUPED_COMPONENTS || {})
    .filter(s => SELECTED_SYSTEM_NUMBERS.has(s))
    .sort();

  if (!toRender.length) {
    content.innerHTML = `<p class="text-muted p-3">${Object.keys(ALL_GROUPED_COMPONENTS || {}).length ? 'Ingen systemer valgt.' : 'Ingen systemer funnet.'}</p>`;
    return;
  }

  toRender.forEach((system_number, idx) => {
    const full = system_number;
    const safeId = `tab-${String(system_number).replace(/[^a-zA-Z0-9]/g, '_')}`;
    const isActive = idx === 0;

    const li = document.createElement("li");
    li.className = "nav-item";
    li.innerHTML = `<a class="nav-link ${isActive ? 'active' : ''}" data-bs-toggle="tab" href="#${safeId}"><span class="tab-label">${full}</span></a>`;
    tabs.appendChild(li);

    const pane = document.createElement("div");
    pane.className = `tab-pane fade ${isActive ? 'show active' : ''}`;
    pane.id = safeId;
    pane.dataset.systemName = system_number;
    pane.dataset.rendered = isActive ? 'true' : 'false';

    const toolbar = document.createElement("div");
    toolbar.className = "ft-tab-toolbar d-flex flex-wrap justify-content-between align-items-center mb-2";
    toolbar.innerHTML = `
      <div class="ft-tab-meta">
        <div class="fw-semibold text-uppercase text-muted small">System</div>
        <div class="h5 mb-0">${full}</div>
      </div>
      <div class="ft-tab-actions">
        <button class="btn btn-sm btn-outline-secondary me-2" data-role="scroll-tab-top">
          <i class="bi bi-arrow-up-short"></i> Til toppen
        </button>
        <button class="btn btn-sm btn-primary" data-role="download-system" data-system="${system_number}" data-system-label="${full}">
          <i class="bi bi-download"></i> Last ned denne fanen
        </button>
      </div>`;
    pane.appendChild(toolbar);

    const host = document.createElement("div");
    host.className = "ft-table-host";
    host.dataset.role = "ft-table-host";
    pane.appendChild(host);

    if (isActive) {
      const rader = ALL_GROUPED_COMPONENTS[system_number] || [];
      const builder = getActiveTableBuilder();
      host.appendChild(builder(rader, system_number));
    } else {
      host.innerHTML = `<div class="d-flex justify-content-center p-5"><div class="spinner-border" role="status"><span class="visually-hidden">Laster...</span></div></div>`;
    }

    content.appendChild(pane);
  });

  // Ensure the first tab's content is properly sized after initial render
  if (content.querySelector('.tab-pane.active')) {
      autosizeAll(content.querySelector('.tab-pane.active'));
  }
}
