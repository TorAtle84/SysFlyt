// ============================================================================
// PROTOKOLLER • UI (Komplett og revidert for korrekt MC-streaming og filtrering)
// Init, event-delegation, generering, nedlasting, TFM-modal + TAB-RENAME (FT)
// ============================================================================

import {
  FUNKSJONSBANK, showMessage, getUsers, getTechnicians, getLoggedInUser, autosizeAll, tdText,
  // Viktig: robust komponentparser og TFM-filter-state fra core
  TFM_SETTINGS, getComponentFromAny, tfmPrefix,
  ALL_GROUPED_COMPONENTS, ALL_IDENTIFIED_SYSTEMS, SELECTED_SYSTEM_NUMBERS
} from "./protokoller.core.js";

import {
  renderFileFilter, renderMCProtocolDisplay, renderFunksjonstestDisplay, renderInnreguleringDisplay,
  renderSystemFilter, extractRowDataFromDom, buildFuncDescTable, getSystemKeyFromRow, updateFilteredTabs,
  setTabContext
} from "./protokoller.tables.js";

window.allRows = []; // gjør tilgjengelig for filfilter og nedlasting

// --- Robust JSON-leser: tåler at server sender HTML/feilmelding i stedet for JSON
async function safeJson(res) {
  const txt = await res.text();              // les alltid som tekst

  try {
    return JSON.parse(txt);                  // forsøk å parse som JSON
  } catch (e) {
    console.error("[safeJson] Ikke-JSON respons:", txt.slice(0, 400));
    throw new Error(`Ugyldig JSON fra server (status ${res.status}).`);
  }
}

// --- State for system-kriterier (for systemknappene) ---
const SELECTED_SYSTEM_CRITERIA = new Set();

// ------------------------ System-modalen ------------------------
function openModalFor(button) {
  const mainDigit = button?.dataset?.val;
  if (!mainDigit) return;

  const modalEl = document.getElementById('filterModal');
  const modalTitle = document.getElementById('modalTitle');
  const modalCheckboxes = document.getElementById('modalCheckboxes');
  const modalConfirm = document.getElementById('modalConfirm');
  if (!modalEl || !modalTitle || !modalCheckboxes || !modalConfirm) {
    showMessage("Filtermodal mangler i DOM.", "error");
    return;
  }

  const modal = new window.bootstrap.Modal(modalEl);
  modalTitle.textContent = `Velg systemer fra kategori ${mainDigit}x`;
  modalCheckboxes.innerHTML = '';

  const checkboxContainer = document.createElement('div');
  checkboxContainer.className = 'd-flex flex-wrap gap-3';
  modalCheckboxes.appendChild(checkboxContainer);

  for (let i = 0; i < 10; i++) {
    const systemValue = `${mainDigit}${i}`;
    const isChecked = SELECTED_SYSTEM_CRITERIA.has(systemValue);

    const div = document.createElement('div');
    div.className = 'form-check form-check-inline';
    div.innerHTML = `
      <input class="form-check-input" type="checkbox" value="${systemValue}" id="sys-chk-${systemValue}" ${isChecked ? 'checked' : ''}>
      <label class="form-check-label" for="sys-chk-${systemValue}">
        ${systemValue}
      </label>
    `;
    checkboxContainer.appendChild(div);
  }

  modalConfirm.onclick = () => {
    for (let i = 0; i < 10; i++) {
      SELECTED_SYSTEM_CRITERIA.delete(`${mainDigit}${i}`);
    }
    modalCheckboxes.querySelectorAll('input:checked').forEach(chk => {
      SELECTED_SYSTEM_CRITERIA.add(chk.value);
    });
    const hasSelection = Array.from(SELECTED_SYSTEM_CRITERIA).some(s => s.startsWith(mainDigit));
    button.classList.toggle('selected', hasSelection);
    modal.hide();
    showMessage(`Filter for kategori ${mainDigit}x oppdatert.`, 'success');
  };
  modal.show();
}

document.addEventListener('click', (ev) => {
  const sysBtn = ev.target.closest?.('.sys-btn');
  if (sysBtn) openModalFor(sysBtn);
}, true);

const _msgBox = document.getElementById('message-box');
// Removed _msgBox.style.pointerEvents = 'none'; to allow interaction if needed


// ------------------------ TFM-innstillinger ------------------------
async function loadTfmSettings(funksjon) {
  const key = (funksjon || "").toUpperCase();
  if (!TFM_SETTINGS[key]) return;

  try {
    const res = await fetch(`/protokoller/api/tfm-liste?funksjon=${encodeURIComponent(funksjon)}`);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const settings = await safeJson(res); // robust
    TFM_SETTINGS[key].clear();
    Object.entries(settings || {}).forEach(([kode, aktiv]) => {
      if (aktiv) TFM_SETTINGS[key].add(kode);
    });
  } catch (e) {
    showMessage(`Kunne ikke laste TFM-innstillinger for ${funksjon}: ${e.message}`, 'error');
  }
}

// ======================================================================
// NDJSON streamingleser – brukes av MC for live-progresjon (tåler også SSE `data:`)
// ======================================================================
async function readNdjsonStream(response, onLine) {
  // Ingen strøm? Les alt som tekst og prøv linjevis
  if (!response?.body?.getReader) {
    const txt = await response.text();
    txt.split(/\r?\n/).forEach(l => {
      let line = l.trim();
      if (!line) return;
      if (line.startsWith('data:')) line = line.slice(5).trim(); // håndter SSE
      try { onLine?.(JSON.parse(line)); } catch { /* ignorer ulesbare linjer */ }
    });
    return;
  }

  const reader  = response.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { value, done } = await reader.read();
    if (done) break;

    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split(/\r?\n/);
    buffer = lines.pop() ?? "";

    for (let raw of lines) {
      let line = raw.trim();
      if (!line) continue;
      if (line.startsWith('data:')) line = line.slice(5).trim(); // håndter SSE
      try { onLine?.(JSON.parse(line)); }
      catch { /* ignorer ulesbare linjer */ }
    }
  }

  let tail = buffer.trim();
  if (tail) {
    if (tail.startsWith('data:')) tail = tail.slice(5).trim();
    try { onLine?.(JSON.parse(tail)); } catch { /* ignore */ }
  }
}

// ======================================================================
// MC-filter helper (TFM-prefiks 2–4 bokstaver før første siffer + failsafe)
// ======================================================================
function applyMcTfmFilter(rows) {
  if (!Array.isArray(rows) || rows.length === 0) return [];
  const tillatte = TFM_SETTINGS.MC;

  // Ingen aktive koder => vis alt
  if (!tillatte || tillatte.size === 0) {
    console.debug("[MC] TFM-filter tomt/ikke lastet → viser alle rader");
    return rows;
  }

  const before = rows.length;
  const filteredRows = rows.filter(r => {
    const komponentId = getComponentFromAny(r.full_id, r.komponent);
    if (!komponentId) return false;
    const pref = tfmPrefix(komponentId); // 2–4 bokstaver før første siffer
    const prefUpper = String(pref || '').toUpperCase();
    if (prefUpper === 'STB') return true;
    const pref2 = prefUpper.slice(0, 2);
    return !!prefUpper && (tillatte.has(prefUpper) || tillatte.has(pref2));
  });

  // Failsafe – ikke end opp med "0" i UI hvis filteret er for strengt
  if (before > 0 && filteredRows.length === 0) {
    console.debug("[MC] TFM-filter aktivt, men 0 beholdt → failsafe: viser alle");
    showMessage("Alle rader ble filtrert bort av TFM-filteret. Viser alle rader midlertidig. Juster TFM-filteret i menyen.", "warning");
    return rows;
  }

  console.debug(`[MC] TFM-filter aktivt: beholdt ${filteredRows.length}/${before} rader`);
  return filteredRows;
}

// Generisk TFM-filter for FT/INNREGULERING med samme STB-unntak
function applyGenericTfmFilter(rows, tillatte) {
  if (!Array.isArray(rows) || rows.length === 0) return [];
  if (!tillatte || tillatte.size === 0) return rows; // ingen aktive → vis alt (failsafe)

  const before = rows.length;
  const filtered = rows.filter(r => {
    const komponentId = getComponentFromAny(r.full_id, r.komponent);
    if (!komponentId) return false;
    const prefFull = (tfmPrefix(komponentId) || '').toUpperCase();
    if (!prefFull) return false;
    if (prefFull === 'STB') return true; // unntak
    const pref2 = prefFull.slice(0, 2);
    return tillatte.has(prefFull) || tillatte.has(pref2);
  });

  if (before > 0 && filtered.length === 0) return rows; // failsafe
  return filtered;
}

function mergeBackendSuggestions(extraSuggestions = {}) {
  if (!extraSuggestions || typeof extraSuggestions !== 'object') return;
  const toText = (val) => (val == null ? "" : String(val));
  Object.entries(extraSuggestions).forEach(([prefix, suggestions]) => {
    if (!Array.isArray(suggestions) || !suggestions.length) return;
    const key = String(prefix || '').toUpperCase();
    if (!key) return;
    const bucket = FUNKSJONSBANK[key] = FUNKSJONSBANK[key] || [];

    suggestions.forEach(s => {
      if (!s) return;
      const kandidat = {
        navn: toText(s.navn ?? s.beskrivelse).trim(),
        test: toText(s.test).trim(),
        aksept: toText(s.aksept).trim()
      };
      if (!kandidat.navn && !kandidat.test && !kandidat.aksept) return;
      const finnes = bucket.some(existing =>
        existing.navn === kandidat.navn &&
        existing.test === kandidat.test &&
        existing.aksept === kandidat.aksept
      );
      if (!finnes) bucket.push(kandidat);
    });
  });
}

function normalizeRowObject(rawRow) {
  if (rawRow == null) return null;
  if (typeof rawRow === "string") {
    try {
      return JSON.parse(rawRow);
    } catch {
      return null;
    }
  }
  if (typeof rawRow === "object") return rawRow;
  return null;
}

async function triggerFileDownload(endpoint, payload, defaultFilename) {
  const statusText = document.getElementById("status-text");
  if (statusText) statusText.textContent = "Forbereder nedlasting...";

  console.log("--- LOGG 2: Data som sendes til server for nedlasting ---");
  console.log("Endpoint:", endpoint);
  if (payload.protocol_data) {
    console.log("protocol_data length:", payload.protocol_data.length);
    console.log("sample:", payload.protocol_data[0]);
  }
  if (payload.rows) {
    console.log("rows length:", payload.rows.length);
    console.log("sample:", payload.rows[0]);
  }

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) throw new Error(await res.text());
    const blob = await res.blob();
    const disp = res.headers.get("Content-Disposition");
    const m = disp?.match(/filename="?([^"]+)"?/);
    const filename = m && m[1] ? m[1] : defaultFilename;
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
    if (statusText) statusText.textContent = "Protokoll lastet ned.";
    showMessage("Protokoll lastet ned!", "success");
    document.querySelectorAll('.row-changed').forEach(row => row.classList.remove('row-changed'));
  } catch (e) {
    showMessage(`Feil ved nedlasting: ${e.message}`, "error");
    if (statusText) statusText.textContent = "Status: Nedlasting feilet.";
  }
}

async function downloadFunksjonstestRows(rawRows, filenameHint = "Funksjonstest_Protokoll", protocolVariant = "FUNKSJONSTEST") {
  const rows = rawRows
    .map(normalizeRowObject)
    .filter(r => r && typeof r === "object");

  if (!rows.length) {
    showMessage("Ingen data å laste ned for dette systemet.", "info");
    return;
  }

  const payload = {
    protocol_data: rows,
    filename_prefix: filenameHint.replace(/\.xlsx$/i, ""),
    bruker: await getLoggedInUser(),
    protocol_variant: protocolVariant
  };

  await triggerFileDownload(
    "/protokoller/download_funksjonstest_protokoll",
    payload,
    `${payload.filename_prefix}.xlsx`
  );
}

// ======================================================================
// TAB-RENAME (FT): oppdater fane-tittel og "System"-kolonnen i alle rader
// ======================================================================
function getPaneFromTabLink(tabLinkEl) {
  if (!tabLinkEl) return null;
  const target = tabLinkEl.getAttribute('data-bs-target') || tabLinkEl.getAttribute('href');
  if (!target) return null;
  try { return document.querySelector(target); } catch { return null; }
}

function applySystemNameToPane(tabLinkEl, newName) {
  const pane = getPaneFromTabLink(tabLinkEl);
  if (!pane) return;

  // Oppdater faneteksten
  const labelEl = tabLinkEl.querySelector('.tab-label') || tabLinkEl;
  labelEl.textContent = newName;
  pane.dataset.systemName = newName;

  // OPPDATER KUN SYSTEM-FELT
  // Treffer både MC og FT hvis vi merker inputs riktig (se pkt. 2)
  const inputs = pane.querySelectorAll('input[data-col="system"], input[name="system_number"]');
  inputs.forEach(inp => { inp.value = newName; });
}

function promptRenameForTab(tabLinkEl) {
  const currentText = (tabLinkEl.querySelector('.tab-label') || tabLinkEl).textContent.trim() || 'Uspesifisert';
  const newName = window.prompt('Gi systemet et navn:', currentText);
  if (!newName) return; // avbrutt
  applySystemNameToPane(tabLinkEl, newName.trim());
}

function getSelectedLlmMode() {
  const value = document.querySelector("input[name='llm-mode']:checked")?.value || "local";
  return value.toLowerCase();
}

function updateLlmAdvancedState() {
  const mode = getSelectedLlmMode();
  document.querySelectorAll('[data-llm-advanced]').forEach(el => {
    el.disabled = mode !== 'api';
  });
}

function toggleLlmModeVisibility(selectedFunctionValue) {
  const container = document.getElementById('llm-mode-container');
  if (!container) return;
  const shouldShow = selectedFunctionValue === 'FUNCTIONAL_DESCRIPTION';
  container.classList.toggle('d-none', !shouldShow);
  if (!shouldShow) {
    const localRadio = document.getElementById('llm-mode-local');
    if (localRadio && !localRadio.checked) {
      localRadio.checked = true;
    }
  }
  updateLlmAdvancedState();
}

// ======================================================================
// Generering (MC streamer; FT/INNREGULERING vanlig JSON)
// ======================================================================
async function handleGeneration() {
  const funksjonsvalgEl = document.getElementById("funksjonsvalg");
  const formatEl        = document.getElementById("format-input");
  const filerEl         = document.getElementById("filopplaster");
  const statusText      = document.getElementById("status-text");
  const generateBtn     = document.getElementById("generate-data-btn");
  const downloadBtn     = document.getElementById("download-protocol-btn");
  const systemFilterContainer = document.getElementById("system-filter-container");
  const protocolTable   = document.getElementById("protocol-table");

  if (!funksjonsvalgEl || !filerEl || !statusText || !generateBtn || !downloadBtn || !protocolTable) {
    showMessage("Påkrevd UI-element mangler i DOM.", "error");
    return;
  }

  const funksjon = (funksjonsvalgEl.value || "").trim();
  const format   = (formatEl?.value || "").trim();
  const filer    = filerEl.files;

  if (!funksjon) return showMessage("Velg en funksjon først.", 'info');
  if (!filer || filer.length === 0) return showMessage("Last opp minst én fil.", 'warning');
  if (funksjon.toUpperCase() !== "FUNKSJONSTEST" && !format) {
    return showMessage("Du må angi et format for denne protokolltypen.", 'warning');
  }

  const formData = new FormData();
  formData.append("format", format || "{komponent}");
  formData.append("funksjon", funksjon);
  formData.append("debug", "1"); // be backend strømme debug-linjer hvis støttet
  for (const f of filer) formData.append("files", f);
  const systemKriterierString = Array.from(SELECTED_SYSTEM_CRITERIA).join(',');
  if (systemKriterierString) formData.append("system_kriterier", systemKriterierString);

  // Legg til egendefinerte regler hvis aktiv
  const egendefinertToggle = document.getElementById("egendefinert-toggle");
  if (egendefinertToggle?.classList.contains('selected')) {
    const custom_rule_byggnr = document.getElementById('custom-rule-byggnr')?.value.trim();
    const custom_rule_system = document.getElementById('custom-rule-system')?.value.trim();
    const custom_rule_komponent = document.getElementById('custom-rule-komponent')?.value.trim();
    const custom_rule_typekode = document.getElementById('custom-rule-typekode')?.value.trim();

    if (custom_rule_byggnr) formData.append('custom_rule_byggnr', custom_rule_byggnr);
    if (custom_rule_system) formData.append('custom_rule_system', custom_rule_system);
    if (custom_rule_komponent) formData.append('custom_rule_komponent', custom_rule_komponent);
    if (custom_rule_typekode) formData.append('custom_rule_typekode', custom_rule_typekode);
  }

  if (funksjon.toUpperCase() === "FUNCTIONAL_DESCRIPTION") {
    const llmMode = getSelectedLlmMode();
    formData.append("llm_mode", llmMode);
    if (llmMode === "api") {
      const apiModel = document.getElementById("llm-api-model")?.value?.trim();
      if (apiModel) formData.append("llm_api_model", apiModel);
      const costValue = document.getElementById("llm-max-cost")?.value;
      const parsed = parseFloat(costValue);
      if (!Number.isNaN(parsed) && parsed > 0) {
        formData.append("llm_max_cost", parsed.toString());
      }
    }
  }

  generateBtn.disabled = true;
  downloadBtn.disabled = true;
  protocolTable.style.display = "none";
  if (systemFilterContainer) systemFilterContainer.style.display = "none";
  statusText.textContent = `Genererer underlag for ${funksjon}…`;

  let endpoint = "";
  let renderFunction = null;

  switch (funksjon.toUpperCase()) {
    case "FUNKSJONSTEST":
      endpoint = "/protokoller/generate_funksjonstest";
      renderFunction = renderFunksjonstestDisplay;
      if (systemFilterContainer) systemFilterContainer.style.display = "block";
      break;
    case "MC":
      endpoint = "/protokoller/generate_underlag";
      renderFunction = renderMCProtocolDisplay;
      break;
    case "INNREGULERING":
      endpoint = "/protokoller/generate_innreguleringsprotokoll";
      renderFunction = renderInnreguleringDisplay;
      break;
    case "FUNCTIONAL_DESCRIPTION":
        endpoint = "/protokoller/generate_functional_description";
        renderFunction = renderFuncDescDisplay;
        if (systemFilterContainer) systemFilterContainer.style.display = "block";
        break;
    default:
      showMessage("Ukjent funksjon.", "error");
      generateBtn.disabled = false;
      return;
  }

  try {
    if (funksjon.toUpperCase() === "MC") {
      // ---------- STREAMET NDJSON ----------
      const res = await fetch(endpoint, { method: "POST", body: formData });
      if (!res.ok) throw new Error(`Serverfeil (${res.status}): ${await res.text()}`);

      let lastRows = [];
      let currentFile = null;
      let filesSeen = 0;

      await readNdjsonStream(res, (obj) => {
        // Backend kan sende {"currentFile": "..."} og til slutt {"rows":[...]}
        if (obj.currentFile) {
          currentFile = obj.currentFile;
          filesSeen++;
          if (statusText) statusText.textContent = `Leser: ${currentFile} (${filesSeen}/${filer.length})…`;
        }
        if (obj.error) {
          console.warn("Backend-feil:", obj.error);
          showMessage(obj.error, "warning");
        }
        if (Array.isArray(obj.rows)) {
          lastRows = obj.rows;
        }
        if (obj.debug) console.debug("[MC debug]", obj);
      });

      const allRowsFromServer = Array.isArray(lastRows) ? lastRows : [];

      // LOGG 1: Rådata
      console.log("--- LOGG 1: Rådata mottatt fra server ---");
      console.table(allRowsFromServer);

      // --- TFM-filter + failsafe ---
      const finalRows = applyMcTfmFilter(allRowsFromServer);
      window.allRows = finalRows;

      // Filfilter-UI
      const uniqueFiles = [...new Set(finalRows.map(row => row.source))];
      renderFileFilter(uniqueFiles, (filteredByFile) => {
        const activeFileNames = new Set(filteredByFile.map(row => row.source));
        const correctlyFiltered = finalRows.filter(row => activeFileNames.has(row.source));
        renderFunction(correctlyFiltered);
      });

      renderFunction(finalRows);
      protocolTable.style.display = "table";
      if (statusText) {
        statusText.textContent = `Fant ${finalRows.length} komponenter. ` +
          (TFM_SETTINGS.MC?.size > 0 ? `(TFM-filter aktivt: ${TFM_SETTINGS.MC.size} koder)` : `(TFM-filter: av)`);
      }
      showMessage("Underlag (MC) generert!", "success");
      downloadBtn.disabled = (finalRows.length === 0);
    } else {
      // ---------- FT/INNREGULERING: vanlig JSON ----------
      const res = await fetch(endpoint, { method: "POST", body: formData });
      if (!res.ok) throw new Error(`Serverfeil (${res.status}): ${await res.text()}`);

      const data = await safeJson(res); // robust

      // Check for missing TFM procedures (Task 2.2) or handle FUNCTIONAL_DESCRIPTION data structure
      if (funksjon.toUpperCase() === "FUNKSJONSTEST" && data.missing_tfms && data.missing_tfms.length > 0) {
        showMissingTfmsWarning(data.missing_tfms, () => {
          // User chose to continue, render the table
          proceedWithRendering(data, renderFunction, protocolTable, statusText, downloadBtn, funksjon.toUpperCase());
        });
      } else {
        // No warning, render as normal
        proceedWithRendering(data, renderFunction, protocolTable, statusText, downloadBtn, funksjon.toUpperCase());
      }
    }
  } catch (err) {
    console.error(err);
    showMessage(`Noe gikk galt: ${err.message}`, 'error');
    if (statusText) statusText.textContent = "Status: Feil ved generering.";
  } finally {
    generateBtn.disabled = false;
  }
}

function proceedWithRendering(data, renderFunction, protocolTable, statusText, downloadBtn, protocolType) {
  const payloadIsObject = data && typeof data === "object" && !Array.isArray(data);
  const extraSuggestions = payloadIsObject ? (data.suggestions || {}) : {};
  const llmMeta = payloadIsObject ? data.llm_meta : null;
  let finalRows = [];

  if (protocolType === "FUNCTIONAL_DESCRIPTION") {
      finalRows = data.generated_tests || [];
  } else {
      finalRows = Array.isArray(data) ? data : (data.rows || []);
  }

  // Bruk samme TFM-filterlogikk (med STB-unntak) for FT/INNREGULERING
  if (renderFunction === renderFunksjonstestDisplay) {
    finalRows = applyGenericTfmFilter(finalRows, TFM_SETTINGS.FUNKSJONSTEST);
  } else if (renderFunction === renderInnreguleringDisplay) {
    finalRows = applyGenericTfmFilter(finalRows, TFM_SETTINGS.INNREGULERING);
  }
  window.allRows = finalRows;

  // LOGG 1: Rådata
  console.log("--- LOGG 1: Rådata mottatt fra server (FT/Innregulering) ---");
  console.table(finalRows);

  // Funksjonsbank-beriking (kun FT) - bruker nå forhåndslastet data
  if (renderFunction === renderFunksjonstestDisplay) {
    mergeBackendSuggestions(extraSuggestions);
    finalRows.forEach(r => {
      const bank = FUNKSJONSBANK[(r.komponent || "").substring(0, 2).toUpperCase()];
      if (bank && bank.length) {
        r.funksjonsbeskrivelse = r.funksjonsbeskrivelse || bank[0].navn || "";
        r.testutfoerelse       = r.testutfoerelse       || bank[0].test || "";
        r.aksept               = r.aksept               || bank[0].aksept || "";
      }
    });
  }

  // Filfilter-UI
  const uniqueFiles = [...new Set(finalRows.map(row => row.source))];
  renderFileFilter(uniqueFiles, (filteredByFile) => {
    const activeFileNames = new Set(filteredByFile.map(row => row.source));
    const correctlyFiltered = finalRows.filter(row => activeFileNames.has(row.source));
    renderFunction(correctlyFiltered);
  });

  renderFunction(finalRows);
  protocolTable.style.display = (protocolType === "FUNKSJONSTEST" || protocolType === "FUNCTIONAL_DESCRIPTION") ? "none" : "table";

  const systemCount = new Set(finalRows.map(row => row?.system_number || row?.unique_system || "Uspesifisert")).size;
  if (statusText) {
    if (protocolType === "FUNCTIONAL_DESCRIPTION") {
      let baseText = `Genererte ${finalRows.length} testlinjer for ${systemCount} system(er).`;
      if (llmMeta) {
        const metaBits = [];
        if (llmMeta.mode) {
          metaBits.push(`LLM-modus: ${llmMeta.mode === 'api' ? 'API (hybrid)' : 'Lokal'}`);
        }
        if (typeof llmMeta.api_cost === 'number') {
          metaBits.push(`API-kost: $${llmMeta.api_cost.toFixed(2)}`);
        }
        if (llmMeta.api_calls) {
          metaBits.push(`API-kall: ${llmMeta.api_calls}`);
        }
        if (metaBits.length) {
          baseText += ` (${metaBits.join(' | ')})`;
        }
      }
      statusText.textContent = baseText;
    } else {
      statusText.textContent = `Fant ${finalRows.length} komponenter.`;
    }
  }

  if (protocolType === "FUNCTIONAL_DESCRIPTION" && llmMeta) {
    if (llmMeta.api_budget_exhausted) {
      showMessage("API-kostnadsgrensen ble nådd. Enkelte seksjoner ble ferdigstilt lokalt.", "warning");
    }
    if (Array.isArray(llmMeta.api_errors) && llmMeta.api_errors.length) {
      showMessage(llmMeta.api_errors.join("\n"), "warning");
    }
  }

  const successMessage = protocolType === "FUNCTIONAL_DESCRIPTION"
    ? "Funksjonsbeskrivelse generert!"
    : "Underlag generert!";
  showMessage(successMessage, "success");
  downloadBtn.disabled = (finalRows.length === 0);
}

// ======================================================================
// Innlesing av FT-rader fra DOM
// ======================================================================
const _val = (el) => (el && typeof el.value !== "undefined") ? el.value : "";

function collectFunksjonstestRowsFromDOM(limitSystems = null) {
    const allRowsForExport = [];
    const targetSystems = limitSystems
        ? Array.from(limitSystems)
        : Array.from(SELECTED_SYSTEM_NUMBERS);

    for (const systemKey of targetSystems) {
        const systemData = ALL_GROUPED_COMPONENTS[systemKey];
        if (!systemData) continue;

        const safeId = String(systemKey).replace(/[^a-zA-Z0-9]/g, '_');
        const paneId = `tab-${safeId}`;
        const pane = document.getElementById(paneId);

        if (pane && pane.dataset.rendered === 'true') {
            const tableRows = pane.querySelectorAll('tbody tr:not([data-role="section-header"])');
            tableRows.forEach(tr => {
                if (tr.rowData) {
                    const updatedRowData = extractRowDataFromDom(tr, tr.rowData);
                    allRowsForExport.push(updatedRowData);
                }
            });
        } else {
            allRowsForExport.push(...systemData);
        }
    }
    return allRowsForExport;
}

function showMissingTfmsWarning(missingTfms, continueCallback) {
  const modalEl = document.getElementById('warningModal');
  const modalBody = document.getElementById('warningModalBody');
  const continueBtn = document.getElementById('warningModalContinueBtn');
  const cancelBtn = document.getElementById('warningModalCancelBtn');

  if (!modalEl || !modalBody || !continueBtn || !cancelBtn) {
    showMessage("Advarsels-modal mangler i DOM.", "error");
    // As a fallback, continue without user confirmation
    continueCallback();
    return;
  }

  modalBody.innerHTML = `
    <p>Følgende komponenter har ingen predefinert prosedyre for test:</p>
    <ul>
      ${missingTfms.map(tfm => `<li>${tfm}</li>`).join('')}
    </ul>
    <p>Vil du fortsette uten disse prosedyrene?</p>
  `;

  const modal = new window.bootstrap.Modal(modalEl);

  const onContinue = () => {
    modal.hide();
    continueCallback();
  };

  continueBtn.addEventListener('click', onContinue, { once: true });

  modal.show();
}

export function renderFuncDescDisplay(rows = []) {
  const tabs = document.getElementById('systemTabs');
  const content = document.getElementById('systemTabContent');
  const table = document.getElementById('protocol-table');
  if (!tabs || !content || !table) return;
  setTabContext("FUNCTIONAL_DESCRIPTION");

  // Gruppér rader på KANONISK nøkkel
  const grouped = {};
  rows.forEach(r => {
    const key = getSystemKeyFromRow(r); // KANONISK
    const obj = {
      ...r,
      system_number: key, // tving visning i tabell til kanonisk
    };
    (grouped[key] = grouped[key] || []).push(obj);
  });

  // Speil til global state
  Object.keys(ALL_GROUPED_COMPONENTS).forEach(k => delete ALL_GROUPED_COMPONENTS[k]);
  Object.assign(ALL_GROUPED_COMPONENTS, grouped);

  // Bygg filterlisten med *samme* kanoniske tekst for både number og label
  ALL_IDENTIFIED_SYSTEMS.length = 0;
  Object.keys(grouped).sort().forEach(s => {
    ALL_IDENTIFIED_SYSTEMS.push({ number: s, full_name: s }); // label = key (kanonisk)
  });

  // Velg alt som default
  SELECTED_SYSTEM_NUMBERS.clear();
  ALL_IDENTIFIED_SYSTEMS.forEach(sys => SELECTED_SYSTEM_NUMBERS.add(sys.number));

  tabs.style.display = 'flex';
  content.style.display = 'block';
  table.style.display = 'none';

  // --- Add Lazy Loading Event Listener for Functional Description Tabs ---
  if (tabs.lazyLoadListener) {
    tabs.removeEventListener('show.bs.tab', tabs.lazyLoadListener);
  }
  tabs.lazyLoadListener = function(event) {
    const tabPane = document.querySelector(event.target.getAttribute('href'));
    const host = tabPane?.querySelector('[data-role="ft-table-host"]');
    if (tabPane && host && tabPane.dataset.rendered === 'false') {
      const system_number = tabPane.dataset.systemName;
      const rader = ALL_GROUPED_COMPONENTS[system_number] || [];

      host.innerHTML = '';
      host.appendChild(buildFuncDescTable(rader, system_number)); // Use the new buildFuncTable
      tabPane.dataset.rendered = 'true';

      autosizeAll(host);
    }
  };
  tabs.addEventListener('show.bs.tab', tabs.lazyLoadListener);

  renderSystemFilter(updateFilteredTabs);
  updateFilteredTabs();
}

// ======================================================================
// INIT / EVENTS
// ======================================================================
document.addEventListener("DOMContentLoaded", async () => {
  // Oppgave 3.1: Konsolider funksjonsbank-DB (korrigert)
  try {
    const res = await fetch('/static/data/funksjonsbank.json');
    if (res.ok) {
      const data = await res.json();
      Object.assign(FUNKSJONSBANK, data);
      console.log("Funksjonsbank lastet fra statisk fil!");
    } else {
      console.warn("Kunne ikke laste funksjonsbank.json. Status:", res.status);
    }
  } catch (e) {
    console.error("Feil ved lasting av funksjonsbank.json:", e);
  }

  await Promise.all([
    getUsers(),
    getTechnicians(),
    loadTfmSettings('MC'),
    loadTfmSettings('FUNKSJONSTEST'),
    loadTfmSettings('INNREGULERING')
  ]);

  const funksjonsvalg = document.getElementById("funksjonsvalg");
  const generateBtn = document.getElementById("generate-data-btn");
  const downloadBtn = document.getElementById("download-protocol-btn");
  const clearBtn = document.getElementById("clear-table-btn");
  const tfmBtn = document.getElementById("tfm-popup-btn");
  const egendefinertToggle = document.getElementById("egendefinert-toggle");
  const customRulesContainer = document.getElementById("custom-rules-container");
  const llmModeRadios = document.querySelectorAll("input[name='llm-mode']");

  if (llmModeRadios.length) {
    llmModeRadios.forEach(radio => radio.addEventListener('change', updateLlmAdvancedState));
    updateLlmAdvancedState();
  }

  if (egendefinertToggle && customRulesContainer) {
    egendefinertToggle.addEventListener('click', () => {
      const isVisible = customRulesContainer.style.display === 'block';
      customRulesContainer.style.display = isVisible ? 'none' : 'block';
      egendefinertToggle.classList.toggle('selected', !isVisible);
    });
  }

  const protocolTable = document.getElementById("protocol-table");
  const systemTabs = document.getElementById("systemTabs");
  const systemTabContent = document.getElementById("systemTabContent");
  const systemFilterContainer = document.getElementById("system-filter-container");
  if (systemTabContent) {
    systemTabContent.addEventListener('change', (event) => {
      const target = event.target;
      if (target.matches('input, select, textarea')) {
        const row = target.closest('tr');
        if (row) {
          row.classList.add('row-changed');
        }
      }
    });
    systemTabContent.addEventListener('click', async (event) => {
      const valgt = (funksjonsvalg?.value || '').toUpperCase();
      const perTabBtn = event.target.closest('[data-role="download-system"]');
      if (perTabBtn) {
        if (valgt !== 'FUNKSJONSTEST') return;
        const systemKey = perTabBtn.dataset.system;
        if (!systemKey) return;
        const label = perTabBtn.dataset.systemLabel || systemKey;
        const safeLabel = `Funksjonstest_${label.replace(/[^\w.-]+/g, "_")}`;
        perTabBtn.disabled = true;
        try {
          const rows = collectFunksjonstestRowsFromDOM(new Set([systemKey]));
          await downloadFunksjonstestRows(rows, safeLabel);
        } finally {
          perTabBtn.disabled = false;
        }
      }

      const scrollBtn = event.target.closest('[data-role="scroll-tab-top"]');
      if (scrollBtn) {
        const pane = scrollBtn.closest('.tab-pane');
        if (pane) pane.scrollTo({ top: 0, behavior: 'smooth' });
      }
    });
  }

  const thead = protocolTable?.querySelector("thead");

  if (funksjonsvalg) {
    funksjonsvalg.onchange = () => {
      const valgt = (funksjonsvalg.value || "").toUpperCase();
      toggleLlmModeVisibility(valgt);
      if (systemTabs) systemTabs.innerHTML = "";
      if (systemTabContent) systemTabContent.innerHTML = "";
      if (systemFilterContainer) systemFilterContainer.style.display = "none";
      if (protocolTable) protocolTable.style.display = "table";
      if (tfmBtn) tfmBtn.style.display = ["MC", "INNREGULERING", "FUNKSJONSTEST"].includes(valgt) ? "inline-block" : "none";

      if (!thead) return;

      if (valgt === "MC") {
        thead.innerHTML = `<tr><th>System</th><th>Komponent ID</th><th>Beskrivelse</th><th>Montasjestatus</th><th>Kablet og koblet</th><th>Merket</th><th>Tilordnet til</th><th>Utført av</th><th>Dato utført</th><th>Kommentar</th></tr>`;
      } else if (valgt === "INNREGULERING") {
        thead.innerHTML = `<tr><th>System</th><th>Komponent</th><th>vMin</th><th>vMid</th><th>vMaks</th><th>Kilde</th></tr>`;
      } else if (valgt === "FUNCTIONAL_DESCRIPTION") {
        thead.innerHTML = ""; // Functional description uses its own table structure within tabs
        if (protocolTable) protocolTable.style.display = "none";
        // systemTabs and systemTabContent will be set to 'flex' and 'block' by renderFuncDescDisplay
      } else {
        thead.innerHTML = "";
        if (protocolTable) protocolTable.style.display = "none";
      }
    };

    toggleLlmModeVisibility((funksjonsvalg.value || "").toUpperCase());
  }

  if (generateBtn) generateBtn.onclick = handleGeneration;

  if (clearBtn) {
    clearBtn.onclick = () => {
      if (!confirm("Er du sikker på at du vil fjerne alt innhold? Dette kan ikke angres.")) return;
      if (systemTabs) {
        systemTabs.innerHTML = "";
        systemTabs.style.display = "none";
      }
      if (systemTabContent) {
        systemTabContent.innerHTML = "";
        systemTabContent.style.display = "none";
      }
      const tbody = protocolTable?.querySelector("tbody");
      if (tbody) tbody.innerHTML = "";
      if (protocolTable) protocolTable.style.display = "table";
      if (systemFilterContainer) {
        systemFilterContainer.innerHTML = "";
        systemFilterContainer.style.display = "none";
      }
      const fileFilter = document.getElementById("fileFilterContainer");
      if (fileFilter) fileFilter.innerHTML = "";

      document.querySelectorAll('.row-changed').forEach(row => {
        row.classList.remove('row-changed');
      });

      window.allRows = [];
      SELECTED_SYSTEM_CRITERIA.clear();
      document.querySelectorAll('.sys-btn.selected').forEach(b => b.classList.remove('selected'));
      showMessage("Alt innhold er fjernet.", "info");
      const statusText = document.getElementById("status-text");
      if (statusText) statusText.textContent = "Tabell tømt.";
      if (downloadBtn) downloadBtn.disabled = true;
    };
  }

  if (tfmBtn) {
    tfmBtn.onclick = async () => {
      const funksjon = funksjonsvalg?.value;
      const tfmTable = document.getElementById("tfmTable");
      const tbody = tfmTable?.querySelector("tbody");
      if (!tbody) return showMessage("TFM-tabellen ble ikke funnet.", "error");
      try {
        const [statusRes, dictRes] = await Promise.all([
          fetch(`/protokoller/api/tfm-liste?funksjon=${encodeURIComponent(funksjon || "")}`),
          fetch(`/static/data/tfm-dict.json`)
        ]);
        if (!statusRes.ok || !dictRes.ok) throw new Error("Kunne ikke laste TFM-data.");
        const statusData = await safeJson(statusRes);     // robust
        const beskrivelseData = await safeJson(dictRes); // robust
        tbody.innerHTML = "";
        Object.entries(statusData || {}).forEach(([kode, aktiv]) => {
          const tr = tbody.insertRow();

          const tdKode = document.createElement("td");
          tdKode.appendChild(tdText(kode));
          tr.appendChild(tdKode);

          const tdBeskr = document.createElement("td");
          tdBeskr.appendChild(tdText(beskrivelseData?.[kode] || "Ikke i bruk"));
          tr.appendChild(tdBeskr);

          const sel = document.createElement("select");
          sel.className = "form-select";
          sel.innerHTML = `<option>Aktiv</option><option>Inaktiv</option>`;
          sel.value = aktiv ? "Aktiv" : "Inaktiv";
          sel.style.backgroundColor = aktiv ? "#d9ead3" : "#f8d7da";
          sel.onchange = () => sel.style.backgroundColor = sel.value === "Aktiv" ? "#d9ead3" : "#f8d7da";
          const tdSel = document.createElement("td");
          tdSel.appendChild(sel);
          tr.appendChild(tdSel);
        });
        new window.bootstrap.Modal(document.getElementById("tfmModal")).show();
      } catch (e) {
        showMessage(`TFM-feil: ${e.message}`, "error");
      }
    };
  }

  const lagreTfmBtn = document.getElementById("lagre-tfm-btn");
  if (lagreTfmBtn) {
    lagreTfmBtn.onclick = async () => {
      const tfmTable = document.getElementById("tfmTable");
      const tbody = tfmTable?.querySelector("tbody");
      const funksjon = funksjonsvalg?.value;
      if (!tbody || !funksjon) return;

      const payload = {};
      tbody.querySelectorAll("tr").forEach(tr => {
        const kode = tr.cells?.[0]?.textContent?.trim();            // les tekst, ikke input
        const statusSel = tr.cells?.[2]?.querySelector("select");
        const status = statusSel ? statusSel.value : "Inaktiv";
        if (kode) payload[kode] = (status === "Aktiv");
      });

      try {
        const r = await fetch(`/protokoller/api/tfm-liste/save?funksjon=${encodeURIComponent(funksjon)}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        if (!r.ok) throw new Error(await r.text());
        await loadTfmSettings(funksjon); // reflekter endringene umiddelbart
        showMessage("TFM-filteret er lagret og oppdatert!", "success");
        const modalEl = document.getElementById("tfmModal");
        if (modalEl) window.bootstrap.Modal.getInstance(modalEl)?.hide();
      } catch (e) {
        showMessage(`Feil ved lagring av TFM: ${e.message}`, "error");
      }
    };
  }

  // --- Rename system tabs (FT): dblclick tab title eller klikk på .rename-tab
  const systemTabsNav = document.getElementById('systemTabs');
  if (systemTabsNav) {
    // Dobbelklikk på fanen
    systemTabsNav.addEventListener('dblclick', (ev) => {
      const link = ev.target.closest('a.nav-link');
      if (!link) return;
      const valgt = (funksjonsvalg?.value || '').toUpperCase();
      if (!['FUNKSJONSTEST', 'MC'].includes(valgt)) return;
      ev.preventDefault();
      promptRenameForTab(link);
    });

    // (Valgfritt) liten penn-ikon i fanen
    systemTabsNav.addEventListener('click', (ev) => {
      const renameBtn = ev.target.closest('.rename-tab');
      if (!renameBtn) return;
      const link = renameBtn.closest('a.nav-link');
      if (!link) return;
      const valgt = (funksjonsvalg?.value || '').toUpperCase();
      if (valgt !== 'FUNKSJONSTEST') return;
      ev.preventDefault();
      promptRenameForTab(link);
    });
  }

  // Nedlasting
  if (downloadBtn) {
    downloadBtn.addEventListener("click", async () => {
      const valgt = (funksjonsvalg?.value || "").toUpperCase();
      if (valgt === "FUNKSJONSTEST") {
        const rawRows = collectFunksjonstestRowsFromDOM();
        await downloadFunksjonstestRows(rawRows, "Funksjonstest_Protokoll");
        return;
      } else if (valgt === "FUNCTIONAL_DESCRIPTION") {
        const rawRows = collectFunksjonstestRowsFromDOM(); // Reuse this function as the data structure for export is similar
        await downloadFunksjonstestRows(rawRows, "Funksjonsbeskrivelse_Protokoll", "FUNCTIONAL_DESCRIPTION");
        return;
      }

      let endpoint = "", payload = {}, defaultFilename = "Protokoll.xlsx";
      const rowsToDownload = window.allRows || [];

      if (valgt === "MC") {
        endpoint = "/protokoller/download_protokoll";
        defaultFilename = "MC_Protokoll.xlsx";
        const rows = rowsToDownload.map(r => ({
          full_id: r.full_id, desc: r.desc, unique_system: r.unique_system
        }));
        if (!rows.length) return showMessage("Ingen data å laste ned.", "info");
        payload.rows = rows;
      } else if (valgt === "INNREGULERING") {
        return showMessage("Nedlasting for Innregulering er ikke implementert.", "info");
      } else {
        return showMessage("Velg en protokolltype for nedlasting.", "warning");
      }

      payload.bruker = await getLoggedInUser();
      await triggerFileDownload(endpoint, payload, defaultFilename);
    });
  }
});
