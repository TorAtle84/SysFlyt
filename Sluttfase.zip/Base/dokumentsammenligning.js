// static/js/dokumentsammenligning.js
document.addEventListener("DOMContentLoaded", () => {
  const statusDiv = document.getElementById("dokumentsammenligning-status");

  // ===== Modus-veksling (syntaktisk/kombinert/diff) =====
  const modus = document.getElementById("sokemodus");
  const syntaktisk = document.getElementById("syntaktisk-oppsett");
  const diffseksjon = document.getElementById("diff-oppsett");

  function setMode(value) {
    if (!syntaktisk || !diffseksjon) return;
    syntaktisk.style.display = value === "syntaktisk" ? "" : "none";
    diffseksjon.style.display = value === "diff" ? "" : "none";
    if (statusDiv) statusDiv.textContent = "";
  }
  if (modus) {
    modus.addEventListener("change", e => setMode(e.target.value));
    setMode(modus.value || "syntaktisk");
  }

  // ===== Syntaktisk: vis/skjul hoveddokument + checkbox ved valg =====
  const radios = document.querySelectorAll("input[name='syntaktisk_action']");
  const onlyRow = document.getElementById("only-hoveddokument-row");
  const hovedRow = document.getElementById("hoveddokument-row");
  function toggleSyntaktiskFields() {
    const v = document.querySelector("input[name='syntaktisk_action']:checked")?.value || "search";
    if (hovedRow && onlyRow) {
      if (v === "diff") {
        hovedRow.style.display = "";
        onlyRow.style.display = "";
      } else {
        hovedRow.style.display = "none";
        onlyRow.style.display = "none";
      }
    }
  }
  radios.forEach(r => r.addEventListener("change", toggleSyntaktiskFields));
  toggleSyntaktiskFields();



  // ===== Diff-sjekk =====
  const diffRunBtn = document.getElementById("diff-run");
  const textA = document.getElementById("textA");
  const textB = document.getElementById("textB");
  const fileA = document.getElementById("fileA");
  const fileB = document.getElementById("fileB");
  const diffSideA = document.getElementById("diff-sideA");
  const diffSideB = document.getElementById("diff-sideB");

  async function readFileAsText(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.onerror = () => reject(reader.error);
      // Bruk korrekt FileReader-API for tekst
      try {
        reader.readAsText(file);
      } catch (e) {
        reject(e);
      }
    });
  }

  fileA?.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (file) {
      textA.value = await readFileAsText(file);
    }
  });

  fileB?.addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (file) {
      textB.value = await readFileAsText(file);
    }
  });

  function escapeHTML(s) {
    return (s || "").replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  }

  function renderWordDiffFiltered(wordDiff, side) {
    if (!Array.isArray(wordDiff)) return "";
    return wordDiff.map(part => {
      if (part.op === "=") {
        return `<span>${escapeHTML(part.text)}</span>`;
      }
      if (side === "left" && part.op === "-") {
        return `<span class="diff-del">${escapeHTML(part.text)}</span>`;
      }
      if (side === "right" && part.op === "+") {
        return `<span class="diff-ins">${escapeHTML(part.text)}</span>`;
      }
      return "";
    }).join(" ");
  }

  function syncScroll(elA, elB) {
    let lock = false;
    elA?.addEventListener("scroll", () => {
      if (lock) return;
      lock = true;
      if (elB) elB.scrollTop = elA.scrollTop;
      lock = false;
    });
    elB?.addEventListener("scroll", () => {
      if (lock) return;
      lock = true;
      if (elA) elA.scrollTop = elB.scrollTop;
      lock = false;
    });
  }
  if (diffSideA && diffSideB) syncScroll(diffSideA, diffSideB);

  async function runDiff() {
    if (statusDiv) statusDiv.textContent = "⏳ Kjører diff...";
    if (diffSideA) diffSideA.innerHTML = "";
    if (diffSideB) diffSideB.innerHTML = "";

    const payload = {
      text_a: textA.value,
      text_b: textB.value,
      ignore_case: document.getElementById('ignore_case')?.checked || false,
      ignore_ws: document.getElementById('ignore_ws')?.checked || true,
      ignore_digits: document.getElementById('ignore_digits')?.checked || false,
    };

    try {
      const res = await fetch("/diff_sjekk", { 
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload) 
      });
      if (!res.ok) throw new Error(`Feil: ${res.status} – ${await res.text()}`);
      const diffResult = await res.json();

      for (const b of diffResult.blocks || []) {
        if (b.type === "equal") {
          diffSideA?.insertAdjacentHTML("beforeend", `<div class="blk eq"><pre>${escapeHTML(b.textA || "")}</pre></div>`);
          diffSideB?.insertAdjacentHTML("beforeend", `<div class="blk eq"><pre>${escapeHTML(b.textB || "")}</pre></div>`);
        } else if (b.type === "delete") {
          diffSideA?.insertAdjacentHTML("beforeend", `<div class="blk del"><pre>${escapeHTML(b.textA || "")}</pre></div>`);
          diffSideB?.insertAdjacentHTML("beforeend", `<div class="blk empty"><pre></pre></div>`);
        } else if (b.type === "insert") {
          diffSideA?.insertAdjacentHTML("beforeend", `<div class="blk empty"><pre></pre></div>`);
          diffSideB?.insertAdjacentHTML("beforeend", `<div class="blk ins"><pre>${escapeHTML(b.textB || "")}</pre></div>`);
        } else if (b.type === "replace") {
          const left = renderWordDiffFiltered(b.wordDiff || [], "left");
          const right = renderWordDiffFiltered(b.wordDiff || [], "right");
          diffSideA?.insertAdjacentHTML("beforeend", `<div class="blk rep"><pre>${left || escapeHTML(b.textA || "")}</pre></div>`);
          diffSideB?.insertAdjacentHTML("beforeend", `<div class="blk rep"><pre>${right || escapeHTML(b.textB || "")}</pre></div>`);
        }
      }

      if (statusDiv) statusDiv.textContent = "✅ Diff fullført.";
      if ((diffSideA?.innerHTML || "").trim() === "" && (diffSideB?.innerHTML || "	").trim() === "") {
        diffSideA.innerHTML = `<div class="blk eq"><pre>Ingen forskjeller.</pre></div>`;
        diffSideB.innerHTML = `<div class="blk eq"><pre>Ingen forskjeller.</pre></div>`;
      }
    } catch (err) {
      if (statusDiv) statusDiv.textContent = `🚨 ${err.message}`;
    }
  }

  diffRunBtn?.addEventListener("click", (e) => {
    e.preventDefault();
    runDiff();
  });
});
