# Fil: app/routes/protokoller_core.py

import logging

# Create a separate logger for debugging
file_handler = logging.FileHandler('C:/Users/tm5479/.gemini/tmp/9c9f6fd532f8accd7f1edef29427521c0d3bb6223ce13d4547c832bcd2b2fb38/parser.log')
file_handler.setLevel(logging.INFO)
file_handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
parser_logger = logging.getLogger('parser_logger')
parser_logger.addHandler(file_handler)

import joblib
from flask import Blueprint, request, jsonify, Response, stream_with_context, render_template, current_app
import io, re, json, os
import fitz, docx
from openpyxl import load_workbook
from openpyxl.styles import Font, Alignment, PatternFill
from app.models.user import User
from flask_login import current_user, login_required
from typing import Dict, Iterable, Iterator, Optional

bp = Blueprint("protokoller", __name__, url_prefix="/protokoller")
basedir = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.abspath(os.path.join("app", "data"))
STATIC_DATA_DIR = os.path.abspath(os.path.join("app", "static", "data"))
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(STATIC_DATA_DIR, exist_ok=True)

TFM_DICT = {"AB": "Bjelke", "AD": "Dekker", "AE": "Elementer", "AF": "Fagverk", "AG": "Glassfelt", "AH": "Fundamenter",
"AK": "Komplette konstruksjoner", "AL": "List - Beslistning", "AO": "Oppbygende - Utforende", "AP": "Plate", "AR": "Ramme - Oppheng",
"AS": "Søyle", "AU": "Åpninger", "AV": "Vegg", "BA": "Armering Forsterkning", "BB": "Beskyttende - Stoppende", "BC": "Begrensende",
"BF": "Fuging", "BG": "Pakning Tetning", "BI": "Isolasjon", "BP": "Avretningsmasse", "BS": "Spikerslag", "CB": "Balkong",
"CC": "Baldakin", "CD": "Karnapp", "CG": "Rampe - Repos", "CK": "Komplett konstruksjon", "CM": "Kjemiske stoffer", "CO": "Kobling Overgang",
"CP": "Pipe - Skostein", "CQ": "Festemateriell", "CR": "Rammeverk - Oppheng", "CT": "Trapp - Leider", "CX": "Tunnel - Bru (inne-ute)",
"DB": "Dør med brannklasse", "DF": "Foldedør - Foldevegg", "DI": "Dør - innvendig", "DK": "Kjøretøyregulering", "DL": "Luke", "DP": "Port",
"DT": "Dør - tilfluktsrom", "DU": "Dør - utvendig", "DV": "Vindu", "EB": "Overflatebekledning", "EC": "Overflatebehandling", "EH": "Himling",
"FA": "Ventilert arbeidsplass", "FB": "Benk - Bord - Plate - Tavle", "FC": "Beslag", "FD": "Disk - Skranke", "FF": "Fryserom", "FH": "Hylle - Reol",
"FI": "Kabinett", "FK": "Kjølerom - Svalrom", "FO": "Sittebenk - Sofa - Stol", "FR": "Rom", "FS": "Skap - Skuff", "FT": "Speil",
"FV": "Vaskemaskin", "FX": "Krok - Knagg - Håndtak", "GA": "Automat - Maskin", "GB": "Benk - Bord - Plate - Tavle", "GD": "Dekontamator",
"GE": "Autoklaver", "GF": "Fryseskap", "GG": "Gardiner - Forheng", "GH": "Hylle - Reol", "GK": "Kjøleskap - Kjøledisk", "GL": "Lås - Beslag",
"GM": "Mattilbereding", "GN": "Nøkler", "GO": "Sofa - Sittebenk", "GP": "Stol", "GQ": "Seng - Liggebenk", "GS": "Skap - Skuffer",
"GT": "Tørkeskap - Varmeskap", "GV": "Vaskemaskin", "GW": "Vekt", "GX": "Holder", "GY": "Avfallsbeholder", "HA": "Automobil - Bil",
"HB": "Rullebord - Tralle", "HC": "Container - Vogn", "HM": "Maskin", "HS": "Rullestol", "HT": "Truck - kran", "HV": "Verktøy",
"IB": "Brenner", "IC": "Solceller-solfangere", "ID": "Kjel for destruksjon", "IE": "Elektrokjel", "IF": "Kjel for fast-bio brensel",
"IG": "Generator", "IK": "Kuldeaggregat", "IL": "Energibrønn", "IM": "Motor", "IO": "Oljekjel", "IP": "Gasskjel", "IT": "Trykkluftaggregat (enhet)",
"IU": "Turbin", "IV": "Aggregatenhet", "JF": "Forsterker", "JK": "Kompressor", "JP": "Pumpe", "JQ": "Pumpe i VA-installasjoner", "JV": "Vifte",
"JW": "Spesialvifte", "KA": "Aktuator", "KD": "Drivhjul - Drev", "KE": "Induktiv energioverføring", "KG": "Gjennomføring",
"KH": "Transportenhet (hevende forflyttende)", "KJ": "Jordingskomponenter", "KK": "Kanal", "KM": "Mast - Antenne", "KN": "Nedløp",
"KO": "Kraftoverføring", "KQ": "Rør - spesielt", "KR": "Rør - generelt", "KS": "Skinne - Bane - Spor", "KU": "Kombinert kabel",
"KV": "Høyspenningskabel > 1000V", "KW": "Lavspenningskabel 50 til 1000V", "KX": "Lavspenningskabel < 50V", "KY": "Optisk kabel",
"KZ": "Slange", "LB": "Varmeomformende med vifte", "LC": "Kjøleomformende med vifte", "LD": "Kjøleflater", "LE": "Kondensator",
"LF": "Fordamper", "LG": "Gear clutch", "LH": "Varmeflate", "LI": "Varmeelement", "LK": "Kjøleomformende", "LL": "Lyskilde",
"LN": "Likeretter", "LO": "Omformer", "LP": "Pens - Veksel - Sjalter", "LQ": "Vekselretter", "LR": "Frekvensomformer",
"LS": "Strålevarme", "LU": "Luftfukter", "LV": "Varmeomformende", "LX": "Varmegjenvinner", "LZ": "Varmerkabel - Varmerør",
"MA": "Absoluttfilter", "MB": "ABC-filter", "MC": "UV-filter", "ME": "Elektrostatiske filter", "MF": "Luftfilter", "MG": "Fettfilter",
"MK": "Kondenspotte", "ML": "Luftutskiller", "MM": "Membran", "MO": "Utskiller", "MR": "Rist - Sil", "MS": "Syklon", "MT": "Tørke",
"MU": "Filter for Lyd - Bilde - Frekvensutjevner", "MV": "Vannfilter", "MX": "Støyfilter", "NB": "Batteri - UPS", "NC": "Kondensator",
"NI": "Informasjonslagring", "NK": "Kum", "NM": "Badekar - Basseng", "NO": "Åpen tank", "NT": "Tank med trykk", "NU": "Tank uten trykk",
"NV": "Vekt Lodd", "NW": "Varmtvannsbereder", "NX": "Toalett", "NY": "Servant", "NZ": "Brannslukkingsapparat", "OA": "AV-maskiner",
"OB": "Shuntgruppe", "OD": "Datamaskin", "OE": "Energimåler", "OF": "Systembærer", "OM": "Mottaker - Sender", "OP": "PBX",
"OQ": "Dataprogramprogramvare", "OR": "Router Fordeler", "OS": "Sentralenhet Mikser i Lydsystem", "OT": "Telefonapparat",
"OU": "Undersentral", "QB": "Belastningsvakt", "QD": "Differansetrykkvakt", "QE": "Elektrisk vern", "QF": "Strømningsvakt",
"QH": "Fuktvakt", "QL": "Lyddemper", "QM": "Mekanisk beskyttelse", "QN": "Nivåvakt", "QO": "Overtrykksventil", "QP": "Trykkvakt",
"QQ": "Vibrasjonsvakt", "QR": "Rotasjonsvakt", "QS": "Strømvakt", "QT": "Temperaturvakt", "QV": "Sikkerhetsventil", "QX": "Solavskjerming",
"QY": "Lynavleder", "QZ": "Brannvern", "RA": "AV-opptaker", "RB": "Bevegelse", "RC": "Seismometer", "RD": "Differansetrykkgiver",
"RE": "Elektriske variabler", "RF": "Strømningsmåler", "RG": "Posisjon - Lengde", "RH": "Fuktighetsgiver", "RI": "Termometer",
"RJ": "Fotocelle", "RK": "Kortleser", "RM": "Multifunksjonell Kombinert føler", "RN": "Nivågiver", "RP": "Trykkgiver",
"RQ": "Manometer Trykkmåler", "RR": "Giver generelt", "RS": "Hastighetsmåler", "RT": "Temperaturgiver", "RU": "Ur", "RV": "Veieceller",
"RW": "Virkningsgradsmåler", "RX": "Målepunkt", "RY": "Gassdetektor-Røykdetektor", "RZ": "Branndeteksjon",
"SA": "Reguleringsventil manuell", "SB": "Reguleringsventil motorstyrt", "SC": "Stengeventil motorstyrt",
"SD": "Alarmventil sprinkler", "SE": "Ekspansjonsventil", "SF": "Fraluftsventil", "SG": "Tilbakeslagsventil - Overtrykkspjeld",
"SH": "Hurtigkobling", "SI": "Effektregulator", "SJ": "Jevntrykksventil", "SM": "Stengeventil manuell", "SP": "Trykkutjevningsventil",
"SQ": "Strømningsregulator - VAV", "SR": "Reguleringsspjeld", "SS": "Stengespjeld", "ST": "Tilluftsventil", "SU": "Sugetrykksventil",
"SV": "Strupeventil", "SW": "Plenumskammer", "SX": "Regulator", "SZ": "Brannspjeld - Røyks-p-j-e-l-d",
"UA": "Uttak alarm", "UD": "Uttak data", "UE": "Uttak el", "UF": "Fellesuttak", "UG": "Uttak gass", "UK": "Kontrollpanel - Tablå",
"UL": "Uttak trykkluft", "UM": "Monitor - Display", "UN": "Nødbelysning", "UO": "Trommel", "UP": "Belysningsarmatur", "UR": "Uttak radio",
"US": "Stasjon", "UT": "Uttak telefon", "UV": "Uttak vann", "UX": "Koblingsboks", "UY": "Uttak antenne", "UZ": "Dyse - Spreder",
"VB": "Bærelag", "VD": "Dekke", "VG": "Gress", "VK": "Kantstein heller", "VL": "Masse", "VM": "Mekanisk beskyttelse", "VP": "Planterbuskertrær",
"VS": "Skilt", "XC": "Kondensator", "XD": "Komp. for binærlogikk", "XF": "Komponenter for vern", "XG": "Komponenter for krafttilførsel",
"XH": "Komponenter for signalering", "XI": "Potensiometer", "XK": "Releer - Kontaktorer", "XL": "Induktiv komponenter", "XM": "Motor",
"XN": "Integrerte kretser", "XO": "Urbryter - Timer", "XP": "Komponenter for måling og prøving", "XQ": "Effektbryter", "XR": "Motstand",
"XS": "Bryter / Vender", "XT": "Transformator", "XV": "Halvlederkomponenter og elektronrør", "XX": "Rekkeklemmer - Samlesignal",
"XZ": "Terminering og tilpasning"}

class RegexCounts:
    pass

DEFAULT_FAGMODELL_PATH = os.environ.get(
    "PROSJEKTBASEN_FAGMODELL",
    os.path.join(DATA_DIR, "models", "fag_model.joblib")
)

_fag_model_cache = {"loaded": False, "model": None, "error": None}

def get_fag_model(path: Optional[str] = None):
    global _fag_model_cache
    if _fag_model_cache["loaded"]:
        return _fag_model_cache["model"]

    model_path = path or DEFAULT_FAGMODELL_PATH
    try:
        import importlib
        main_mod = importlib.import_module("__main__")
        if not hasattr(main_mod, "RegexCounts"):
            setattr(main_mod, "RegexCounts", RegexCounts)

        _fag_model_cache["model"] = joblib.load(model_path)
        _fag_model_cache["loaded"] = True
        return _fag_model_cache["model"]
    except Exception as e:
        _fag_model_cache["error"] = e
        _fag_model_cache["loaded"] = True
        parser_logger.error("Fag-modell feilet: %s", e)
        return None

def build_parser_from_format(format_str: str, custom_rules: Optional[Dict] = None) -> re.Pattern:
    parser_logger.info(f"--- Building parser ---")
    parser_logger.info(f"Format string: {format_str}")
    parser_logger.info(f"Custom rules: {custom_rules}")

    if not format_str:
        parser_logger.warning("No format string provided, using fallback.")
        return re.compile(r"-?(?P<komponent>([A-Za-z]{2,4})[A-Za-z0-9]{0,6}\d{2,5}[A-Za-z0-9/]*)", re.IGNORECASE)

    custom_rules = custom_rules or {}
    default_patterns = {
        'byggnr': r'[A-Z0-9]+',
        'system': r'[\d.:/]+',
        'komponent': r'[A-Za-z]{2,4}[A-Za-z0-9]{0,6}\d{2,5}[A-Za-z0-9/]*',
        'typekode': r'[A-Z0-9./:_-]+',
        'custom': r'[^\s]+',
    }

    separator_map = {
        'byggnr': r'\s*\+\s*', 
        'system': r'\s*=\s*', 
        'komponent': r'\s*-\s*', 
        'typekode': r'\s*%\s*', 
    }

    regex_pattern = ''
    temp_format = format_str
    placeholders = re.findall(r'({(.*?)})', temp_format)

    if not placeholders:
        parser_logger.info(f"No placeholders found, treating as literal search for: {format_str}")
        return re.compile(re.escape(format_str), re.IGNORECASE)

    for placeholder, key in placeholders:
        literal, _, rest = temp_format.partition(placeholder)
        if literal:
            regex_pattern += re.escape(literal)
        
        if key in separator_map:
            regex_pattern += f'(?:{separator_map[key]})?'

        user_pattern = custom_rules.get(key)
        pattern = user_pattern.lstrip('+-=% ') if user_pattern else default_patterns.get(key, r'\S+')
        
        regex_pattern += f'(?P<{key}>{pattern})'
        temp_format = rest

    if temp_format:
        regex_pattern += re.escape(temp_format)

    parser_logger.info(f"Generated regex pattern: {regex_pattern}")

    try:
        return re.compile(regex_pattern, re.IGNORECASE)
    except re.error as e:
        parser_logger.error(f"Invalid regex: {e}, falling back to default.")
        return re.compile(r"-?(?P<komponent>([A-Za-z]{2,4})[A-Za-z0-9]{0,6}\d{2,5}[A-Za-z0-9/]*)", re.IGNORECASE)

def get_unique_system_id(system_string: Optional[str]) -> str:
    if not system_string: return "Uspesifisert"
    s = system_string.strip()
    m = re.search(r'\b(\d{3,4}\.\d{3,4})\b', s)
    if m: return m.group(1)
    m2 = re.match(r'^\d+(?:\.\d+)?', s)
    return m2.group(0) if m2 else "Uspesifisert"

def extract_text_from_file(file_storage):
    filename = (file_storage.filename or "").lower()
    try:
        file_storage.seek(0)
    except Exception:
        pass

    if filename.endswith((".csv", ".txt")):
        try:
            return file_storage.read().decode("utf-8-sig")
        except Exception:
            try:
                file_storage.seek(0)
            except Exception:
                pass
            return file_storage.read().decode("latin-1", errors="ignore")

    file_bytes = file_storage.read()
    bio = io.BytesIO(file_bytes)

    if filename.endswith(".pdf"):
        try:
            doc = fitz.open(stream=bio, filetype="pdf")
            return "".join([p.get_text() for p in doc])
        except Exception:
            return ""

    if filename.endswith(".docx"):
        try:
            d = docx.Document(bio)
            return "\n".join(p.text for p in d.paragraphs)
        except Exception:
            return ""

    if filename.endswith(".xlsx"):
        try:
            wb = load_workbook(bio, data_only=True)
            lines = []
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    parts = [str(c) for c in row if c is not None]
                    if parts:
                        lines.append(" ".join(parts))
            return "\n".join(lines)
        except Exception:
            return ""

    return ""

@bp.route("/generate_underlag", methods=["POST"])
@login_required
def generate_underlag():
    parser_logger.info("--- generate_underlag called ---")
    files = request.files.getlist("files")
    raw_criteria = (request.form.get("system_kriterier") or "").strip()
    allowed_prefixes = [s for s in re.split(r"[\,\s]+", raw_criteria) if s]
    format_str = request.form.get("format", "{komponent}")
    custom_rules = {k.replace('custom_rule_', ''): v for k, v in request.form.items() if k.startswith('custom_rule_')}

    parser = build_parser_from_format(format_str, custom_rules)

    def _allowed(uid: str) -> bool:
        if not allowed_prefixes: return True
        return any(str(uid or "").startswith(pref) for pref in allowed_prefixes)

    files_mem = [(f.filename, f.read()) for f in files if f and f.filename]

    def tfm_prefix_from_component(komp: str) -> str:
        if not komp: return ""
        letters = re.match(r"^[A-Za-z]{2,}", komp)
        return (letters.group(0)[:2].upper()) if letters else ""

    def generate():
        all_rows = []
        for filename, file_bytes in files_mem:
            yield f'data: {json.dumps({"currentFile": filename})}\n\n'
            try:
                class _FS:
                    def __init__(self, name, data):
                        self.filename = name
                        self._bio = io.BytesIO(data)
                    def read(self): return self._bio.read()
                    def seek(self, pos): self._bio.seek(pos)

                text = extract_text_from_file(_FS(filename, file_bytes))
                matches = list(parser.finditer(text))
                parser_logger.info(f"Found {len(matches)} matches in {filename}")
                for m in matches:
                    gd = m.groupdict()
                    komponent = gd.get("komponent")
                    if not komponent: continue

                    uid = get_unique_system_id(gd.get("system"))
                    if not _allowed(uid):
                        continue

                    tfm_key = tfm_prefix_from_component(komponent)
                    desc = TFM_DICT.get(tfm_key, "Ukjent beskrivelse")

                    all_rows.append({
                        "source": filename,
                        "unique_system": uid,
                        "full_id": m.group(0),
                        "komponent": komponent.strip().upper(),
                        "desc": desc
                    })
            except Exception as e:
                msg = f"Feil under {filename}: {type(e).__name__}: {e}"
                yield f'data: {json.dumps({"error": msg})}\n\n'
        yield f'data: {json.dumps({"rows": all_rows})}\n\n'
    return Response(stream_with_context(generate()), mimetype="application/x-ndjson")

@bp.route("/api/tfm-liste")
@login_required
def hent_tfm_liste():
    funksjon = request.args.get("funksjon", "").upper()
    mapping = {
        "MC": "tfm-settings-mc.json",
        "FUNKSJONSTEST": "tfm-settings-funksjonstest.json",
        "INNREGULERING": "tfm-settings-innregulering.json"
    }
    if funksjon not in mapping:
        return jsonify({"error": "Ugyldig funksjonstype"}), 400
    settings_path = os.path.abspath(os.path.join(basedir, "..", "static", "data", mapping[funksjon]))
    try:
        with open(settings_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp.route("/api/tfm-liste/save", methods=["POST"])
@login_required
def lagre_tfm_liste():
    data = request.get_json()
    funksjon = request.args.get("funksjon", "mc").lower()
    if not data:
        return jsonify({"error": "Manglende data"}), 400
    filnavn = f"tfm-settings-{funksjon}.json"
    path = os.path.join(current_app.static_folder, "data", filnavn)
    try:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        return jsonify({"status": "ok"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@bp.route("/api/users")
@login_required
def api_users():
    users = User.query.filter_by(approved=True).all()
    return jsonify([f"{u.first_name} {u.last_name}" for u in users])

@bp.route("/api/technicians")
@login_required
def api_technicians():
    techs = User.query.filter_by(role="tekniker", approved=True).all()
    return jsonify([f"{t.first_name} {t.last_name}" for t in techs])

@bp.route("/api/me")
@login_required
def api_me():
    return f"{current_user.first_name} {current_user.last_name}"

@bp.route("/")
@login_required
def index():
    return render_template("protokoller.html")

_FUNKBANK_CACHE = {"mtime": None, "data": {}}

def _funbank_excel_path():
    return os.path.join(DATA_DIR, "Funksjonstest_db.xlsx")

def _load_bank_from_excel(selected=None):
    xlsx_path = _funbank_excel_path()
    if not os.path.exists(xlsx_path):
        return {}
    mtime = os.path.getmtime(xlsx_path)
    if _FUNKBANK_CACHE["mtime"] != mtime:
        wb = load_workbook(xlsx_path, data_only=True)
        data = {}
        for ws in wb.worksheets:
            code = (ws.title or "").strip().upper()
            if not code: 
                continue
            rows = list(ws.iter_rows(values_only=True))
            if not rows:
                continue
            header0 = str(rows[0][0]).lower() if rows and rows[0] and rows[0][0] else ""
            start_idx = 1 if any(k in header0 for k in ["beskrivelse", "navn"]) else 0
            bank = []
            for row in rows[start_idx:]:
                if not row or not any(row):
                    continue
                navn = (str(row[0]).strip() if len(row) > 0 and row[0] else "")
                test = (str(row[1]).strip() if len(row) > 1 and row[1] else "")
                aksept = (str(row[2]).strip() if len(row) > 2 and row[2] else "")
                if not (navn or test or aksept):
                    continue
                bank.append({"navn": navn, "test": test, "aksept": aksept})
            if bank:
                data[code] = bank
        _FUNKBANK_CACHE["data"] = data
        _FUNKBANK_CACHE["mtime"] = mtime
    if selected:
        wanted = {t.strip().upper() for t in selected if t and t.strip()}
        return {k: v for k, v in _FUNKBANK_CACHE["data"].items() if k in wanted}
    return _FUNKBANK_CACHE["data"]

PASTELL_LYSEBLAA = "DCEBFF"
SECTION_ORDER = ["Start og Stopp funksjoner", "Reguleringsfunksjoner", "Sikkerhetsfunksjoner", "Øvrig"]

def insert_section_header(ws, row_index: int, title: str):
    to_unmerge = []
    for mr in list(ws.merged_cells.ranges):
        if mr.min_row <= row_index <= mr.max_row:
            to_unmerge.append(mr)
    for mr in to_unmerge:
        ws.unmerge_cells(str(mr))
    max_col = max(14, ws.max_column)
    for col in range(1, max_col + 1):
        ws.cell(row=row_index, column=col, value=None)
    ws.merge_cells(start_row=row_index, start_column=1, end_row=row_index, end_column=14)
    c = ws.cell(row=row_index, column=1, value=title)
    c.fill = PatternFill(fill_type="solid", start_color=PASTELL_LYSEBLAA, end_color=PASTELL_LYSEBLAA)
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    c.font = Font(bold=True)

def add_betingelser(worksheet):
    conditions_text = [
        "",
        "Kontroll av protokoll",
        "Dokumentasjon må overleveres før igangkjøring av anlegg.",
        "Protokollen skal fylles ut og signeres av utførende montør.",
        "Protokollen skal fylles ut og signeres av kontrollør som kontrollerer arbeidet.",
        "Dokumentasjonen skal fylles ut fortløpende avhengig av fremdrift i prosjektet."
    ]
    start_row = 202
    for i, line in enumerate(conditions_text):
        worksheet.cell(row=start_row + i, column=1, value=line)
        if line:
            worksheet.merge_cells(start_row=start_row + i, start_column=1, end_row=start_row + i, end_column=9)
            worksheet.cell(row=start_row + i, column=1).font = Font(bold=True)
            worksheet.cell(row=start_row + i, column=1).alignment = Alignment(wrapText=True)
