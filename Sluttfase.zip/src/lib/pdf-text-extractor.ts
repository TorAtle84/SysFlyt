import * as fs from 'fs';
import * as path from 'path';
import { pathToFileURL } from 'url';

// Polyfill Promise.withResolvers (required by pdfjs-dist v4+)
if (typeof Promise.withResolvers === 'undefined') {
    (Promise as any).withResolvers = function () {
        let resolve, reject;
        const promise = new Promise((res, rej) => {
            resolve = res;
            reject = rej;
        });
        return { promise, resolve, reject };
    };
}

// Polyfill DOMMatrix for Node.js environment (required by pdfjs-dist v4+)
if (typeof DOMMatrix === 'undefined') {
    (global as any).DOMMatrix = class DOMMatrix {
        a = 1; b = 0; c = 0; d = 1; e = 0; f = 0;
        constructor(init?: string | number[]) {
            if (Array.isArray(init)) {
                this.a = init[0]; this.b = init[1];
                this.c = init[2]; this.d = init[3];
                this.e = init[4]; this.f = init[5];
            }
        }
    };
}

export interface TextItem {
    text: string;
    x: number; // Percentage 0-100
    y: number; // Percentage 0-100
    width: number;
    height: number;
    page: number; // 1-based page number
}

/**
 * Extract text items with coordinates from a PDF file
 * @param pdfPath - Absolute path to the PDF file or URL
 * @returns Array of text items with coordinates
 */
export async function extractTextWithCoordinates(
    pdfPath: string
): Promise<TextItem[]> {
    try {
        // Dynamically import pdfjs-dist to ensure polyfills run first
        const pdfjsLib = await import('pdfjs-dist');

        // Set worker source to local file path for Node.js
        // This is crucial for the "fake worker" to load the worker script correctly
        const workerPath = path.join(process.cwd(), 'node_modules', 'pdfjs-dist', 'build', 'pdf.worker.mjs');
        pdfjsLib.GlobalWorkerOptions.workerSrc = pathToFileURL(workerPath).href;

        // Load PDF
        const buffer = fs.readFileSync(pdfPath);
        const data = new Uint8Array(buffer);
        const loadingTask = pdfjsLib.getDocument({ data });
        const pdfDocument = await loadingTask.promise;

        const allTextItems: TextItem[] = [];

        // Process each page
        for (let pageNum = 1; pageNum <= pdfDocument.numPages; pageNum++) {
            const page = await pdfDocument.getPage(pageNum);
            const textContent = await page.getTextContent();
            // Use default rotation (usually respects metadata)
            const viewport = page.getViewport({ scale: 1.0 });
            const { width, height } = viewport;

            // Log Viewport and CropBox (view) details
            const view = page.view; // This is the CropBox [x, y, w, h]
            const logMsg = `\n[TextExtraction] Page ${pageNum} Viewport: ${width}x${height}, Rotation: ${viewport.rotation}, viewBox: [${view.join(',')}]\n`;
            fs.appendFileSync(path.join(process.cwd(), 'debug_log.txt'), logMsg);

            for (const item of textContent.items) {
                if ('str' in item && item.str.trim()) {
                    // Calculate coordinates using the transform matrix to handle rotation and height correctly
                    const tx = item.transform;
                    // tx is [a, b, c, d, x, y]
                    // (0,0) is the baseline start.
                    // (width, 0) is the baseline end.
                    // (0, height) is the top start.
                    // (width, height) is the top end.

                    // We need the font height. item.height is often the font size.
                    // If item.height is missing or 0, we default to a reasonable value relative to width or just 0.
                    const fontHeight = item.height || 0;

                    // Helper to apply PDF transform then Viewport transform
                    const transformPoint = (px: number, py: number) => {
                        // Apply PDF transform (a, b, c, d, tx, ty)
                        // x' = a*px + c*py + tx
                        // y' = b*px + d*py + ty
                        const pdfX = tx[0] * px + tx[2] * py + tx[4];
                        const pdfY = tx[1] * px + tx[3] * py + tx[5];
                        return viewport.convertToViewportPoint(pdfX, pdfY);
                    };

                    // Calculate 4 corners of the text box
                    const corners = [
                        transformPoint(0, 0),              // Bottom-Left (Baseline Start)
                        transformPoint(item.width, 0),     // Bottom-Right (Baseline End)
                        transformPoint(item.width, fontHeight), // Top-Right
                        transformPoint(0, fontHeight)      // Top-Left
                    ];

                    // Find bounding box in Viewport pixels
                    const xs = corners.map(c => c[0]);
                    const ys = corners.map(c => c[1]);
                    const minX = Math.min(...xs);
                    const maxX = Math.max(...xs);
                    const minY = Math.min(...ys);
                    const maxY = Math.max(...ys);

                    const widthPx = maxX - minX;
                    const heightPx = maxY - minY;

                    // Convert to percentages (0-100)
                    const x = (minX / width) * 100;
                    const y = (minY / height) * 100;
                    const w = (widthPx / width) * 100;
                    const h = (heightPx / height) * 100;

                    // Log debug info for specific components
                    if (item.str.includes('KA001T/003') || item.str.includes('RT016T/010') || item.str.includes('JP033T/004')) {
                        const logMsg = `\n🕵️ DEBUG TARGET: ${item.str}\n   - Page: ${pageNum}\n   - Transform: [${tx.join(', ')}]\n   - Viewport BBox: [${minX.toFixed(1)}, ${minY.toFixed(1)}, ${widthPx.toFixed(1)}, ${heightPx.toFixed(1)}]\n   - Calculated: x=${x.toFixed(2)}%, y=${y.toFixed(2)}%, w=${w.toFixed(2)}%, h=${h.toFixed(2)}%\n`;
                        fs.appendFileSync(path.join(process.cwd(), 'debug_log.txt'), logMsg);
                    }

                    allTextItems.push({
                        text: item.str,
                        x,
                        y,
                        width: w,
                        height: h,
                        page: pageNum
                    });
                }
            }
        }

        return allTextItems;
    } catch (error) {
        console.error('Failed to extract text with coordinates:', error);
        throw error;
    }
}
