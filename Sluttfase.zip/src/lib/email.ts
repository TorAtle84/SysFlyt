import nodemailer from "nodemailer";

const host = process.env.SMTP_HOST;
const port = process.env.SMTP_PORT ? parseInt(process.env.SMTP_PORT, 10) : 587;
const user = process.env.SMTP_USER;
const pass = process.env.SMTP_PASS;
const from = process.env.SMTP_FROM || user;

export function getTransporter() {
  if (!host || !user || !pass) {
    console.warn("SMTP config mangler - bruker mock-transporter (logger til konsoll)");
    return {
      sendMail: async (opts: any) => {
        console.log("--- MOCK EMAIL ---");
        console.log("To:", opts.to);
        console.log("Subject:", opts.subject);
        console.log("HTML:", opts.html);
        console.log("------------------");
        return true;
      },
    } as any;
  }
  return nodemailer.createTransport({
    host,
    port,
    secure: port === 465,
    auth: { user, pass },
  });
}

export async function sendResetEmail(to: string, resetUrl: string) {
  const transporter = getTransporter();
  await transporter.sendMail({
    from,
    to,
    subject: "Tilbakestill passord - SLUTTFASE",
    html: `
      <p>Hei,</p>
      <p>Du ba om å tilbakestille passordet ditt. Klikk lenken under (gyldig i 1 time):</p>
      <p><a href="${resetUrl}">${resetUrl}</a></p>
      <p>Hvis du ikke ba om dette, kan du ignorere e-posten.</p>
    `,
  });
}
