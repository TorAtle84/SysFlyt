import { MassList } from "@prisma/client";
import { parseComponentIds, ParsedComponentId } from "./id-pattern";

export type ScanResult = {
  components: ParsedComponentId[];
  uniqueCount: number;
};

export function scanDocumentForComponents(
  content: string,
  systemTags: string[] = []
): ScanResult {
  const components = parseComponentIds(content || "", systemTags);
  const unique = new Set(components.map((c) => c.full));
  return { components, uniqueCount: unique.size };
}

export function verifyAgainstMassList(
  scanned: ParsedComponentId[],
  massList: MassList[]
) {
  const massCodes = new Set(massList.map((m) => m.code));
  const scannedCodes = new Set(scanned.map((c) => c.full));

  const missingInDrawing = massList.filter((m) => !scannedCodes.has(m.code));
  const missingInMassList = scanned.filter((c) => !massCodes.has(c.full));

  return { missingInDrawing, missingInMassList };
}
