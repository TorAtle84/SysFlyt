import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export const adminEmails = ["tm5479@gk.no", "flytlink.app@gmail.com"];

export function titleCase(value: string) {
  return value
    .split(" ")
    .map((v) => v.charAt(0).toUpperCase() + v.slice(1).toLowerCase())
    .join(" ");
}

export function stringToColor(str: string) {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    hash = str.charCodeAt(i) + ((hash << 5) - hash);
  }
  const c = (hash & 0x00ffffff).toString(16).toUpperCase();
  return "#" + "00000".substring(0, 6 - c.length) + c;
}
