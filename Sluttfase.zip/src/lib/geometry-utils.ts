/**
 * Geometry utility functions for spatial calculations
 */

/**
 * Check if a point is inside a polygon using ray casting algorithm
 * @param point - {x, y} coordinates of the point
 * @param polygon - Array of {x, y} points defining the polygon vertices
 * @returns true if point is inside polygon, false otherwise
 */
export function pointInPolygon(
    point: { x: number; y: number },
    polygon: { x: number; y: number }[]
): boolean {
    let inside = false;
    const x = point.x;
    const y = point.y;

    for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
        const xi = polygon[i].x;
        const yi = polygon[i].y;
        const xj = polygon[j].x;
        const yj = polygon[j].y;

        const intersect =
            yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi;

        if (intersect) inside = !inside;
    }

    return inside;
}

/**
 * Check if a point is inside a rectangle
 * @param point - {x, y} coordinates of the point
 * @param rect - {x, y, width, height} defining the rectangle
 * @returns true if point is inside rectangle, false otherwise
 */
export function pointInRect(
    point: { x: number; y: number },
    rect: { x: number; y: number; width: number; height: number }
): boolean {
    return (
        point.x >= rect.x &&
        point.x <= rect.x + rect.width &&
        point.y >= rect.y &&
        point.y <= rect.y + rect.height
    );
}
