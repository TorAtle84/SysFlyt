import { Role } from "@prisma/client";

export const rolePermissions: Record<Role, string[]> = {
  [Role.ADMIN]: ["approve_users", "assign_roles", "delete_all", "projects_write", "comment", "invite"],
  [Role.PROJECT_LEADER]: ["projects_write", "comment", "invite"],
  [Role.USER]: ["update_status", "comment"],
  [Role.READER]: ["read_only"],
};

export function hasPermission(role: Role, permission: string) {
  const perms = rolePermissions[role] || [];
  return perms.includes(permission) || role === Role.ADMIN;
}
