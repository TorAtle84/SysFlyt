export type ParsedComponentId = {
  full: string;
  bygg: string | null;
  system: string;
  component: string;
  typeCode: string | null;
};

// TFM: +256=3601.0001-RTA4001%RTA0001
// Simplified: 360.001-RT401

// Regex for TFM:
// Group 1: Bygg (+256)
// Group 2: System (=3601.0001) - capture without =
// Group 3: Component (-RTA4001) - capture without -
// Group 4: Type (%RTA0001) - capture without %
const tfmRegex = /(\+\w+)=([\w.]+)-([\w]+)(?:%([\w]+))?/g;

// Regex for Simplified:
// Group 1: System (360.001)
// Group 2: Component (RT401)
// Group 3: Type (optional, if present)
const simpleRegex = /\b(\d{3,4}(?:\.\d+)*)-([A-Za-z]{2,3}\d+[\w]*)(?:%([\w]+))?/g;

export function parseComponentIds(content: string, systemFilter?: string[]): ParsedComponentId[] {
  const matches: ParsedComponentId[] = [];
  const filterSet = systemFilter?.length ? new Set(systemFilter) : null;

  // 1. Try TFM
  for (const match of content.matchAll(tfmRegex)) {
    const [full, bygg, system, component, typeCode] = match;
    if (filterSet && !filterSet.has(system)) {
      continue;
    }
    matches.push({
      full,
      bygg,
      system,
      component,
      typeCode: typeCode || null,
    });
  }

  // 2. Try Simplified
  for (const match of content.matchAll(simpleRegex)) {
    const [full, system, component, typeCode] = match;
    // Avoid duplicates if TFM already caught it (TFM is stricter)
    if (matches.some((m) => m.full.includes(full))) continue;

    if (filterSet && !filterSet.has(system)) {
      continue;
    }
    matches.push({
      full,
      bygg: null,
      system,
      component,
      typeCode: typeCode || null,
    });
  }

  return matches;
}
