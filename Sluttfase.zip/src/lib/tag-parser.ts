export function parseSystemTags(text: string): string[] {
    const tags: Set<string> = new Set();

    // Rule 1: TFM Style (+Bygg=System-Component%Type)
    // Extract the System part (e.g., 360.001 from +Bygg=360.001-RT401)
    const tfmRegex = /\+(\w+)=([\d]+\.[\d]+)-/g;
    let match;
    while ((match = tfmRegex.exec(text)) !== null) {
        if (match[2]) tags.add(match[2]);
    }

    // Rule 2: System-Component format (e.g., 360.001-RT401)
    // Extract just the System part (360.001)
    const systemComponentRegex = /([\d]{3,4}(?:\.[\d]+)+)-([A-Za-z]{2,4}[\d]+)/g;
    while ((match = systemComponentRegex.exec(text)) !== null) {
        if (match[1]) tags.add(match[1]);
    }

    // Rule 3: Standalone system codes (e.g., =360.001 or just 360.001)
    // Must be 3-4 digits, followed by dot, followed by more digits
    // Must start with building system range (3-7 hundreds)
    const standaloneSystemRegex = /\b([3-7][\d]{2,3}\.[\d]+)\b/g;
    while ((match = standaloneSystemRegex.exec(text)) !== null) {
        tags.add(match[1]);
    }

    return Array.from(tags);
}
