import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";
import { Role } from "@prisma/client";

async function getUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  return prisma.user.findUnique({ where: { email: session.user.email } });
}

type Context = { params: Promise<{ projectId: string }> };

export async function POST(req: NextRequest, context: Context) {
  const actor = await getUser();
  if (!actor) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  if (!(actor.role === Role.ADMIN || actor.role === Role.PROJECT_LEADER)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const { email, role } = body || {};
  if (!email) return NextResponse.json({ error: "E-post mangler" }, { status: 400 });

  const invitee = await prisma.user.findUnique({ where: { email: email.toLowerCase() } });
  if (!invitee) return NextResponse.json({ error: "Bruker finnes ikke" }, { status: 404 });

  const { projectId } = await context.params;
  const project = await prisma.project.findUnique({ where: { id: projectId } });
  if (!project) return NextResponse.json({ error: "Prosjekt ikke funnet" }, { status: 404 });

  const member = await prisma.projectMember.upsert({
    where: {
      projectId_userId: { projectId: project.id, userId: invitee.id },
    },
    update: {
      role: role && Object.values(Role).includes(role) ? role : Role.USER,
    },
    create: {
      projectId: project.id,
      userId: invitee.id,
      role: role && Object.values(Role).includes(role) ? role : Role.USER,
    },
    include: { user: true },
  });

  return NextResponse.json(member);
}
