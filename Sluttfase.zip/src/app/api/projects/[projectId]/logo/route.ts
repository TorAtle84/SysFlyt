import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import { canWrite } from "@/app/api/projects/[projectId]/route";
import { NextResponse } from "next/server";
import { promises as fs } from "fs";
import path from "path";

type Context = { params: Promise<{ projectId: string }> };

const logFile = path.join(process.cwd(), "debug-logo.txt");

async function logToFile(message: string) {
    const timestamp = new Date().toISOString();
    const logMessage = `[${timestamp}] ${message}\n`;
    try {
        await fs.appendFile(logFile, logMessage);
    } catch (e) {
        console.error("Failed to write to log file:", e);
    }
}

export async function POST(req: Request, context: Context) {
    try {
        await logToFile("Starting logo upload request");
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) {
            await logToFile("Unauthorized: No session");
            return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
        }

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) {
            await logToFile("User not found");
            return NextResponse.json({ error: "User not found" }, { status: 404 });
        }
        if (!canWrite(user.role)) {
            await logToFile(`Forbidden: User role ${user.role}`);
            return NextResponse.json({ error: "Forbidden" }, { status: 403 });
        }

        const { projectId } = await context.params;
        await logToFile(`Processing project: ${projectId}`);

        const project = await prisma.project.findUnique({ where: { id: projectId } });
        if (!project) {
            await logToFile("Project not found");
            return NextResponse.json({ error: "Project not found" }, { status: 404 });
        }

        await logToFile("Reading form data...");
        const form = await req.formData();
        const file = form.get("logo") as File | null;
        if (!file) {
            await logToFile("No file provided in form data");
            return NextResponse.json({ error: "No file provided" }, { status: 400 });
        }

        await logToFile(`File received: ${file.name}, size: ${file.size}, type: ${file.type}`);

        const arrayBuffer = await file.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        const ext = path.extname(file.name) || ".png";
        const filename = `${projectId}-${Date.now()}${ext}`;
        const uploadDir = path.join(process.cwd(), "public", "uploads");
        const uploadPath = path.join(uploadDir, filename);

        await logToFile(`Writing file to: ${uploadPath}`);

        // Ensure directory exists
        try {
            await fs.mkdir(uploadDir, { recursive: true });
        } catch (err) {
            await logToFile(`Failed to create directory: ${err}`);
        }

        await fs.writeFile(uploadPath, buffer);
        await logToFile("File written successfully");

        const updated = await prisma.project.update({
            where: { id: projectId },
            data: { logoUrl: `/uploads/${filename}` },
        });

        await logToFile("Database updated");
        return NextResponse.json(updated);
    } catch (error) {
        await logToFile(`CRITICAL ERROR: ${error}`);
        console.error("Logo upload CRITICAL error:", error);
        return NextResponse.json({ error: "Internal Server Error", details: String(error) }, { status: 500 });
    }
}

export async function DELETE(req: Request, context: Context) {
    try {
        const session = await getServerSession(authOptions);
        if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

        const user = await prisma.user.findUnique({ where: { email: session.user.email } });
        if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });
        if (!canWrite(user.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

        const { projectId } = await context.params;

        // Get current project to find logo file
        const project = await prisma.project.findUnique({ where: { id: projectId } });
        if (!project) return NextResponse.json({ error: "Project not found" }, { status: 404 });

        // Try to delete the file if it exists
        if (project.logoUrl) {
            const filePath = path.join(process.cwd(), "public", project.logoUrl);
            try {
                await fs.unlink(filePath);
            } catch (err) {
                console.warn("Could not delete logo file:", err);
            }
        }

        const updated = await prisma.project.update({
            where: { id: projectId },
            data: { logoUrl: null },
        });

        return NextResponse.json(updated);
    } catch (error) {
        console.error("Logo delete error:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}
