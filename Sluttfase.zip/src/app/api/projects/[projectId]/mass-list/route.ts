import { NextRequest, NextResponse } from "next/server";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import * as XLSX from "xlsx";
import { z } from "zod";

// Schema for column mapping
const MappingSchema = z.object({
    tfm: z.string().optional(),
    productName: z.string().optional(),
    location: z.string().optional(),
    zone: z.string().optional(),
});

export async function POST(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { projectId } = await params;

    try {
        const formData = await req.formData();
        const file = formData.get("file") as File;
        const mappingJson = formData.get("mapping") as string;

        if (!file || !mappingJson) {
            return new NextResponse("Missing file or mapping", { status: 400 });
        }

        const mapping = MappingSchema.parse(JSON.parse(mappingJson));
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: "A" }) as any[];

        const massListEntries = [];

        for (const row of jsonData) {
            const tfmRaw = mapping.tfm ? row[mapping.tfm]?.toString() : undefined;

            // Skip if TFM is marked as not relevant (not provided) OR if the row doesn't have a TFM value
            if (!tfmRaw) continue;

            // Parse TFM based on strict user rules:
            // {byggnr}{system}{komponent}{typekode}
            // Byggnr: Starts with +, digits. Ends before = or end.
            // System: Starts with = (optional), digits/dots/colons. Ends before - or end.
            // Komponent: Starts with - (optional), 2-3 letters, then digits/chars. Ends before % or end.
            // Typekode: Starts with %, 2-3 letters.

            // Regex explanation:
            // ^(?<bygg>\+\d+)?                  -> Optional Bygg: + followed by digits
            // (?<system>=?[\d\.:]+)?            -> Mandatory System (usually): Optional =, then digits/dots/colons
            // (?<komponent>-?[a-zA-Z]{2,3}[^%]*)? -> Mandatory Component: Optional -, 2-3 letters, then anything until %
            // (?<type>%[a-zA-Z0-9]+)?           -> Optional Type: % followed by alphanumeric

            // Note: We use a slightly flexible regex to capture the parts if they exist.
            const tfmRegex = /^(?<bygg>\+\d+)?(?<system>=?[\d\.:]+)?(?<komponent>-?[a-zA-Z]{2,3}[^%]*)?(?<type>%[a-zA-Z0-9]+)?$/;
            const match = tfmRaw.match(tfmRegex);

            if (!match) continue;

            const groups = match.groups || {};
            let building = groups.bygg || "";
            let system = groups.system || "";
            let component = groups.komponent || "";
            let typeCode = groups.type || "";

            // Clean up delimiters from stored values
            if (building.startsWith("+")) building = building.substring(1);
            if (system.startsWith("=")) system = system.substring(1);
            if (component.startsWith("-")) component = component.substring(1);
            if (typeCode.startsWith("%")) typeCode = typeCode.substring(1);

            // Validation: Require at least System or Component
            if (!system && !component) continue;

            const productName = mapping.productName ? row[mapping.productName]?.toString() : undefined;
            const location = mapping.location ? row[mapping.location]?.toString() : undefined;
            const zone = mapping.zone ? row[mapping.zone]?.toString() : undefined;

            massListEntries.push({
                projectId,
                tfm: tfmRaw,
                productName,
                location,
                zone,
                building,
                system,
                component,
                typeCode,
            });
        }

        if (massListEntries.length > 0) {
            await prisma.massList.createMany({
                data: massListEntries,
            });
        }

        return NextResponse.json({ count: massListEntries.length });
    } catch (error) {
        console.error("Mass list upload error:", error);
        return new NextResponse("Internal Server Error", { status: 500 });
    }
}

export async function GET(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { projectId } = await params;

    const items = await prisma.massList.findMany({
        where: { projectId },
        orderBy: { createdAt: "desc" },
    });

    return NextResponse.json(items);
}

export async function DELETE(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session) return new NextResponse("Unauthorized", { status: 401 });

    const { projectId } = await params;
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");

    if (!id) {
        const all = searchParams.get("all");
        if (all === "true") {
            await prisma.massList.deleteMany({ where: { projectId } });
            return new NextResponse("Deleted all", { status: 200 });
        }
        return new NextResponse("Missing ID", { status: 400 });
    }

    await prisma.massList.delete({
        where: { id },
    });

    return new NextResponse("Deleted", { status: 200 });
}
