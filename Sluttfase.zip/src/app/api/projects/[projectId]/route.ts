import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";
import { ProjectStatus, Role } from "@prisma/client";

export async function getUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  return prisma.user.findUnique({ where: { email: session.user.email } });
}

async function getProject(id: string) {
  return prisma.project.findUnique({
    where: { id },
    include: {
      members: { include: { user: true } },
      documents: { include: { tags: { include: { systemTag: true } } } },
      massList: true,
    },
  });
}

export function canWrite(userRole: Role) {
  return userRole === Role.ADMIN || userRole === Role.PROJECT_LEADER;
}

type Context = { params: Promise<{ projectId: string }> };

export async function GET(_: NextRequest, context: Context) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { projectId } = await context.params;
  const project = await getProject(projectId);
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const isMember = project.members.some((m) => m.userId === user.id);
  if (!isMember && user.role !== Role.ADMIN) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  return NextResponse.json(project);
}

export async function PATCH(req: NextRequest, context: Context) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  if (!canWrite(user.role)) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }

  const body = await req.json();
  const { action } = body || {};

  const { projectId } = await context.params;
  const project = await prisma.project.findUnique({ where: { id: projectId } });
  if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });

  if (action === "archive") {
    const updated = await prisma.project.update({
      where: { id: project.id },
      data: { status: ProjectStatus.ARCHIVED, archivedAt: new Date() },
    });
    return NextResponse.json(updated);
  }

  if (action === "restore") {
    const updated = await prisma.project.update({
      where: { id: project.id },
      data: { status: ProjectStatus.ACTIVE, archivedAt: null },
    });
    return NextResponse.json(updated);
  }

  return NextResponse.json({ error: "Ukjent handling" }, { status: 400 });
}

export async function DELETE(_: NextRequest, context: Context) {
  try {
    const user = await getUser();
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    if (!canWrite(user.role)) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const { projectId } = await context.params;
    const project = await prisma.project.findUnique({ where: { id: projectId } });
    if (!project) return NextResponse.json({ error: "Not found" }, { status: 404 });

    if (project.status !== ProjectStatus.ARCHIVED) {
      return NextResponse.json({ error: "Kan kun slette arkiverte prosjekter" }, { status: 400 });
    }

    // Delete related data first to avoid foreign key constraints
    await prisma.$transaction([
      // Delete annotations and their comments
      prisma.comment.deleteMany({ where: { annotation: { document: { projectId } } } }),
      prisma.annotation.deleteMany({ where: { document: { projectId } } }),
      // Delete document components and tags
      prisma.documentComponent.deleteMany({ where: { document: { projectId } } }),
      prisma.documentSystemTag.deleteMany({ where: { document: { projectId } } }),
      // Delete documents
      prisma.document.deleteMany({ where: { projectId } }),
      // Delete project comments
      prisma.comment.deleteMany({ where: { projectId } }),
      // Delete mass list
      prisma.massList.deleteMany({ where: { projectId } }),
      // Delete notifications related to the project
      prisma.notification.deleteMany({ where: { comment: { projectId } } }),
      // Delete project members
      prisma.projectMember.deleteMany({ where: { projectId } }),
      // Finally delete the project
      prisma.project.delete({ where: { id: projectId } }),
    ]);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Error deleting project:", error);
    return NextResponse.json({ error: "Kunne ikke slette prosjekt" }, { status: 500 });
  }
}
