import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";
import { DocumentType } from "@prisma/client";
import { writeFile } from "fs/promises";
import * as fs from "fs";
import path from "path";

// pdf-parse is a CommonJS module, import at runtime
// const pdf = require("pdf-parse"); // Moved inside handler

async function getUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  return prisma.user.findUnique({ where: { email: session.user.email } });
}

type Context = { params: Promise<{ projectId: string }> };

export async function GET(_: NextRequest, context: Context) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { projectId } = await context.params;
  const documents = await prisma.document.findMany({
    where: { projectId },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json(documents);
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ projectId: string }> }
) {
  console.log("🔥 HIT DOCUMENT ROUTE POST");
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) {
    return NextResponse.json({ error: "Ikke autentisert" }, { status: 401 });
  }

  const { projectId } = await params;

  // Check if user is a member
  const membership = await prisma.projectMember.findFirst({
    where: { projectId, user: { email: session.user.email } },
  });
  if (!membership) {
    return NextResponse.json({ error: "Ikke tilgang" }, { status: 403 });
  }

  try {
    const formData = await req.formData();
    const file = formData.get("file") as File;
    const title = formData.get("title") as string;
    const type = (formData.get("type") as DocumentType) || DocumentType.DRAWING;

    console.log("📤 Upload request:", { title, type, fileName: file?.name, fileType: file?.type, fileSize: file?.size });

    if (!file || !title) {
      return NextResponse.json({ error: "Fil og tittel er påkrevd" }, { status: 400 });
    }

    const bytes = await file.arrayBuffer();
    const buffer = Buffer.from(bytes);

    // Extract text from PDF
    let extractedText = "";
    const isPdf = file.type === "application/pdf" || file.name.toLowerCase().endsWith('.pdf');
    console.log(`🔍 Is PDF? ${isPdf}`);

    if (isPdf) {
      try {
        console.log("🔍 Attempting PDF text extraction...");
        // Bypass index.js which has a buggy !module.parent check causing ENOENT
        const pdf = require("pdf-parse/lib/pdf-parse.js");
        console.log(`🔍 pdf-parse loaded: ${typeof pdf}`);

        const pdfData = await pdf(buffer);
        extractedText = pdfData.text || "";
        console.log(`📄 Ekstrahert ${extractedText.length} tegn fra PDF: ${title}`);
        if (extractedText.length > 0) {
          console.log(`📄 Sample: ${extractedText.substring(0, 50)}...`);
        } else {
          console.warn("⚠️ Extracted text is EMPTY");
        }
      } catch (pdfError: any) {
        console.warn("⚠️ PDF parsing failed:", pdfError?.message || pdfError);
        console.warn(pdfError.stack);
      }
    } else {
      console.warn("⚠️ Skipping PDF extraction (not a PDF)");
    }

    const filename = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.+\-=%]/g, "_")}`;

    // Map DocumentType to folder names
    const typeFolderMap: Record<DocumentType, string> = {
      [DocumentType.DRAWING]: "Arbeidstegninger",
      [DocumentType.SCHEMA]: "Systemskjema",
      [DocumentType.MASSLIST]: "Masseliste",
      [DocumentType.OTHER]: "Annet"
    };

    const folderName = typeFolderMap[type] || "Annet";
    const uploadsDir = path.join(process.cwd(), "public", "uploads", projectId, folderName);
    const filepath = path.join(uploadsDir, filename);

    // Ensure directory exists
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir, { recursive: true });
    }

    await writeFile(filepath, buffer);
    console.log(`💾 Lagret fil: ${filepath}`);

    const document = await prisma.document.create({
      data: {
        title,
        url: `/uploads/${projectId}/${folderName}/${filename}`,
        type,
        description: extractedText,
        projectId,
        systemTags: [],
        revision: 1,
        isLatest: true,
      },
    });

    console.log(`✅ Dokument opprettet: ${document.id}`);
    return NextResponse.json({ document });
  } catch (error: any) {
    console.error("❌ Error uploading document:", error);
    console.error(`Error stack: ${error.stack}`);
    return NextResponse.json({
      error: "Kunne ikke laste opp dokument",
      details: error.message
    }, { status: 500 });
  }
}
