import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string; documentId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { projectId, documentId } = await params;
    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Check access
    const membership = await prisma.projectMember.findFirst({
        where: { projectId, user: { email: session.user.email } },
    });
    if (!membership) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const annotations = await prisma.systemAnnotation.findMany({
        where: { documentId },
        include: {
            createdBy: true,
            comments: {
                include: {
                    author: true
                },
                orderBy: { createdAt: "asc" }
            }
        },
        orderBy: { createdAt: "asc" },
    });

    return NextResponse.json(annotations);
}

export async function POST(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string; documentId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { projectId, documentId } = await params;
    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Check access
    const membership = await prisma.projectMember.findFirst({
        where: { projectId, user: { email: session.user.email } },
    });
    if (!membership) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    const body = await req.json();
    console.log("POST /annotations body:", JSON.stringify(body, null, 2));

    const {
        type = "SYSTEM",
        systemCode,
        content,
        mentions = [],
        color,
        pageNumber,
        x, y, width, height,
        points,
        systemAnnotationId // For replies
    } = body;

    if (pageNumber === undefined || !color) {
        return NextResponse.json({ error: "Missing required fields" }, { status: 400 });
    }

    if (type === "SYSTEM" && !systemCode) {
        return NextResponse.json({ error: "Missing system code" }, { status: 400 });
    }

    try {
        // Fetch project and document names for notification metadata
        const project = await prisma.project.findUnique({ where: { id: projectId }, select: { name: true } });
        const document = await prisma.document.findUnique({ where: { id: documentId }, select: { title: true } });

        // If systemAnnotationId is present, this is a reply (Comment)
        if (systemAnnotationId) {
            const comment = await prisma.comment.create({
                data: {
                    content: content || "",
                    authorId: user.id,
                    systemAnnotationId,
                    projectId
                },
                include: {
                    author: true
                }
            });

            // Create notifications for mentions in reply
            if (mentions && Array.isArray(mentions) && mentions.length > 0) {
                try {
                    await prisma.notification.createMany({
                        data: mentions.map((userId: string) => ({
                            userId,
                            type: "MENTION",
                            commentId: comment.id,
                            read: false,
                            metadata: {
                                documentId,
                                projectId,
                                projectName: project?.name || "Ukjent prosjekt",
                                documentTitle: document?.title || "Ukjent dokument"
                            }
                        }))
                    });
                } catch (notificationError) {
                    console.error("Failed to create notifications for reply:", notificationError);
                }
            }
            return NextResponse.json(comment);
        } else {
            // Create new SystemAnnotation
            const annotation = await prisma.systemAnnotation.create({
                data: {
                    type,
                    systemCode: type === "SYSTEM" ? systemCode : undefined,
                    content,
                    color,
                    pageNumber,
                    x, y, width, height,
                    points: points ?? undefined,
                    documentId,
                    createdById: user.id
                },
                include: {
                    createdBy: true,
                    comments: {
                        include: {
                            author: true
                        }
                    }
                }
            });

            // Create notifications for mentions in new annotation
            if (mentions && Array.isArray(mentions) && mentions.length > 0) {
                try {
                    await prisma.notification.createMany({
                        data: mentions.map((userId: string) => ({
                            userId,
                            type: "MENTION",
                            systemAnnotationId: annotation.id,
                            read: false,
                            metadata: {
                                documentId,
                                projectId,
                                projectName: project?.name || "Ukjent prosjekt",
                                documentTitle: document?.title || "Ukjent dokument"
                            }
                        }))
                    });
                } catch (notificationError) {
                    console.error("Failed to create notifications:", notificationError);
                }
            }
            return NextResponse.json(annotation);
        }
    } catch (error) {
        console.error("Failed to create annotation:", error);
        return NextResponse.json({ error: "Failed to create annotation", details: (error as Error).message }, { status: 500 });
    }
}
