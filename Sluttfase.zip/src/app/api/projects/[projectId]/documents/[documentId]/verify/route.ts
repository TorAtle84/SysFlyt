import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { scanDocumentForComponents, verifyAgainstMassList } from "@/lib/scan";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";

async function getUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  return prisma.user.findUnique({ where: { email: session.user.email } });
}

type Context = { params: Promise<{ projectId: string; documentId: string }> };

export async function POST(req: NextRequest, context: Context) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { content, systemTags = [] } = body || {};
  if (!content) return NextResponse.json({ error: "Ingen dokumentinnhold sendt inn" }, { status: 400 });

  const { projectId, documentId } = await context.params;

  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: { massList: true },
  });
  if (!project) return NextResponse.json({ error: "Prosjekt ikke funnet" }, { status: 404 });

  const scan = scanDocumentForComponents(content, systemTags);
  const verification = verifyAgainstMassList(scan.components, project.massList);

  return NextResponse.json({ scan, verification });
}
