import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/db";
import { getUser, canWrite } from "../../route";

export async function PATCH(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string; documentId: string }> }
) {
    const user = await getUser();
    if (!user) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { projectId, documentId } = await params;

    if (!canWrite(user.role)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    try {
        const body = await req.json();
        const { systemTags } = body;

        if (!Array.isArray(systemTags)) {
            return NextResponse.json({ error: "Invalid tags format" }, { status: 400 });
        }

        const document = await prisma.document.update({
            where: { id: documentId },
            data: {
                systemTags: systemTags,
            },
        });

        return NextResponse.json(document);
    } catch (error) {
        console.error("Error updating document:", error);
        return NextResponse.json({ error: "Internal Server Error" }, { status: 500 });
    }
}

export async function DELETE(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string; documentId: string }> }
) {
    const user = await getUser();
    if (!user) {
        return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { projectId, documentId } = await params;

    if (!canWrite(user.role)) {
        return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    try {
        // Get the document to find its title
        const document = await prisma.document.findUnique({
            where: { id: documentId },
            select: { title: true, projectId: true },
        });

        if (!document || document.projectId !== projectId) {
            return NextResponse.json({ error: "Dokument ikke funnet" }, { status: 404 });
        }

        // Find all documents with the same title (all revisions)
        const allRevisions = await prisma.document.findMany({
            where: {
                projectId,
                title: document.title,
            },
            select: { id: true },
        });

        const revisionIds = allRevisions.map(d => d.id);

        // Delete all related data for all revisions
        await prisma.$transaction([
            prisma.documentSystemTag.deleteMany({ where: { documentId: { in: revisionIds } } }),
            prisma.documentComponent.deleteMany({ where: { documentId: { in: revisionIds } } }),
            prisma.annotation.deleteMany({ where: { documentId: { in: revisionIds } } }),
            prisma.document.deleteMany({ where: { id: { in: revisionIds } } })
        ]);

        console.log(`🗑️ Slettet ${revisionIds.length} revisjon(er) av "${document.title}"`);
        return NextResponse.json({ success: true, deletedCount: revisionIds.length });
    } catch (error) {
        console.error("Error deleting document:", error);
        return NextResponse.json({ error: "Kunne ikke slette dokument" }, { status: 500 });
    }
}
