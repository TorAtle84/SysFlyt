import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";
import { extractTextWithCoordinates } from "@/lib/pdf-text-extractor";
import { pointInPolygon } from "@/lib/geometry-utils";
import * as path from "path";

// --- TFM REGEX DEFINITIONS (Based on User Spec) ---

// SYSTEM: Optional byggnr +, optional =, 3-4 digits dot 2-4 digits (optionally :xxx/yyy)
// Captures: groups.byggnr, groups.system
const SYSTEM_RE = /(?:\+(?<byggnr>\d+)=)?=?(?<system>[3-7]?\d{2,3}\.\d{2,4}(?::\d+(?:\/\d+)?)?)/gi;

// INLINE TFM: Full {system}{komponent} (typekode optional) in one token
const INLINE_TFM_RE = /(?:\+(?<byggnr>\d+)=)?=?(?<system>[3-7]?\d{2,3}\.\d{2,4}(?::\d+(?:\/\d+)?)?)[-\s]*(?<komponent>[A-Z]{2,3}\d[0-9A-Z/_\-]*)(?:%(?<typekode>[A-Z]{2,3}))?/gi;

// COMPONENT: Optional dash/space, 2-3 letters then digits/extra chars, stops before % or whitespace
const COMPONENT_RE = /[- \s]*?(?<komponent>[A-Z]{2,3}\d[0-9A-Z/_\-]*)(?=%[A-Z]{2,3}|\s|$)/gi;

// TYPECODE: % followed by 2-3 letters (case-insensitive, no global to avoid lastIndex issues)
const TYPECODE_RE = /%(?<typekode>[A-Z]{2,3})\b/i;

export async function POST(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string; documentId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { projectId, documentId } = await params;
    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Check access
    const membership = await prisma.projectMember.findFirst({
        where: { projectId, user: { email: session.user.email } },
    });
    if (!membership) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    try {
        const body = await req.json().catch(() => ({})); // Handle empty body
        const { enableGeometry = false } = body;

        // Get document with system annotations and systemTags
        const document = await prisma.document.findUnique({
            where: { id: documentId },
            include: {
                systemAnnotations: {
                    where: { type: "SYSTEM" },
                    orderBy: { createdAt: "asc" }
                }
            }
        });

        if (!document) {
            return NextResponse.json({ error: "Document not found" }, { status: 404 });
        }

        // Default system from document metadata (if available)
        const defaultSystem = document.systemTags?.[0]?.trim() || "Systemløs";

        // Get PDF file path
        const pdfPath = path.join(process.cwd(), "public", document.url);

        console.log(`🔍 Extracting text from PDF: ${pdfPath}`);

        // Extract text with coordinates
        const textItems = await extractTextWithCoordinates(pdfPath);

        console.log(`📄 Found ${textItems.length} text items in PDF`);

        // Robust Line Clustering
        // 1. Group items by Page
        const itemsByPage = new Map<number, typeof textItems>();
        for (const item of textItems) {
            if (!itemsByPage.has(item.page)) itemsByPage.set(item.page, []);
            itemsByPage.get(item.page)!.push(item);
        }

        const mergedItems: typeof textItems = [];

        // 2. Process each page
        for (const [, items] of itemsByPage) {
            if (items.length === 0) continue;

            // Cluster items into lines based on Y-proximity
            const lines: { ySum: number; count: number; items: typeof textItems }[] = [];

            // TOLERANCE: 3.0% of page height
            const Y_TOLERANCE = 3.0;

            // Sort by Y first to make clustering easier
            items.sort((a, b) => a.y - b.y);

            for (const item of items) {
                let placed = false;
                // Try to find a matching line
                for (const line of lines) {
                    const avgY = line.ySum / line.count;
                    if (Math.abs(item.y - avgY) < Y_TOLERANCE) {
                        line.items.push(item);
                        line.ySum += item.y;
                        line.count++;
                        placed = true;
                        break;
                    }
                }
                // If not placed, create new line
                if (!placed) {
                    lines.push({ ySum: item.y, count: 1, items: [item] });
                }
            }

            // 3. Sort lines by Y (Top-Down)
            lines.sort((a, b) => (a.ySum / a.count) - (b.ySum / b.count));

            // 4. Sort items within each line by X (Left-Right) and Merge
            for (const line of lines) {
                line.items.sort((a, b) => a.x - b.x);

                if (line.items.length === 0) continue;

                let currentItem = line.items[0];
                for (let i = 1; i < line.items.length; i++) {
                    const nextItem = line.items[i];

                    // Calculate distance
                    const xDist = nextItem.x - (currentItem.x + currentItem.width);

                    // Merge if close enough
                    // X_TOLERANCE: Allow up to 15% gap
                    if (xDist < 15.0 && xDist > -2.0) {
                        currentItem.text += " " + nextItem.text;
                        currentItem.width += xDist + nextItem.width;
                    } else {
                        mergedItems.push(currentItem);
                        currentItem = nextItem;
                    }
                }
                mergedItems.push(currentItem);
            }
        }

        console.log(`📄 Merged into ${mergedItems.length} text lines`);

        // Debug: Log first 20 merged lines
        mergedItems.slice(0, 20).forEach((item, i) => console.log(`📝 Line ${i}: "${item.text}"`));

        const components: {
            system: string;
            component: string;
            typekode?: string;
            byggnr?: string;
            x: number;
            y: number;
            page: number;
            source: string;
        }[] = [];

        // --- NEW TFM PARSING LOGIC (State Machine) ---

        let currentSystem: string | null = null;
        let currentByggnr: string | null = null;
        let gapSinceContext = 0;
        const MAX_GAP = 2;

        const normalizeSystem = (raw?: string | null) => {
            if (!raw) return null;
            return raw.replace(/^=/, "");
        };

        const normalizeComponent = (raw?: string | null) => {
            if (!raw) return null;
            return raw.replace(/^[-\s]+/, "").trim().toUpperCase();
        };

        for (const item of mergedItems) {
            const text = item.text;
            let lineHandled = false;

            const consumedRanges: { start: number; end: number }[] = [];
            const markConsumed = (start: number, end: number) => consumedRanges.push({ start, end });
            const isConsumed = (start: number, end: number) =>
                consumedRanges.some(r => start < r.end && end > r.start);

            // 1) Inline tokens that already contain system+komponent
            const inlineMatches = [...text.matchAll(INLINE_TFM_RE)];
            for (const match of inlineMatches) {
                const system = normalizeSystem(match.groups?.system) || defaultSystem;
                const component = normalizeComponent(match.groups?.komponent);
                if (!component) continue;

                const typekode = match.groups?.typekode ? match.groups.typekode.toUpperCase() : undefined;
                components.push({
                    system,
                    component,
                    typekode,
                    byggnr: match.groups?.byggnr || undefined,
                    x: item.x,
                    y: item.y,
                    page: item.page,
                    source: "inline"
                });

                markConsumed(match.index!, match.index! + match[0].length);
                currentSystem = normalizeSystem(match.groups?.system) || currentSystem;
                currentByggnr = match.groups?.byggnr || currentByggnr;
                gapSinceContext = 0;
                lineHandled = true;
                console.log(`🚀 Inline Match: ${system} -> ${component}`);
            }

            // 2) Standalone system tokens to build context
            const systemSpans: { start: number; end: number; system: string; byggnr: string | null }[] = [];
            for (const sysMatch of text.matchAll(SYSTEM_RE)) {
                const start = sysMatch.index!;
                const end = start + sysMatch[0].length;
                if (isConsumed(start, end)) continue;

                const system = normalizeSystem(sysMatch.groups?.system);
                if (!system) continue;

                const before = start > 0 ? text[start - 1] : " ";
                const after = text[end] || " ";
                const bounded = !/[A-Za-z0-9]/.test(before) && !/[A-Za-z]/.test(after);
                if (!bounded) continue;

                systemSpans.push({
                    start,
                    end,
                    system,
                    byggnr: sysMatch.groups?.byggnr || null
                });

                currentSystem = system;
                currentByggnr = sysMatch.groups?.byggnr || null;
                gapSinceContext = 0;
                lineHandled = true;
                console.log(`🔄 Context Update: ${system}`);
            }

            // 3) Components (bind to inline/system/context before falling back to Systemtagging)
            for (const compMatch of text.matchAll(COMPONENT_RE)) {
                const compStart = compMatch.index!;
                const compEnd = compStart + compMatch[0].length;
                if (isConsumed(compStart, compEnd)) continue; // Already captured as inline

                const compCode = normalizeComponent(compMatch.groups?.komponent);
                if (!compCode || !/[A-Z]{2,}\d{2,}/.test(compCode)) continue;

                const nearestSystem = systemSpans
                    .filter(s => s.end <= compStart)
                    .sort((a, b) => b.end - a.end)[0];

                let assignedSystem: string | null = null;
                let assignedByggnr: string | null = null;
                let source = "fallback-tag";

                if (nearestSystem) {
                    const gapText = text.substring(nearestSystem.end, compStart);
                    const isNoisy = /[A-Za-z0-9]/.test(gapText.replace(/[- \.,;:]/g, ""));
                    if (!isNoisy) {
                        assignedSystem = nearestSystem.system;
                        assignedByggnr = nearestSystem.byggnr;
                        source = "same-line";
                    }
                }

                if (!assignedSystem && currentSystem && gapSinceContext <= MAX_GAP) {
                    assignedSystem = currentSystem;
                    assignedByggnr = currentByggnr || null;
                    source = "context";
                }

                if (!assignedSystem) {
                    assignedSystem = defaultSystem;
                    source = "systemtag-fallback";
                }

                const typeCodeMatch = text.substring(compEnd).match(TYPECODE_RE);
                const typekode = typeCodeMatch?.groups?.typekode?.toUpperCase();

                if (assignedSystem === defaultSystem && enableGeometry) {
                    const centerX = item.x + (item.width / 2);
                    const centerY = item.y + (item.height / 2);
                    const componentPoint = { x: centerX, y: centerY };
                    let bestMatch: { system: string; distance: number; isStrict: boolean } | null = null;

                    for (const annotation of document.systemAnnotations) {
                        if (annotation.pageNumber !== item.page) continue;
                        let polygon: { x: number; y: number }[] = [];
                        if (annotation.points) {
                            try { polygon = typeof annotation.points === 'string' ? JSON.parse(annotation.points) : annotation.points; } catch { /* ignore malformed geometry */ }
                        } else if (annotation.x !== null) {
                            polygon = [
                                { x: annotation.x, y: annotation.y },
                                { x: annotation.x + annotation.width!, y: annotation.y },
                                { x: annotation.x + annotation.width!, y: annotation.y + annotation.height! },
                                { x: annotation.x, y: annotation.y + annotation.height! }
                            ];
                        }

                        if (polygon.length > 0 && pointInPolygon(componentPoint, polygon)) {
                            bestMatch = { system: annotation.systemCode || "Ukjent", distance: 0, isStrict: true };
                        }
                    }
                    if (bestMatch) {
                        assignedSystem = bestMatch.system;
                        source = "geometry";
                    }
                }

                components.push({
                    system: assignedSystem || defaultSystem,
                    component: compCode,
                    typekode: typekode || undefined,
                    byggnr: assignedByggnr || undefined,
                    x: item.x,
                    y: item.y,
                    page: item.page,
                    source: source
                });

                lineHandled = true;
                gapSinceContext = 0;
                console.log(`🎯 Found Component: ${compCode} -> ${assignedSystem || defaultSystem} (${source})`);
            }

            if (!lineHandled) {
                gapSinceContext++;
                if (gapSinceContext > MAX_GAP && currentSystem) {
                    console.log(`⚠️ Context Lost: Gap > ${MAX_GAP}. Resetting.`);
                    currentSystem = null;
                    currentByggnr = null;
                }
            }
        }

        // Remove duplicates
        const uniqueComponentsMap = new Map<string, typeof components[0]>();

        for (const comp of components) {
            const key = `${comp.system}-${comp.component}`;
            if (!uniqueComponentsMap.has(key)) {
                uniqueComponentsMap.set(key, comp);
            }
        }

        const uniqueComponents = Array.from(uniqueComponentsMap.values());

        console.log(`🎯 Extracted ${uniqueComponents.length} unique components`);

        return NextResponse.json({
            components: uniqueComponents,
            debugText: mergedItems.map(i => i.text)
        });
    } catch (error) {
        console.error("Failed to extract components:", error);
        return NextResponse.json({
            error: "Failed to extract components",
            details: error instanceof Error ? error.message : String(error)
        }, { status: 500 });
    }
}

export async function PUT(
    req: NextRequest,
    { params }: { params: Promise<{ projectId: string; documentId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { projectId, documentId } = await params;
    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    // Check access
    const membership = await prisma.projectMember.findFirst({
        where: { projectId, user: { email: session.user.email } },
    });
    if (!membership) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

    try {
        const body = await req.json();
        const { components } = body as { components: { system: string; component: string; x?: number; y?: number; page?: number }[] };

        // Delete existing components for this document
        await prisma.documentComponent.deleteMany({
            where: { documentId }
        });

        // Insert new components
        if (components && components.length > 0) {
            await prisma.documentComponent.createMany({
                data: components.map(c => ({
                    documentId,
                    code: c.component,
                    system: c.system,
                    x: c.x,
                    y: c.y,
                    page: c.page
                }))
            });
        }

        return NextResponse.json({ success: true });
    } catch (error) {
        console.error("Failed to save components:", error);
        return NextResponse.json({ error: "Failed to save components" }, { status: 500 });
    }
}
