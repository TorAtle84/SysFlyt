import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { ProjectStatus, Role } from "@prisma/client";

async function getUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  return prisma.user.findUnique({ where: { email: session.user.email } });
}

export async function GET() {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const [mine, invited] = await Promise.all([
    prisma.project.findMany({
      where: { OR: [{ createdById: user.id }, { members: { some: { userId: user.id } } }] },
      include: {
        members: { include: { user: true } },
      },
      orderBy: { updatedAt: "desc" },
    }),
    prisma.project.findMany({
      where: { members: { some: { userId: user.id } } },
      include: {
        members: { include: { user: true } },
      },
      orderBy: { updatedAt: "desc" },
    }),
  ]);

  return NextResponse.json({ mine, invited });
}

export async function POST(req: Request) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  if (!(user.role === Role.ADMIN || user.role === Role.PROJECT_LEADER)) {
    return NextResponse.json({ error: "Mangler tilgang" }, { status: 403 });
  }

  const body = await req.json();
  const { name, description, discipline } = body || {};
  if (!name) return NextResponse.json({ error: "Navn er påkrevd" }, { status: 400 });

  // Check for duplicate project name for this user
  const existingProject = await prisma.project.findFirst({
    where: {
      name: name,
      createdById: user.id,
      status: ProjectStatus.ACTIVE
    }
  });

  if (existingProject) {
    return NextResponse.json({ error: "Prosjektet eksisterer" }, { status: 400 });
  }

  const project = await prisma.project.create({
    data: {
      name,
      description,
      discipline,
      status: ProjectStatus.ACTIVE,
      createdById: user.id,
      members: {
        create: {
          userId: user.id,
          role: Role.PROJECT_LEADER,
        },
      },
    },
    include: {
      members: { include: { user: true } },
      documents: true,
    },
  });

  return NextResponse.json(project);
}
