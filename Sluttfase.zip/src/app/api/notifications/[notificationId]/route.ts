import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";

export async function PATCH(
    req: NextRequest,
    { params }: { params: Promise<{ notificationId: string }> }
) {
    const session = await getServerSession(authOptions);
    if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

    const { notificationId } = await params;

    const user = await prisma.user.findUnique({ where: { email: session.user.email } });
    if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

    try {
        // Mark notification as read
        const notification = await prisma.notification.update({
            where: {
                id: notificationId,
                userId: user.id // Ensure user owns this notification
            },
            data: { read: true }
        });

        return NextResponse.json(notification);
    } catch (error) {
        console.error("Failed to mark notification as read:", error);
        return NextResponse.json({ error: "Failed to update notification" }, { status: 500 });
    }
}
