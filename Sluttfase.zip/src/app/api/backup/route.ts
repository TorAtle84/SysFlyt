import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";
import { Role } from "@prisma/client";

export async function POST() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!user || user.role !== Role.ADMIN) {
    return NextResponse.json({ error: "Kun admin kan trigge backup" }, { status: 403 });
  }

  await new Promise((resolve) => setTimeout(resolve, 1200));
  return NextResponse.json({ status: "ok", message: "Mock backup fullført" });
}
