import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import bcrypt from "bcryptjs";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server"; // Added NextRequest

export async function PATCH(req: NextRequest) { // Changed req type to NextRequest
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) { // Added curly braces for consistency
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  // Added user existence check
  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  if (!user) {
    return NextResponse.json({ error: "User not found" }, { status: 404 });
  }

  const body = await req.json();
  // Added firstName and lastName to destructuring, removed `|| {}`
  const { firstName, lastName, phone, company, title, discipline, other, password } = body;

  // Changed `data` to `updateData` and its type
  const updateData: any = {};
  // Added firstName and lastName checks, changed checks to `!== undefined`
  if (firstName !== undefined) updateData.firstName = firstName;
  if (lastName !== undefined) updateData.lastName = lastName;
  if (phone !== undefined) updateData.phone = phone;
  if (company !== undefined) updateData.company = company;
  if (title !== undefined) updateData.title = title;
  if (discipline !== undefined) updateData.discipline = discipline;
  if (other !== undefined) updateData.other = other;
  if (password) { // Kept password check as is
    updateData.passwordHash = await bcrypt.hash(password, 10);
  }

  const updated = await prisma.user.update({
    where: { id: user.id }, // Changed where clause to use user.id
    data: updateData, // Changed data object name
    // Removed the select clause
  });

  return NextResponse.json(updated);
}
