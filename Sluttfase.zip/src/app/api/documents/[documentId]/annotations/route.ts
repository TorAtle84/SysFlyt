import { authOptions } from "@/lib/auth";
import prisma from "@/lib/db";
import { getServerSession } from "next-auth";
import { NextRequest, NextResponse } from "next/server";
import { AnnotationStatus } from "@prisma/client";

async function getUser() {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return null;
  return prisma.user.findUnique({ where: { email: session.user.email } });
}

type Context = { params: Promise<{ documentId: string }> };

export async function GET(_: NextRequest, context: Context) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { documentId } = await context.params;
  const annotations = await prisma.annotation.findMany({
    where: { documentId },
    include: { comments: { include: { author: true } } },
    orderBy: { createdAt: "desc" },
  });

  return NextResponse.json(annotations);
}

export async function POST(req: NextRequest, context: Context) {
  const user = await getUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const body = await req.json();
  const { x, y, status = AnnotationStatus.OPEN } = body || {};
  if (typeof x !== "number" || typeof y !== "number") {
    return NextResponse.json({ error: "Koordinater mangler" }, { status: 400 });
  }

  const { documentId } = await context.params;
  const annotation = await prisma.annotation.create({
    data: {
      documentId,
      authorId: user.id,
      x,
      y,
      status,
    },
  });

  return NextResponse.json(annotation);
}
