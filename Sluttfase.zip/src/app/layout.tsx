import type { Metadata } from "next";
import { Manrope, Space_Grotesk } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";
import { VantaBackground } from "@/components/vanta-background";

const grotesk = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-grotesk",
  display: "swap",
});

const manrope = Manrope({
  subsets: ["latin"],
  variable: "--font-manrope",
  display: "swap",
});

export const metadata: Metadata = {
  title: "SLUTTFASE",
  description: "Construction tech platform for håndtering av prosjekter, dokumenter og QA",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="no">
      <body className={`${grotesk.variable} ${manrope.variable} antialiased`}>
        <Providers>
          <VantaBackground />
          {children}
        </Providers>
      </body>
    </html>
  );
}
