"use client";

import { useState } from "react";
import { Topbar } from "./topbar";
import { cn } from "@/lib/utils";

export function AppShell({
  children,
  sidebar,
}: {
  children: React.ReactNode;
  sidebar?: React.ReactNode;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/60">
      <Topbar onToggleSidebar={() => setSidebarOpen((s) => !s)} />
      <div className="mx-auto flex max-w-screen-2xl gap-6 px-6 pb-10 pt-4 lg:px-10">
        {sidebar && (
          <aside
            className={cn(
              "sticky top-4 h-[calc(100vh-5rem)] w-72 shrink-0 overflow-hidden rounded-2xl border border-border bg-card/[0.88] shadow-lg transition-all",
              sidebarOpen ? "opacity-100" : "hidden lg:block lg:opacity-70"
            )}
          >
            {sidebar}
          </aside>
        )}
        <main className="flex-1">{children}</main>
      </div>
    </div>
  );
}
