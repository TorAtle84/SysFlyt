"use client";

import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { useTheme } from "@/components/theme-provider";
import { cn } from "@/lib/utils";
import { Bell, LogOut, Menu, Moon, Sun, User } from "lucide-react";
import Link from "next/link";
import { signOut, useSession } from "next-auth/react";
import { useEffect, useState } from "react";

export function Topbar({ onToggleSidebar }: { onToggleSidebar?: () => void }) {
  const { theme, toggle } = useTheme();
  const [open, setOpen] = useState(false);
  const [notifications, setNotifications] = useState(0);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const [notificationsList, setNotificationsList] = useState<any[]>([]);

  useEffect(() => {
    async function loadNotifications() {
      try {
        const res = await fetch("/api/notifications");
        if (res.ok) {
          const data = await res.json();
          setNotificationsList(data);
          const unread = data.filter((n: any) => !n.read).length;
          setNotifications(unread);
        }
      } catch {
        // ignore fetch errors in UI
      }
    }
    loadNotifications();
  }, []);

  const handleNotificationClick = async (notificationId: string) => {
    try {
      const res = await fetch("/api/notifications", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ notificationId })
      });
      if (res.ok) {
        // Update local state to mark as read
        setNotificationsList(prev =>
          prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
        );
        setNotifications(prev => Math.max(0, prev - 1));
      }
    } catch (error) {
      console.error("Failed to mark notification as read:", error);
    }
    setOpen(false);
  };

  const handleClearAll = async () => {
    try {
      const res = await fetch("/api/notifications", {
        method: "DELETE"
      });
      if (res.ok) {
        setNotificationsList([]);
        setNotifications(0);
      }
    } catch (error) {
      console.error("Failed to clear notifications:", error);
    }
  };

  return (
    <header className="sticky top-0 z-30 border-b border-border/60 bg-card/[0.88] backdrop-blur-xl">
      <div className="mx-auto flex max-w-screen-2xl items-center gap-4 px-4 py-3 lg:px-10">
        <button
          onClick={onToggleSidebar}
          className="flex h-10 w-10 items-center justify-center rounded-xl border border-border bg-muted text-foreground lg:hidden"
        >
          <Menu size={18} />
        </button>
        <Link href="/dashboard" className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-700 shadow-lg" />
          <div>
            <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Sluttfase</p>
            <p className="text-base font-semibold text-foreground">Kontrollsenter</p>
          </div>
        </Link>
        <div className="ml-auto flex items-center gap-2">
          <Button variant="ghost" size="sm" onClick={toggle} className="h-10 w-10 rounded-xl border border-border">
            {mounted ? (theme === "dark" ? <Sun size={18} /> : <Moon size={18} />) : <div className="h-[18px] w-[18px]" />}
          </Button>
          <div className="relative">
            <Button
              variant="ghost"
              size="sm"
              className="h-10 w-10 rounded-xl border border-border"
              onClick={() => setOpen((o) => !o)}
            >
              <Bell size={18} />
              {notifications > 0 && (
                <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-danger text-[10px] font-semibold text-white">
                  {notifications}
                </span>
              )}
            </Button>
            {open && (
              <div className="absolute right-0 mt-2 w-80 rounded-2xl border border-border bg-card shadow-2xl overflow-hidden">
                <div className="p-3 border-b border-border bg-muted/50 flex justify-between items-center">
                  <h3 className="font-semibold text-sm">Varsler</h3>
                  {notificationsList.length > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={handleClearAll}
                      className="text-xs h-7 px-2 text-muted-foreground hover:text-foreground"
                    >
                      Rens
                    </Button>
                  )}
                </div>
                <div className="max-h-[300px] overflow-y-auto">
                  {notificationsList.length === 0 ? (
                    <div className="px-4 py-8 text-center text-sm text-muted-foreground">Ingen nye varsler.</div>
                  ) : (
                    notificationsList.map((n: any) => (
                      <Link
                        key={n.id}
                        href={`/projects/${n.metadata?.projectId}/documents/${n.metadata?.documentId}?annotationId=${n.systemAnnotationId}`}
                        className={`block px-4 py-3 hover:bg-muted/50 transition-colors border-b border-border/50 last:border-0 ${n.read ? 'opacity-60' : ''}`}
                        onClick={() => handleNotificationClick(n.id)}
                      >
                        <div className="flex gap-3">
                          {!n.read && <div className="mt-1 h-2 w-2 rounded-full bg-blue-500 shrink-0" />}
                          {n.read && <div className="mt-1 h-2 w-2 shrink-0" />}
                          <div>
                            <p className="text-sm font-medium text-foreground">Du ble nevnt i en kommentar</p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {n.metadata?.projectName && n.metadata?.documentTitle
                                ? `i ${n.metadata.projectName}, i systemskjema ${n.metadata.documentTitle}`
                                : "Trykk for å se kommentaren i dokumentet."}
                            </p>
                          </div>
                        </div>
                      </Link>
                    ))
                  )}
                </div>
              </div>
            )}
          </div>
          <ProfileMenu />
        </div>
      </div>
    </header>
  );
}

function ProfileMenu() {
  const { data } = useSession();
  const [open, setOpen] = useState(false);
  const name = data?.user?.name || "Ukjent";

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "flex items-center gap-3 rounded-xl border border-border bg-card px-3 py-2.5 shadow-sm transition hover:border-primary/40"
        )}
      >
        <Avatar name={name} size={36} />
        <div className="text-left">
          <p className="text-sm font-semibold leading-tight text-foreground">{name}</p>
          <p className="text-xs text-muted-foreground">{data?.user?.role}</p>
        </div>
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-56 rounded-2xl border border-border bg-card p-2 shadow-xl">
          <Link
            href="/profile"
            className="flex items-center gap-2 rounded-xl px-3 py-2 text-sm text-foreground hover:bg-muted"
          >
            <User size={16} />
            Profil & sikkerhet
          </Link>
          <button
            onClick={() => signOut({ callbackUrl: "/login" })}
            className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-sm text-danger hover:bg-danger/10"
          >
            <LogOut size={16} />
            Logg ut
          </button>
        </div>
      )}
    </div>
  );
}
