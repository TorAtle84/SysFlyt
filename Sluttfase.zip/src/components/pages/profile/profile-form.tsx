"use client";

import { User } from "@prisma/client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function ProfileForm({ user }: { user: User }) {
  const [firstName, setFirstName] = useState(user.firstName);
  const [lastName, setLastName] = useState(user.lastName);
  const [phone, setPhone] = useState(user.phone || "");
  const [company, setCompany] = useState(user.company || "");
  const [title, setTitle] = useState(user.title || "");
  const [discipline, setDiscipline] = useState(user.discipline || "");
  const [other, setOther] = useState(user.other || "");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setMessage(null);
    const res = await fetch("/api/profile", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ firstName, lastName, phone, company, title, discipline, other, password: password || undefined }),
    });
    const json = await res.json();
    setLoading(false);
    setMessage(res.ok ? "Profil oppdatert" : json.error || "Kunne ikke oppdatere");
  }

  return (
    <div className="space-y-5">
      <div>
        <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">Profil</p>
        <h1 className="text-3xl font-semibold text-foreground">Personlige innstillinger</h1>
        <p className="text-sm text-muted-foreground">Oppdater navn, kontaktinfo og passord. E-post og rolle er låst.</p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Detaljer</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="grid gap-4 md:grid-cols-2">
            <Input label="Fornavn" value={firstName} onChange={(e) => setFirstName(e.target.value)} required />
            <Input label="Etternavn" value={lastName} onChange={(e) => setLastName(e.target.value)} required />
            <Input label="E-post" value={user.email} readOnly />
            <Input label="Rolle" value={user.role} readOnly />
            <Input label="Telefon" value={phone} onChange={(e) => setPhone(e.target.value)} />
            <Input label="Firma" value={company} onChange={(e) => setCompany(e.target.value)} />
            <Input label="Tittel" value={title} onChange={(e) => setTitle(e.target.value)} />
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-medium text-foreground">Fag</label>
              <select
                value={discipline}
                onChange={(e) => setDiscipline(e.target.value)}
                className="rounded-xl border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:border-info focus:ring-1 focus:ring-info"
              >
                <option value="">Velg fag...</option>
                <option value="Elektro">Elektro</option>
                <option value="Ventilasjon">Ventilasjon</option>
                <option value="Kulde">Kulde</option>
                <option value="Byggautomasjon">Byggautomasjon</option>
                <option value="Rørlegger">Rørlegger</option>
                <option value="Administrasjon">Administrasjon</option>
                <option value="Totalentreprenør">Totalentreprenør</option>
                <option value="Byggherre">Byggherre</option>
                <option value="Annet">Annet</option>
              </select>
            </div>
            <Input label="Annet" value={other} onChange={(e) => setOther(e.target.value)} placeholder="Tilleggsinformasjon" />
            <Input
              label="Nytt passord"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              hint="La tomt for å beholde eksisterende"
            />
            {message && <p className="md:col-span-2 text-sm text-info">{message}</p>}
            <div className="md:col-span-2 flex justify-end">
              <Button type="submit" loading={loading}>
                Lagre endringer
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
