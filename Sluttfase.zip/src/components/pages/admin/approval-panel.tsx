"use client";

import { useState } from "react";
import { Role, UserStatus } from "@prisma/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

type User = {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  company: string | null;
  title: string | null;
  createdAt: string | Date;
  role: Role;
};

export function ApprovalPanel({ initialUsers }: { initialUsers: User[] }) {
  const [users, setUsers] = useState(initialUsers);
  const [loading, setLoading] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  async function approve(userId: string, role: Role) {
    setLoading(userId);
    setMessage(null);
    const res = await fetch("/api/admin/users", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ userId, status: UserStatus.ACTIVE, role }),
    });
    if (res.ok) {
      setUsers((prev) => prev.filter((u) => u.id !== userId));
      setMessage("Bruker oppdatert");
    } else {
      const json = await res.json();
      setMessage(json.error || "Noe gikk galt");
    }
    setLoading(null);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs uppercase tracking-[0.35em] text-muted-foreground">Administrasjon</p>
          <h1 className="text-3xl font-semibold text-foreground">Ventende brukere</h1>
          <p className="text-sm text-muted-foreground">Aktiver eller sett roller for nye registreringer.</p>
        </div>
        <Badge tone="info">{users.length} venter</Badge>
      </div>
      {message && <p className="text-sm text-info">{message}</p>}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {users.map((user) => (
          <Card key={user.id} className="flex flex-col">
            <CardHeader>
              <CardTitle>{user.firstName} {user.lastName}</CardTitle>
              <p className="text-sm text-muted-foreground">{user.email}</p>
            </CardHeader>
            <CardContent className="flex flex-1 flex-col gap-3">
              <div className="text-sm text-muted-foreground">
                <p>{user.title || "Ingen tittel"}</p>
                <p>{user.company || "Ukjent firma"}</p>
              </div>
              <div className="mt-auto flex flex-wrap gap-2">
                {[Role.ADMIN, Role.PROJECT_LEADER, Role.USER, Role.READER].map((role) => (
                  <Button
                    key={role}
                    size="sm"
                    variant={role === Role.ADMIN ? "primary" : "outline"}
                    loading={loading === user.id}
                    onClick={() => approve(user.id, role)}
                  >
                    Godkjenn som {role}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      {users.length === 0 && (
        <Card className="p-6">
          <p className="text-sm text-muted-foreground">Ingen brukere i kø. Godt jobbet!</p>
        </Card>
      )}
    </div>
  );
}
