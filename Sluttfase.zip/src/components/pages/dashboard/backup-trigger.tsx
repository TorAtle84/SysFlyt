"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";

export function BackupTrigger() {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  async function handleBackup() {
    setLoading(true);
    setMessage(null);
    const res = await fetch("/api/backup", { method: "POST" });
    const json = await res.json();
    setLoading(false);
    setMessage(res.ok ? json.message : json.error || "Kunne ikke kjøre backup");
  }

  return (
    <div className="rounded-2xl border border-border bg-muted/50 p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-semibold text-foreground">Backup</p>
          <p className="text-xs text-muted-foreground">Mock-dump for å teste flyten.</p>
        </div>
        <Button size="sm" onClick={handleBackup} loading={loading}>
          Kjør nå
        </Button>
      </div>
      {message && <p className="mt-2 text-sm text-info">{message}</p>}
    </div>
  );
}
