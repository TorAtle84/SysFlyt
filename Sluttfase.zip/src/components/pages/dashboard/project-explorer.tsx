"use client";

import { useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Link from "next/link";
import { ProjectStatus, Role } from "@prisma/client";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { cn } from "@/lib/utils";
import { Calendar, List, Plus, Search, Table } from "lucide-react";

type Project = {
  id: string;
  name: string;
  description: string | null;
  status: ProjectStatus;
  createdAt: string | Date;
  archivedAt: string | Date | null;
  members: { userId: string; role: Role; user: { firstName: string; lastName: string; email: string } }[];
  documents: { id: string }[];
  logoUrl?: string | null;
  discipline?: string | null;
  createdById: string | null;
  createdBy?: { firstName: string; lastName: string };
};

type Props = {
  mine: Project[];
  invited: Project[];
  canCreate: boolean;
  userDiscipline?: string | null;
};

export function ProjectExplorer({ mine, invited, canCreate, userDiscipline }: Props) {
  const [tab, setTab] = useState<"mine" | "invited">("mine");
  const [view, setView] = useState<"grid" | "list">("grid");
  const [filter, setFilter] = useState<"active" | "archived" | "all">("active");
  const [query, setQuery] = useState("");
  const [data, setData] = useState({ mine, invited });

  const projects = tab === "mine" ? data.mine : data.invited;

  const filtered = useMemo(() => {
    return projects.filter((p) => {
      const creatorName = p.createdBy ? `${p.createdBy.firstName} ${p.createdBy.lastName}` : "";
      const matchesQuery =
        p.name.toLowerCase().includes(query.toLowerCase()) ||
        (p.description || "").toLowerCase().includes(query.toLowerCase()) ||
        (p.discipline || "").toLowerCase().includes(query.toLowerCase()) ||
        creatorName.toLowerCase().includes(query.toLowerCase()) ||
        p.status.toLowerCase().includes(query.toLowerCase());
      const matchesFilter =
        filter === "all" ||
        (filter === "active" && p.status === ProjectStatus.ACTIVE) ||
        (filter === "archived" && p.status === ProjectStatus.ARCHIVED);
      return matchesQuery && matchesFilter;
    });
  }, [projects, query, filter]);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex overflow-hidden rounded-xl border border-border">
            <TabButton active={tab === "mine"} onClick={() => setTab("mine")}>
              Mine prosjekter
            </TabButton>
            <TabButton active={tab === "invited"} onClick={() => setTab("invited")}>
              Inviterte
            </TabButton>
          </div>
          <div className="flex gap-2 rounded-xl border border-border bg-card px-2 py-1">
            <FilterChip label="Aktive" active={filter === "active"} onClick={() => setFilter("active")} />
            <FilterChip label="Arkiv" active={filter === "archived"} onClick={() => setFilter("archived")} />
            <FilterChip label="Alle" active={filter === "all"} onClick={() => setFilter("all")} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-2 rounded-xl border border-border bg-card px-3 py-2">
            <Search size={16} className="text-muted-foreground" />
            <input
              placeholder="Søk prosjekter"
              className="bg-transparent text-sm text-foreground outline-none"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
          </div>
          <div className="flex rounded-xl border border-border bg-card">
            <ToggleButton icon={<Table size={16} />} active={view === "grid"} onClick={() => setView("grid")} />
            <ToggleButton icon={<List size={16} />} active={view === "list"} onClick={() => setView("list")} />
          </div>
          {canCreate && (
            <CreateProject
              onCreated={(project) => setData((d) => ({ ...d, mine: [project, ...d.mine] }))}
              defaultDiscipline={userDiscipline}
            />
          )}
        </div>
      </div>

      <AnimatePresence mode="popLayout">
        {filtered.length === 0 ? (
          <Card className="flex flex-col items-center justify-center gap-3 px-6 py-10 text-center">
            <p className="text-lg font-semibold text-foreground">Ingen prosjekter</p>
            <p className="text-sm text-muted-foreground">Prøv et annet filter eller opprett et nytt prosjekt.</p>
          </Card>
        ) : view === "grid" ? (
          <motion.div layout className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
            {filtered.map((project) => (
              <motion.div key={project.id} layout initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
                <ProjectCard project={project} />
              </motion.div>
            ))}
          </motion.div>
        ) : (
          <motion.div layout className="space-y-3">
            {filtered.map((project) => (
              <motion.div key={project.id} layout initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
                <ProjectRow project={project} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function TabButton({ active, children, onClick }: { active: boolean; children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "px-4 py-2 text-sm font-semibold transition",
        active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:bg-muted"
      )}
    >
      {children}
    </button>
  );
}

function FilterChip({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-lg px-3 py-1 text-xs font-semibold uppercase tracking-wide transition",
        active ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
      )}
    >
      {label}
    </button>
  );
}

function ToggleButton({
  icon,
  active,
  onClick,
}: {
  icon: React.ReactNode;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={cn(
        "flex items-center justify-center px-3 py-2 text-muted-foreground transition",
        active ? "bg-muted text-foreground" : "hover:bg-muted/60"
      )}
    >
      {icon}
    </button>
  );
}

function statusTone(status: ProjectStatus) {
  if (status === ProjectStatus.ARCHIVED) return "warning"; // Changed to warning for orange border
  return "info"; // Active is info (green border per new badge styles)
}

function statusLabel(status: ProjectStatus) {
  return status === ProjectStatus.ARCHIVED ? "Arkivert" : "Aktiv";
}

function ProjectCard({ project }: { project: Project }) {
  return (
    <Card className="group relative h-full overflow-hidden border-border/70 bg-card/80 transition hover:-translate-y-1 hover:shadow-2xl">
      <div className="absolute inset-0 opacity-0 blur-3xl transition group-hover:opacity-100 group-hover:blur-xl">
        <div className="absolute left-4 top-4 h-20 w-20 rounded-full bg-info/20" />
        <div className="absolute right-4 bottom-4 h-16 w-16 rounded-full bg-success/15" />
      </div>

      <div className="relative flex h-full flex-col gap-3 p-5">
        <div className="flex items-start justify-between">
          <Badge tone={statusTone(project.status)}>{statusLabel(project.status)}</Badge>

          {/* Logo and Date container */}
          <div className="flex flex-col items-end gap-1">
            {project.logoUrl && (
              <img
                src={project.logoUrl}
                alt="Logo"
                className="h-10 w-10 rounded-md object-cover shadow-sm"
              />
            )}
            <span className="text-[10px] text-muted-foreground">
              {new Date(project.createdAt).toLocaleDateString("no-NO")}
            </span>
          </div>
        </div>

        <div>
          <h3 className="text-xl font-semibold text-foreground">{project.name}</h3>
          {project.discipline && (
            <p className="text-xs font-medium text-info uppercase tracking-wider mb-1">
              {project.discipline}
            </p>
          )}
          <p className="mt-1 line-clamp-3 text-sm text-muted-foreground">
            {project.description || "Ingen beskrivelse"}
          </p>
        </div>

        <div className="mt-auto flex items-center justify-between pt-2">
          <div className="flex -space-x-2">
            {project.members.slice(0, 3).map((m) => (
              <Avatar
                key={m.userId}
                name={`${m.user.firstName} ${m.user.lastName}`}
                className="ring-2 ring-card"
                size={28}
              />
            ))}
            {project.members.length > 3 && (
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-muted text-[10px] font-medium ring-2 ring-card">
                +{project.members.length - 3}
              </div>
            )}
          </div>
          <Link
            href={`/projects/${project.id}`}
            className="text-sm font-semibold text-info underline-offset-4 hover:underline"
          >
            Åpne →
          </Link>
        </div>
      </div>
    </Card>
  );
}

function ProjectRow({ project }: { project: Project }) {
  return (
    <div className="flex items-center justify-between rounded-2xl border border-border bg-card/80 px-4 py-3 shadow-sm">
      <div className="flex flex-col">
        <div className="flex items-center gap-2">
          <p className="text-base font-semibold text-foreground">{project.name}</p>
          <Badge tone={statusTone(project.status)}>{statusLabel(project.status)}</Badge>
        </div>
        <p className="text-sm text-muted-foreground">{project.description || "Ingen beskrivelse"}</p>
      </div>
      <div className="flex items-center gap-2">
        {project.status === ProjectStatus.ARCHIVED && <Badge tone="warning">Arkiv</Badge>}
        <Link
          href={`/projects/${project.id}`}
          className="rounded-xl border border-border px-3 py-2 text-sm font-semibold text-info hover:bg-muted"
        >
          Åpne
        </Link>
      </div>
    </div>
  );
}

function CreateProject({
  onCreated,
  defaultDiscipline,
}: {
  onCreated: (project: Project) => void;
  defaultDiscipline?: string | null;
}) {
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [discipline, setDiscipline] = useState(defaultDiscipline || "");
  const [loading, setLoading] = useState(false);

  const disciplines = [
    "Elektro",
    "Ventilasjon",
    "Kulde",
    "Byggautomasjon",
    "Rørlegger",
    "Administrasjon",
    "Totalentreprenør",
    "Byggherre",
    "Annet",
  ];

  const [error, setError] = useState("");

  async function handleSubmit() {
    if (!name) return;
    setError("");
    setLoading(true);
    const res = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, description, discipline }),
    });
    const json = await res.json();
    setLoading(false);
    if (res.ok) {
      onCreated(json);
      setOpen(false);
      setName("");
      setDescription("");
      setDiscipline("");
    } else {
      setError(json.error || "Noe gikk galt");
    }
  }

  return (
    <div className="relative">
      <Button variant="primary" size="md" onClick={() => setOpen((o) => !o)}>
        <Plus size={16} />
        Nytt prosjekt
      </Button>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 6 }}
            className="absolute right-0 z-50 mt-2 w-80 max-w-[calc(100vw-2rem)] rounded-2xl border border-border bg-card p-4 shadow-2xl sm:right-0 sm:w-80"
          >
            <p className="text-sm font-semibold text-foreground">Opprett nytt prosjekt</p>
            <div className="mt-3 space-y-3">
              <Input
                label="Navn"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setError("");
                }}
              />

              <div className="flex flex-col gap-1.5">
                <label className="text-sm font-medium text-foreground">Fag</label>
                <select
                  value={discipline}
                  onChange={(e) => setDiscipline(e.target.value)}
                  className="rounded-xl border border-border bg-card px-3 py-2 text-sm text-foreground outline-none focus:border-info focus:ring-1 focus:ring-info"
                >
                  <option value="">Velg fag...</option>
                  {disciplines.map((d) => (
                    <option key={d} value={d}>
                      {d}
                    </option>
                  ))}
                </select>
              </div>

              <Input
                label="Beskrivelse"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Kort pitch"
              />

              {error && (
                <p className="text-xs font-medium text-danger">{error}</p>
              )}

              <div className="flex items-center justify-end gap-2">
                <Button variant="ghost" size="sm" onClick={() => setOpen(false)}>
                  Avbryt
                </Button>
                <Button size="sm" onClick={handleSubmit} loading={loading}>
                  Opprett
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
