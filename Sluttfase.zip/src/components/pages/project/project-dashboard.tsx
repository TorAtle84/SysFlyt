import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Project, ProjectStatus, Document, MassList, Comment } from "@prisma/client";
import { Activity, AlertTriangle, CheckCircle2, Clock3, FileText } from "lucide-react";

type ExtendedDocument = Document & { systemTags: string[] };

type ProjectDashboardProps = {
  project: Project & { documents: ExtendedDocument[]; massList: MassList[]; comments: (Comment & { author: { firstName: string; lastName: string } })[] };
};

export function ProjectDashboard({ project }: ProjectDashboardProps) {
  const completed = Math.max(1, Math.floor(project.massList.length * 0.6));
  const total = Math.max(project.massList.length || 10, completed + 4);
  const progress = Math.min(100, Math.round((completed / total) * 100));

  return (
    <div id="overview" className="grid gap-4 lg:grid-cols-[1.2fr,0.8fr]">
      <Card className="border-border/70">
        <CardHeader>
          <CardTitle>Fremdrift</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <StatCard title="Utførte" value={completed} icon={<CheckCircle2 className="text-success" size={18} />} />
            <StatCard title="Avvik" value={Math.max(1, Math.floor(project.documents.length / 2))} icon={<AlertTriangle className="text-warning" size={18} />} />
            <StatCard title="Pågår" value={Math.max(2, project.documents.length)} icon={<Clock3 className="text-info" size={18} />} />
            <StatCard title="Kommende" value={total - completed} icon={<Activity className="text-muted-foreground" size={18} />} />
          </div>
          <div className="mt-6 flex flex-col gap-3 rounded-2xl border border-border bg-muted/40 p-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <p className="text-sm font-semibold text-foreground">Total fremdrift</p>
              <p className="text-sm text-muted-foreground">
                {progress}% av komponentene er verifisert mot masselisten.
              </p>
            </div>
            <div className="relative h-24 w-24">
              <div
                className="absolute inset-0 rounded-full"
                style={{
                  background: `conic-gradient(var(--info) ${progress}%, var(--muted) ${progress}% 100%)`,
                }}
              />
              <div className="absolute inset-2 rounded-full bg-card flex items-center justify-center">
                <span className="text-xl font-semibold text-foreground">{progress}%</span>
              </div>
            </div>
            <Badge tone={project.status === ProjectStatus.ARCHIVED ? "muted" : "info"}>
              {project.status === ProjectStatus.ARCHIVED ? "Arkivert" : "Aktiv"}
            </Badge>
          </div>
        </CardContent>
      </Card>
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle>Siste aktivitet</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {project.comments.length === 0 && (
              <p className="text-sm text-muted-foreground">Ingen kommentarer ennå.</p>
            )}
            {project.comments.map((c) => (
              <div key={c.id} className="rounded-xl border border-border bg-muted/40 px-3 py-2">
                <p className="text-sm text-foreground">
                  <span className="font-semibold">{c.author.firstName} {c.author.lastName}</span>: {c.content}
                </p>
                <p className="text-xs text-muted-foreground">{new Date(c.createdAt).toLocaleString("no-NO")}</p>
              </div>
            ))}
          </CardContent>
        </Card>
        <Card id="protocols">
          <CardHeader>
            <CardTitle>Meldingssentral</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">Mentions og varsler vises her. Integrert med @mentions på annotasjoner.</p>
          </CardContent>
        </Card>
      </div>
      <Card id="drawings" className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Nylige dokumenter</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {project.documents.map((doc) => {
            const typeLabels: Record<string, string> = {
              DRAWING: "Arbeidstegning",
              SCHEMA: "Systemskjema",
              MASSLIST: "Masseliste",
              OTHER: "Annet",
            };

            return (
              <div key={doc.id} className="rounded-xl border border-border bg-muted/40 p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText size={16} />
                    <p className="text-sm font-semibold text-foreground">{doc.title}</p>
                  </div>
                  <Badge tone="info">{typeLabels[doc.type] || doc.type}</Badge>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  Systemer: {doc.systemTags?.length ? doc.systemTags.join(", ") : "Ukjent"}
                </p>
              </div>
            );
          })}
          {project.documents.length === 0 && <p className="text-sm text-muted-foreground">Ingen dokumenter registrert.</p>}
        </CardContent>
      </Card>
    </div>
  );
}

function StatCard({ title, value, icon }: { title: string; value: number; icon: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card/80 p-4 shadow-sm">
      <div className="flex items-center justify-between">
        <p className="text-sm font-semibold text-foreground">{title}</p>
        {icon}
      </div>
      <p className="mt-2 text-2xl font-semibold text-foreground">{value}</p>
    </div>
  );
}
