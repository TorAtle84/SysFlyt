"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Avatar } from "@/components/ui/avatar";
import { Project, ProjectMember, ProjectStatus } from "@prisma/client";
import { Archive, ArchiveRestore, Users, Trash, Upload } from "lucide-react";
import { resizeImage } from "@/lib/image-utils";

type ProjectWithMembers = Project & { members: (ProjectMember & { user: { firstName: string; lastName: string; email: string } })[]; logoUrl?: string; };

export function ProjectHeader({ project, canEdit }: { project: ProjectWithMembers; canEdit: boolean }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  async function update(action: "archive" | "restore" | "delete") {
    setLoading(true);
    setMessage(null);

    try {
      const res = await fetch(`/api/projects/${project.id}`, {
        method: action === "delete" ? "DELETE" : "PATCH",
        headers: { "Content-Type": "application/json" },
        body: action === "delete" ? undefined : JSON.stringify({ action }),
      });

      let data;
      const text = await res.text();

      try {
        data = text ? JSON.parse(text) : {};
      } catch (e) {
        console.error("Failed to parse response:", text);
        data = {};
      }

      setLoading(false);

      if (res.ok) {
        if (action === "delete") {
          setMessage("Slettet");
          // Redirect to dashboard after successful delete
          setTimeout(() => router.push("/dashboard"), 500);
        } else {
          setMessage("Oppdatert");
          router.refresh();
        }
      } else {
        console.error("Error response:", res.status, data);
        setMessage(data.error || "Noe gikk galt");
      }
    } catch (error) {
      console.error("Request failed:", error);
      setLoading(false);
      setMessage("Noe gikk galt");
    }
  }

  async function handleLogoUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);

    try {
      // Resize image to max 500x500px
      const resizedBlob = await resizeImage(file, 500, 500);
      const resizedFile = new File([resizedBlob], file.name, { type: file.type });

      const form = new FormData();
      form.append("logo", resizedFile);

      const res = await fetch(`/api/projects/${project.id}/logo`, {
        method: "POST",
        body: form,
      });

      let data;
      try {
        data = await res.json();
      } catch (e) {
        console.error("Failed to parse upload response");
      }

      if (res.ok) {
        setMessage("Logo lastet opp");
        router.refresh();
      } else {
        console.error("Upload error:", res.status, data);
        setMessage(data?.error || `Feil: ${res.status} - Kunne ikke laste opp logo`);
      }
    } catch (error) {
      console.error("Upload failed:", error);
      setMessage("Noe gikk galt under opplasting");
    } finally {
      setLoading(false);
    }
  }

  async function handleRemoveLogo() {
    if (!confirm("Er du sikker på at du vil fjerne logoen?")) return;

    setLoading(true);
    try {
      const res = await fetch(`/api/projects/${project.id}/logo`, {
        method: "DELETE",
      });

      if (res.ok) {
        setMessage("Logo fjernet");
        router.refresh();
      } else {
        setMessage("Kunne ikke fjerne logo");
      }
    } catch (error) {
      console.error("Remove logo failed:", error);
      setMessage("Noe gikk galt");
    } finally {
      setLoading(false);
    }
  }

  return (
    <Card className="relative overflow-hidden border-border/70 bg-card/90">
      <div className="flex flex-col gap-4 px-6 py-5 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex-1">
          <div className="flex items-start justify-between">
            <div>
              <Badge tone={project.status === ProjectStatus.ARCHIVED ? "muted" : "info"}>
                {project.status === ProjectStatus.ARCHIVED ? "Arkivert" : "Aktivt"}
              </Badge>
              <h1 className="mt-2 text-3xl font-semibold text-foreground">{project.name}</h1>
            </div>
          </div>
          <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
            {project.description || "Ingen beskrivelse enda."}
          </p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <div className="flex -space-x-2">
              {project.members.slice(0, 5).map((m) => (
                <Avatar
                  key={m.userId}
                  name={`${m.user.firstName} ${m.user.lastName}`}
                  className="ring-2 ring-card"
                  size={36}
                />
              ))}
            </div>
            <Badge tone="muted">{project.members.length} medlemmer</Badge>
            {canEdit && (
              <>
                {project.logoUrl ? (
                  <Button
                    variant="danger"
                    size="sm"
                    onClick={handleRemoveLogo}
                    disabled={loading}
                    className="ml-2 h-6 text-xs"
                  >
                    <Trash size={12} className="mr-1" />
                    Forkast logo
                  </Button>
                ) : (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={loading}
                    className="ml-2 h-6 text-xs"
                  >
                    <Upload size={12} className="mr-1" />
                    Last inn logo
                  </Button>
                )}
                <input
                  type="file"
                  ref={fileInputRef}
                  className="hidden"
                  accept="image/*"
                  onChange={handleLogoUpload}
                />
              </>
            )}
          </div>
          {message && <p className="mt-2 text-sm text-info">{message}</p>}
        </div>

        {/* Logo Positioned Absolute Top Right */}
        {project.logoUrl && (
          <div className="absolute right-6 top-5">
            <img
              src={project.logoUrl}
              alt="Prosjektlogo"
              className="h-20 w-20 rounded-lg object-cover shadow-sm"
            />
          </div>
        )}

        {/* Action Buttons Positioned Absolute Bottom Right */}
        {canEdit && (
          <div className="absolute bottom-5 right-6 flex gap-2">
            {project.status === ProjectStatus.ACTIVE ? (
              <Button variant="outline" size="sm" onClick={() => update("archive")} loading={loading}>
                <Archive size={14} className="mr-1" />
                Arkiver
              </Button>
            ) : (
              <Button variant="secondary" size="sm" onClick={() => update("restore")} loading={loading}>
                <ArchiveRestore size={14} className="mr-1" />
                Gjenopprett
              </Button>
            )}
            <Button variant="ghost" size="sm" onClick={() => router.push(`/projects/${project.id}#drawings`)}>
              <Users size={14} className="mr-1" />
              Medlemmer
            </Button>
            {project.status === ProjectStatus.ARCHIVED && (
              <Button variant="danger" size="sm" onClick={() => update("delete")} loading={loading}>
                <Trash size={14} className="mr-1" />
                Slett permanent
              </Button>
            )}
          </div>
        )}
      </div>
    </Card>
  );
}
