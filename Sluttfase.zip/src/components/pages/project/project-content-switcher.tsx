"use client";

import { useState } from "react";
import { Project, ProjectMember, Document, MassList, Comment, Role } from "@prisma/client";
import { ProjectDashboard } from "./project-dashboard";
import DocumentWorkspace from "./document-workspace";
import { InvitePanel } from "./invite-panel";
import { MassListManager } from "./mass-list/mass-list-manager";

type Section = "overview" | "drawings" | "schemas" | "masslist" | "protocols" | "progress";

type ProjectData = Project & {
    members: (ProjectMember & { user: { firstName: string; lastName: string; email: string } })[];
    documents: (Document & { revision: number; isLatest: boolean; systemTags: string[] })[];
    massList: MassList[];
    comments: (Comment & { author: { firstName: string; lastName: string } })[];
};

type Props = {
    project: ProjectData;
    canEdit: boolean;
    activeSection?: Section;
    onSectionChange?: (section: Section) => void;
};

export function ProjectContentSwitcher({ project, canEdit, activeSection = "overview", onSectionChange }: Props) {
    const [section, setSection] = useState<Section>(activeSection);

    const handleSectionChange = (newSection: Section) => {
        setSection(newSection);
        onSectionChange?.(newSection);
    };

    // Expose section change handler to parent
    if (typeof window !== "undefined") {
        (window as any).__setProjectSection = handleSectionChange;
    }

    return (
        <div className="space-y-6">
            {section === "overview" && (
                <>
                    {canEdit && <InvitePanel projectId={project.id} />}
                    <ProjectDashboard project={project} />
                </>
            )}

            {(section === "drawings" || section === "schemas") && (
                <DocumentWorkspace
                    project={project}
                    canEdit={canEdit}
                    members={project.members}
                    preselectedType={
                        section === "drawings" ? "DRAWING" : "SCHEMA"
                    }
                />
            )}

            {section === "masslist" && (
                <MassListManager projectId={project.id} />
            )}

            {section === "protocols" && (
                <div className="rounded-2xl border border-border bg-card p-6">
                    <h2 className="text-xl font-semibold text-foreground">Protokoller MC</h2>
                    <p className="mt-2 text-sm text-muted-foreground">
                        Protokollhåndtering kommer snart. Her vil du kunne administrere MC-protokoller og dokumentasjon.
                    </p>
                </div>
            )}

            {section === "progress" && (
                <div className="rounded-2xl border border-border bg-card p-6">
                    <h2 className="text-xl font-semibold text-foreground">Fremdrift</h2>
                    <p className="mt-2 text-sm text-muted-foreground">
                        Fremdriftsvisning med annotasjoner og @mentions kommer snart.
                    </p>
                </div>
            )}
        </div>
    );
}
