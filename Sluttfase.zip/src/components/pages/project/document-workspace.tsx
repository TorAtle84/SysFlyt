"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Search,
  FileUp,
  ScanSearch,
  ArchiveRestore,
  Loader2,
  Check,
  ChevronsUpDown,
  Package,
  Trash2,
} from "lucide-react";
import { Document, DocumentType, Project, User, Role } from "@prisma/client";
import { AnimatePresence, motion } from "framer-motion";
import Link from "next/link";
import { parseSystemTags } from "@/lib/tag-parser";
import { cn } from "@/lib/utils";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

type ExtendedDocument = Document & { revision: number; isLatest: boolean; systemTags: string[] };

type VerificationResponse = {
  scan: {
    totalComponents: number;
    uniqueCount: number;
    systemCodes: string[];
  };
  verification: {
    missingInMassList: { full: string; system: string; component: string }[];
    missingInDrawing: { id: string; code: string; description: string | null }[];
  };
};

type ProjectData = Project & {
  members: (any & { user: User })[];
  documents: ExtendedDocument[];
  massList: any[];
};

export default function DocumentWorkspace({
  project,
  canEdit,
  members,
  preselectedType,
}: {
  project: ProjectData;
  canEdit: boolean;
  members: (any & { user: User })[];
  preselectedType?: DocumentType;
}) {
  const [documents, setDocuments] = useState<ExtendedDocument[]>(project.documents);
  const [activeDoc, setActiveDoc] = useState<ExtendedDocument | null>(null);
  const [verifying, setVerifying] = useState<string | null>(null);
  const [scanResult, setScanResult] = useState<string | null>(null);
  const [matrix, setMatrix] = useState<VerificationResponse | null>(null);

  // Filter documents based on preselectedType if provided
  const visibleDocuments = preselectedType
    ? documents.filter(d => d.type === preselectedType && d.isLatest)
    : documents.filter(d => d.isLatest);

  const existingTitles = Array.from(new Set(documents.map((d) => d.title)));

  async function handleDelete(documentId: string) {
    if (!confirm("Er du sikker på at du vil slette dette dokumentet?")) return;

    const res = await fetch(`/api/projects/${project.id}/documents/${documentId}`, {
      method: "DELETE",
    });

    if (res.ok) {
      setDocuments((prev) => prev.filter((d) => d.id !== documentId));
      if (activeDoc?.id === documentId) setActiveDoc(null);
    }
  }

  async function handleUpload(formData: FormData) {
    const res = await fetch(`/api/projects/${project.id}/documents`, {
      method: "POST",
      body: formData,
    });
    if (res.ok) {
      const { document: newDoc } = await res.json();

      // Add systemTags array from the extracted text if needed
      const docWithTags = {
        ...newDoc,
        systemTags: [], // Empty initially - user will populate via search
      };

      // Add new document to the list
      setDocuments((prev) => {
        return [docWithTags, ...prev];
      });

      console.log("✅ Dokument lastet opp:", newDoc.title);
    } else {
      const text = await res.text();
      let error;
      try {
        error = JSON.parse(text);
      } catch (e) {
        console.error("❌ Server returned non-JSON error:", text);
        error = { error: `Server Error (${res.status}): ${text.substring(0, 50)}...` };
      }
      console.error("❌ Opplasting feilet:", error);
      alert(`Kunne ikke laste opp dokument: ${error.error || "Ukjent feil"}`);
    }
  }

  async function updateSystemTags(documentId: string, tags: string[]) {
    const res = await fetch(`/api/projects/${project.id}/documents/${documentId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ systemTags: tags }),
    });
    if (res.ok) {
      setDocuments((prev) =>
        prev.map((d) => (d.id === documentId ? { ...d, systemTags: tags } : d))
      );
    }
  }

  async function verifyDocument(documentId: string, content: string, systemTags: string[]) {
    setVerifying(documentId);
    setMatrix(null);
    const res = await fetch(`/api/projects/${project.id}/documents/${documentId}/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, systemTags }),
    });
    const json = await res.json();
    setVerifying(null);
    if (res.ok) {
      const data = json as VerificationResponse;
      setMatrix(data);
      return data.scan?.uniqueCount;
    }
    const err = json as { error?: string };
    setScanResult(err.error || "Kunne ikke verifisere");
    return undefined;
  }

  return (
    <div className="space-y-4" id="drawings">
      <div className="grid gap-4 lg:grid-cols-[1.1fr,0.9fr]">
        <Card className="border-border/70">
          <CardHeader>
            <CardTitle>Last opp nytt dokument</CardTitle>
          </CardHeader>
          <CardContent>
            <UploadForm
              canEdit={canEdit}
              onSubmit={handleUpload}
              preselectedType={preselectedType}
              existingTitles={existingTitles}
            />
            {scanResult && <p className="mt-3 text-sm text-info">{scanResult}</p>}
          </CardContent>
        </Card>
        <Card id="schemas">
          <CardHeader>
            <CardTitle>Masseliste & verifikasjon</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <p className="text-sm text-muted-foreground">
              Total {project.massList.length} komponenter i masselisten. Klikk et dokument under for å verifisere.
            </p>
            {matrix && (
              <div className="rounded-2xl border border-border bg-muted/50 p-3">
                <p className="text-sm font-semibold text-foreground">Avviksmatrise</p>
                <div className="mt-2 grid gap-2 text-xs text-muted-foreground">
                  <div>
                    <p className="font-semibold text-danger">Funnet i masseliste, mangler i tegning</p>
                    <ul className="list-disc pl-5">
                      {matrix.verification.missingInDrawing.length === 0 && <li>Ingen avvik</li>}
                      {matrix.verification.missingInDrawing.map((m) => (
                        <li key={m.id}>{m.code}</li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <p className="font-semibold text-warning">Funnet i tegning, ikke i masseliste</p>
                    <ul className="list-disc pl-5">
                      {matrix.verification.missingInMassList.length === 0 && <li>Ingen avvik</li>}
                      {matrix.verification.missingInMassList.map((m) => (
                        <li key={m.full}>{m.full}</li>
                      ))}
                    </ul>
                  </div>
                  <Button variant="outline" size="sm" disabled>
                    Eksporter til protokoll (kommer)
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card className="border-border/70" id="masslist">
        <CardHeader>
          <CardTitle>Dokumenter (Siste revisjoner)</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-hidden rounded-2xl border border-border">
            <table className="w-full text-left text-sm">
              <thead className="bg-muted/60 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                <tr>
                  <th className="px-4 py-3 font-medium">Dokumentnavn</th>
                  <th className="px-4 py-3 font-medium">System</th>
                  <th className="px-4 py-3 font-medium">Type</th>
                  <th className="px-4 py-3 font-medium">Sist endret</th>
                  <th className="px-4 py-3 font-medium text-right">Funksjon</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border/80">
                {visibleDocuments.map((doc) => (
                  <DocumentRow
                    key={doc.id}
                    doc={doc}
                    massList={project.massList}
                    verifying={verifying === doc.id}
                    onVerify={(content) => verifyDocument(doc.id, content, doc.systemTags)}
                    onSelect={() => setActiveDoc(doc)}
                    onUpdateTags={(tags) => updateSystemTags(doc.id, tags)}
                    onDelete={() => handleDelete(doc.id)}
                    canEdit={canEdit}
                  />
                ))}
                {visibleDocuments.length === 0 && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-sm text-muted-foreground">
                      Ingen dokumenter lastet opp ennå.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {activeDoc && (
        <Card id="progress" className="border-border/70">
          <CardHeader>
            <CardTitle>Annoteringer & @mentions</CardTitle>
          </CardHeader>
          <CardContent>
            <AnnotationBoard document={activeDoc} members={members} />
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function UploadForm({
  onSubmit,
  canEdit,
  preselectedType,
  existingTitles,
}: {
  onSubmit: (payload: FormData) => Promise<void>;
  canEdit: boolean;
  preselectedType?: DocumentType;
  existingTitles: string[];
}) {
  const [title, setTitle] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [type, setType] = useState<DocumentType>(preselectedType || DocumentType.DRAWING);
  const [loading, setLoading] = useState(false);
  const [openCombobox, setOpenCombobox] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredTitles = existingTitles.filter(t =>
    t.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Update type if preselectedType changes
  useEffect(() => {
    if (preselectedType) setType(preselectedType);
  }, [preselectedType]);

  const documentTypeLabels: Record<DocumentType, string> = {
    [DocumentType.DRAWING]: "Arbeidstegning",
    [DocumentType.SCHEMA]: "Systemskjema",
    [DocumentType.MASSLIST]: "Masseliste",
    [DocumentType.OTHER]: "Annet",
  };

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!file || !title) return;

    setLoading(true);
    const formData = new FormData();
    formData.append("title", title);
    formData.append("file", file);
    formData.append("type", type);
    formData.append("systemTags", ""); // Empty initially
    formData.append("content", ""); // Empty initially
    formData.append("description", "");

    await onSubmit(formData);

    setLoading(false);
    setTitle("");
    setFile(null);
    // Reset file input
    const fileInput = document.getElementById("file-upload") as HTMLInputElement;
    if (fileInput) fileInput.value = "";
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-3 md:grid-cols-2">
      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-medium text-foreground">Tittel</label>
        <div className="relative">
          <Input
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setTitle(e.target.value);
              setOpenCombobox(e.target.value.length > 0);
            }}
            onFocus={() => setOpenCombobox(searchQuery.length > 0)}
            onBlur={() => setTimeout(() => setOpenCombobox(false), 200)}
            onKeyDown={(e) => {
              if (e.key === "ArrowDown" && filteredTitles.length > 0) {
                e.preventDefault();
                const firstMatch = filteredTitles[0];
                setTitle(firstMatch);
                setSearchQuery(firstMatch);
                setOpenCombobox(false);
              } else if (e.key === "Enter" && filteredTitles.length === 1) {
                e.preventDefault();
                const match = filteredTitles[0];
                setTitle(match);
                setSearchQuery(match);
                setOpenCombobox(false);
              }
            }}
            placeholder="Skriv tittel..."
            disabled={!canEdit}
            className="w-full"
          />
          {openCombobox && filteredTitles.length > 0 && (
            <div className="absolute z-50 w-full mt-1 bg-popover border border-border rounded-md shadow-lg max-h-60 overflow-auto">
              {filteredTitles.map((t) => (
                <button
                  key={t}
                  type="button"
                  onClick={() => {
                    setTitle(t);
                    setSearchQuery(t);
                    setOpenCombobox(false);
                  }}
                  className="w-full px-3 py-2 text-left text-sm hover:bg-accent hover:text-accent-foreground flex items-center gap-2"
                >
                  {title === t && <Check size={14} />}
                  {t}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-medium text-foreground">Fil</label>
        <Input
          id="file-upload"
          type="file"
          onChange={(e) => setFile(e.target.files?.[0] || null)}
          required
          disabled={!canEdit}
          className="cursor-pointer"
        />
      </div>

      {!preselectedType && (
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-foreground">Type</label>
          <select
            className="rounded-xl border border-border bg-card px-3 py-2 text-sm text-foreground"
            value={type}
            onChange={(e) => setType(e.target.value as DocumentType)}
            disabled={!canEdit}
          >
            {Object.values(DocumentType).map((t) => (
              <option key={t} value={t}>
                {documentTypeLabels[t]}
              </option>
            ))}
          </select>
        </div>
      )}

      <div className="md:col-span-2 flex items-center justify-between">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <FileUp size={14} />
          Last opp ny revisjon ved å velge samme tittel.
        </div>
        <Button type="submit" loading={loading} disabled={!canEdit}>
          Last opp dokument
        </Button>
      </div>
    </form>
  );
}

function DocumentRow({
  doc,
  massList,
  verifying,
  onVerify,
  onSelect,
  onUpdateTags,
  onDelete,
  canEdit,
}: {
  doc: ExtendedDocument;
  massList: any[];
  verifying: boolean;
  onVerify: (content: string) => Promise<number | undefined>;
  onSelect: () => void;
  onUpdateTags: (tags: string[]) => Promise<void>;
  onDelete: () => Promise<void>;
  canEdit: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [count, setCount] = useState<number | null>(null);
  const [systemTags, setSystemTags] = useState(doc.systemTags.join(", "));
  const [isScanning, setIsScanning] = useState(false);
  const [componentModalOpen, setComponentModalOpen] = useState(false);
  const [components, setComponents] = useState<{ system: string; component: string }[]>([]);
  const [allComponents, setAllComponents] = useState<{ system: string; component: string }[]>([]);
  const [loadingComponents, setLoadingComponents] = useState(false);
  const [guideline, setGuideline] = useState("");

  const [filterSystem, setFilterSystem] = useState("");
  const [filterComponent, setFilterComponent] = useState("");

  const documentTypeLabels: Record<DocumentType, string> = {
    [DocumentType.DRAWING]: "Arbeidstegning",
    [DocumentType.SCHEMA]: "Systemskjema",
    [DocumentType.MASSLIST]: "Masseliste",
    [DocumentType.OTHER]: "Annet",
  };

  function handleSearchSystem() {
    setIsScanning(true);
    const filename = decodeURIComponent(doc.url.split("/").pop() || "");
    const pdfText = doc.description || "";

    console.log("🔍 Søker etter systemkoder...");
    console.log("📄 Filnavn:", filename);
    console.log("📝 PDF-tekst:", pdfText ? `${pdfText.substring(0, 100)}...` : "(ikke ekstrahert ennå)");

    // Check if user has manually entered system tags to use as pattern templates
    const manualTags = systemTags ? systemTags.split(",").map(s => s.trim()).filter(Boolean) : [];
    console.log("🏷️ Manuelt oppgitte tagger (brukes som mønster):", manualTags);

    // Search in both filename AND extracted PDF text
    const searchText = pdfText ? `${filename} ${pdfText}` : filename;

    // First, use standard parser
    let foundTags = parseSystemTags(searchText);

    // If user has provided manual tags, use them as pattern templates
    if (manualTags.length > 0) {
      console.log("🎯 Bruker manuell tag som mal for søk...");

      // Analyze the format of the first manual tag
      const template = manualTags[0];
      const parts = template.split('.');

      if (parts.length === 2) {
        const digitsBefore = parts[0].length;
        const digitsAfter = parts[1].length;

        // Create a dynamic regex based on the template
        // E.g., "3200.001" -> look for \b\d{4}\.\d{3}\b
        const patternRegex = new RegExp(`\\b\\d{${digitsBefore}}\\.\\d{${digitsAfter}}\\b`, 'g');
        console.log(`📐 Søker etter mønster: ${digitsBefore} siffer, punktum, ${digitsAfter} siffer`);

        let match;
        while ((match = patternRegex.exec(searchText)) !== null) {
          const code = match[0];
          // Verify it starts with a reasonable building system range (3-7)
          if (/^[3-7]/.test(code)) {
            foundTags.push(code);
            console.log(`✅ Fant match: ${code}`);
          }
        }
      } else if (parts.length === 3) {
        // Handle format like "360.01.02"
        const d1 = parts[0].length;
        const d2 = parts[1].length;
        const d3 = parts[2].length;
        // Component regex: optional minus, 2-3 letters, digits+chars (not hyphen/space), optionally ends with "%"
        // This will split chained components like -RTA4001-RTA4002-RTA4003 into separate matches
        const patternRegex = new RegExp(`\\b\\d{${d1}}\\.\\d{${d2}}\\.\\d{${d3}}\\b`, 'g');
        console.log(`📐 Søker etter mønster: ${d1}.${d2}.${d3} siffer`);

        let match;
        while ((match = patternRegex.exec(searchText)) !== null) {
          const code = match[0];
          if (/^[3-7]/.test(code)) {
            foundTags.push(code);
            console.log(`✅ Fant match: ${code}`);
          }
        }
      }
    }

    // Remove duplicates
    foundTags = Array.from(new Set(foundTags));
    console.log("📋 Totalt funnet systemkoder:", foundTags);

    if (foundTags.length > 0) {
      const allTags = Array.from(new Set([...manualTags, ...foundTags]));
      const newTagsString = allTags.join(", ");
      console.log("✅ Oppdaterer til:", newTagsString);
      setSystemTags(newTagsString);
      setIsScanning(false);
    } else {
      console.log("❌ Ingen systemkoder funnet");
      setTimeout(() => {
        setIsScanning(false);
        const hint = manualTags.length > 0
          ? `\n\n💡 Tips: Jeg søkte etter koder som ligner "${manualTags[0]}".\nSjekk at PDF-en inneholder systemkoder i samme format.`
          : "\n\n💡 Tips: Prøv å skrive inn ett eksempel på et systemnummer (f.eks. 3200.001) i feltet over, så søker jeg etter alle koder i samme format.";
        const pdfStatus = pdfText ? `${pdfText.length} tegn ekstrahert` : "PDF-tekst ikke ekstrahert ennå - prøv å laste opp filen på nytt";
        alert(`Ingen systemkoder funnet.\n\nSøkte i:\n- Filnavn: "${filename}"\n- PDF-innhold: ${pdfStatus}${hint}`);
      }, 500);
    }
  }

  async function handleSaveTags() {
    const tags = systemTags.split(",").map(s => s.trim()).filter(s => s);
    await onUpdateTags(tags);
  }

  async function handleSearchComponents(enableGeometry = false) {
    setLoadingComponents(true);
    setComponentModalOpen(true);
    try {
      const res = await fetch(`/api/projects/${doc.projectId}/documents/${doc.id}/components`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ enableGeometry })
      });
      if (res.ok) {
        const data = await res.json();

        // Debug: Log the raw extracted text lines
        if (data.debugText) {
          console.group("📝 PDF Raw Text Debug (All lines)");
          data.debugText.forEach((line: string, i: number) => console.log(`${i}: ${line}`));
          console.groupEnd();
        }

        // Add a unique ID to each component for safe deletion/updates
        const foundComponents = (data.components || []).map((c: any) => ({
          ...c,
          _id: Math.random().toString(36).substr(2, 9)
        }));

        setAllComponents(foundComponents);

        // If guideline is set, filter by pattern immediately
        if (guideline.trim()) {
          const filtered = filterByGuideline(foundComponents, guideline);
          setComponents(filtered);
        } else {
          setComponents(foundComponents);
        }
      } else {
        const text = await res.text();
        console.error("Component fetch raw response:", text);
        try {
          const errorData = JSON.parse(text);
          alert(`Kunne ikke hente komponenter: ${errorData.details || errorData.error || "Ukjent feil"}`);
        } catch (e) {
          alert(`Serverfeil (ikke JSON): ${text.substring(0, 200)}...`);
        }
      }
    } catch (error) {
      console.error("Failed to fetch components:", error);
      alert("En feil oppstod ved henting av komponenter");
    } finally {
      setLoadingComponents(false);
    }
  }

  function handleSearchInBoxes() {
    handleSearchComponents(true);
  }

  function handleSyncMassList() {
    if (!massList || massList.length === 0) {
      alert("Masselisten er tom eller ikke lastet inn.");
      return;
    }

    console.log("🔄 Synkroniserer mot masseliste...");
    console.log("📊 Antall komponenter:", components.length);
    console.log("📊 Antall i masseliste:", massList.length);
    if (massList.length > 0) {
      console.log("📋 Eksempel fra masseliste:", massList[0]);
    }

    let updatedCount = 0;
    const updatedComponents = components.map(comp => {
      // Find match in mass list (case insensitive component code)
      // We assume mass list has keys like 'Komponent' (or 'Component') and 'System'
      const match = massList.find(m => {
        const mComp = m.Komponent || m.Component || m.komponent || m.component;
        // Trim and normalize
        const cleanMComp = String(mComp || "").trim().toLowerCase();
        const cleanComp = comp.component.trim().toLowerCase();
        return cleanMComp === cleanComp;
      });

      if (match) {
        const mSystem = match.System || match.system;
        // Trim systems for comparison
        const cleanMSystem = String(mSystem || "").trim();
        const cleanCompSystem = String(comp.system || "").trim();

        if (cleanMSystem && cleanMSystem !== cleanCompSystem) {
          console.log(`✅ Match funnet for ${comp.component}: Endrer system fra '${comp.system}' til '${mSystem}'`);
          updatedCount++;
          return { ...comp, system: mSystem }; // Use the raw value from mass list
        } else if (cleanMSystem === cleanCompSystem) {
          console.log(`ℹ️ Match funnet for ${comp.component}, men system er likt: '${cleanMSystem}'`);
        }
      } else {
        // Log a few failures to help debug
        if (Math.random() < 0.01) {
          console.log(`❌ Ingen match funnet for ${comp.component} i masseliste.`);
        }
      }
      return comp;
    });

    if (updatedCount > 0) {
      setComponents(updatedComponents);
      alert(`Oppdaterte ${updatedCount} komponenter mot masselisten.`);
    } else {
      console.log("⚠️ Ingen endringer funnet. Sjekk at kolonnenavnene i masselisten er 'Komponent' og 'System'.");
      alert("Ingen endringer funnet mot masselisten. Sjekk konsollen (F12) for detaljer.");
    }
  }

  function filterByGuideline(components: any[], guideline: string) {
    if (!guideline) return components;
    try {
      // Convert guideline "template" to regex
      // Replace X with [A-Z] and 0 with \d
      // Escape other characters to be safe
      const pattern = guideline
        .replace(/[.*+?^${}()|[\]\\]/g, '\\$&') // Escape regex special chars
        .replace(/X/g, '[A-Z]')
        .replace(/0/g, '\\d');

      const regex = new RegExp(`^${pattern}$`, 'i');
      return components.filter(c => regex.test(c.component));
    } catch (e) {
      console.error("Invalid guideline regex:", e);
      return components;
    }
  }

  async function handleSaveAndClose() {
    try {
      // Save components to database
      const res = await fetch(`/api/projects/${doc.projectId}/documents/${doc.id}/components`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ components })
      });

      if (res.ok) {
        setComponentModalOpen(false);
      } else {
        alert("Kunne ikke lagre komponenter");
      }
    } catch (error) {
      console.error("Failed to save components:", error);
      alert("En feil oppstod ved lagring");
    }
  }

  function handleSystemChange(index: number, newSystem: string) {
    setComponents(prev => prev.map((c, i) => i === index ? { ...c, system: newSystem } : c));
  }

  function handleDeleteComponent(idOrIndex: string | number) {
    if (typeof idOrIndex === 'string') {
      setComponents(prev => prev.filter(c => c._id !== idOrIndex));
    } else {
      setComponents(prev => prev.filter((_, i) => i !== idOrIndex));
    }
  }

  return (
    <>
      <Dialog open={isScanning} onOpenChange={setIsScanning}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Analyserer dokument</DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center justify-center py-8 space-y-4">
            <div className="relative h-16 w-16">
              <motion.div
                className="absolute inset-0 rounded-full border-4 border-primary/30"
              />
              <motion.div
                className="absolute inset-0 rounded-full border-4 border-primary border-t-transparent"
                animate={{ rotate: 360 }}
                transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              />
              <Search className="absolute inset-0 m-auto h-6 w-6 text-primary" />
            </div>
            <p className="text-sm text-muted-foreground">Leter etter systemkoder i filnavn...</p>
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setIsScanning(false)}>Avbryt</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <tr className="group hover:bg-muted/30 transition-colors">
        <td className="px-4 py-3 align-top">
          <div className="flex flex-col min-w-0 pr-4">
            <Link href={`/projects/${doc.projectId}/documents/${doc.id}`} className="text-left font-medium text-foreground truncate hover:text-primary hover:underline underline-offset-4 block">
              {doc.title}
            </Link>
            <span className="truncate max-w-full text-xs text-muted-foreground opacity-70 mt-0.5">{decodeURIComponent(doc.url.split("/").pop() || "")}</span>
          </div>
        </td>
        <td className="px-4 py-3 align-top">
          <div className="text-xs text-muted-foreground truncate pr-2">
            {doc.systemTags.length > 0 ? (
              <div className="flex flex-wrap gap-1">
                {doc.systemTags.slice(0, 2).map(tag => (
                  <span key={tag} className="inline-flex items-center rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground ring-1 ring-inset ring-border/50">
                    {tag}
                  </span>
                ))}
                {doc.systemTags.length > 2 && <span className="text-[10px] text-muted-foreground">+{doc.systemTags.length - 2}</span>}
              </div>
            ) : (
              <span className="opacity-50 italic">Ingen</span>
            )}
          </div>
        </td>
        <td className="px-4 py-3 align-top">
          <div className="text-xs text-muted-foreground">
            {documentTypeLabels[doc.type] || doc.type}
          </div>
        </td>
        <td className="px-4 py-3 align-top">
          <div className="flex flex-col gap-1">
            <span className="text-xs text-muted-foreground">
              {new Date(doc.updatedAt).toLocaleDateString("no-NO", { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </span>
            <Badge tone="muted" className="w-fit px-1.5 py-0 text-[10px] font-normal border-border/60 text-muted-foreground">Rev {doc.revision}</Badge>
          </div>
        </td>
        <td className="px-4 py-3 align-top text-right">
          <div className="flex items-center justify-end gap-2">
            {count !== null && <Badge tone="info" className="h-6 px-2">{count}</Badge>}
            <Button
              variant={open ? "secondary" : "outline"}
              size="sm"
              onClick={() => setOpen((o) => !o)}
              className="h-8 px-3 text-xs"
            >
              Behandle
            </Button>
          </div>
        </td>
      </tr>

      <AnimatePresence>
        {open && (
          <tr>
            <td colSpan={5} className="p-0 border-0">
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="mx-4 mb-4 rounded-xl border border-border bg-muted/30 p-4 space-y-4">
                  <div className="space-y-2.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-semibold text-foreground flex items-center gap-2">
                        <Search size={12} />
                        Systemtagging
                      </label>
                      <span className="text-[10px] text-muted-foreground italic">Skriv eksempel (f.eks. 3200.001), trykk SØK</span>
                    </div>
                    <div className="flex gap-2">
                      <Input
                        value={systemTags}
                        onChange={(e) => setSystemTags(e.target.value)}
                        placeholder="f.eks. 360.01, 420..."
                        className="h-9 text-sm bg-background"
                        disabled={!canEdit}
                      />
                      <Button size="sm" variant="secondary" onClick={handleSearchSystem} title="Søk etter systemkoder i PDF" disabled={!canEdit} className="h-9 px-3">
                        <Search size={14} className="mr-1.5" />
                        Søk
                      </Button>
                      <Button size="sm" onClick={handleSaveTags} disabled={!canEdit} className="h-9 px-4">
                        Lagre
                      </Button>
                    </div>
                  </div>

                  <div className="flex items-center justify-between border-t border-border/50 pt-3 mt-2">
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        onClick={async () => {
                          const count = await onVerify(doc.description || "");
                          if (typeof count === "number") setCount(count);
                          onSelect();
                        }}
                        disabled={!canEdit}
                        className="h-8"
                      >
                        {verifying ? <Loader2 className="animate-spin mr-2" size={14} /> : <ScanSearch className="mr-2" size={14} />}
                        Verifiser mot masseliste
                      </Button>
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => handleSearchComponents(false)}
                        disabled={!canEdit}
                        className="h-8"
                      >
                        <Package className="mr-2" size={14} />
                        Komponenter
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => {
                          setCount((c) => (c || 0) + 1);
                          onSelect();
                        }}
                        disabled={!canEdit}
                        className="h-8"
                      >
                        <ArchiveRestore className="mr-2" size={14} />
                        Godkjenn avvik
                      </Button>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge tone="muted" className="text-muted-foreground font-normal">Eksporter til protokoll (kommer)</Badge>
                      <Button
                        size="sm"
                        className="h-8 border-2 border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                        variant="outline"
                        onClick={onDelete}
                        disabled={!canEdit}
                      >
                        Slett dokument
                      </Button>
                    </div>
                  </div>
                </div>
              </motion.div>
            </td>
          </tr>
        )}
      </AnimatePresence>

      {/* Component Matrix Dialog */}
      <Dialog open={componentModalOpen} onOpenChange={setComponentModalOpen}>
        <DialogContent className="sm:max-w-4xl max-h-[90vh] flex flex-col">
          <DialogHeader>
            <DialogTitle>Komponenter</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 flex-1 overflow-hidden flex flex-col">

            {/* Top Row: Search Actions */}
            <div className="flex gap-2 items-end border-b border-border/50 pb-4">
              <Button
                size="sm"
                variant="outline"
                onClick={handleSearchInBoxes}
                disabled={loadingComponents}
                className="h-9 mr-auto"
                title="Søk etter komponenter inne i systembokser"
              >
                <ScanSearch className="mr-2" size={14} />
                Søk i systembokser
              </Button>

              <div className="w-48">
                <label className="text-xs font-medium text-foreground mb-1.5 block">
                  Retningslinje (format)
                </label>
                <Input
                  value={guideline}
                  onChange={(e) => setGuideline(e.target.value)}
                  placeholder="f.eks. -RTA4001"
                  className="h-9 text-sm"
                />
              </div>
              <Button
                size="sm"
                variant="secondary"
                onClick={() => handleSearchComponents(false)}
                disabled={loadingComponents}
                className="h-9"
              >
                {loadingComponents ? <Loader2 className="animate-spin mr-2" size={14} /> : <Search className="mr-2" size={14} />}
                Søk (Tekst)
              </Button>
            </div>

            {/* Filter Row */}
            <div className="flex gap-2 items-center bg-muted/30 p-2 rounded-lg">
              <div className="flex-1 flex gap-2">
                <Input
                  placeholder="Filtrer system..."
                  value={filterSystem}
                  onChange={(e) => setFilterSystem(e.target.value)}
                  className="h-8 text-xs bg-background"
                />
                <Input
                  placeholder="Filtrer komponent..."
                  value={filterComponent}
                  onChange={(e) => setFilterComponent(e.target.value)}
                  className="h-8 text-xs bg-background"
                />
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={handleSyncMassList}
                disabled={loadingComponents || components.length === 0}
                className="h-8 text-xs ml-auto"
                title="Oppdater systemer basert på masseliste"
              >
                <ArchiveRestore className="mr-2" size={12} />
                Oppdater mot masseliste
              </Button>
            </div>

            <div className="text-sm text-muted-foreground flex justify-between">
              <span>
                Funnet {components.length} komponenter
                {(filterSystem || filterComponent || guideline) && (
                  <span className="ml-2 text-xs opacity-70">
                    (viser {
                      components.filter(c =>
                        (!filterSystem || c.system.toLowerCase().includes(filterSystem.toLowerCase())) &&
                        (!filterComponent || c.component.toLowerCase().includes(filterComponent.toLowerCase())) &&
                        (!guideline || filterByGuideline([c], guideline).length > 0)
                      ).length
                    })
                  </span>
                )}
              </span>
            </div>

            {loadingComponents ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="animate-spin h-6 w-6 text-primary" />
              </div>
            ) : components.length === 0 ? (
              <div className="text-center py-8 text-sm text-muted-foreground">
                Ingen komponenter funnet. Klikk "Søk" for å lete.
              </div>
            ) : (
              <div className="border border-border rounded-lg overflow-hidden flex-1 flex flex-col">
                <div className="overflow-y-auto flex-1">
                  <table className="w-full text-sm">
                    <thead className="bg-muted/60 sticky top-0 z-10">
                      <tr>
                        <th className="px-4 py-2 text-left font-medium w-1/3">System</th>
                        <th className="px-4 py-2 text-left font-medium">Komponent</th>
                        <th className="px-4 py-2 text-right font-medium w-20">Behandle</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-border">
                      {components
                        .filter(c =>
                          (!filterSystem || c.system.toLowerCase().includes(filterSystem.toLowerCase())) &&
                          (!filterComponent || c.component.toLowerCase().includes(filterComponent.toLowerCase())) &&
                          (!guideline || filterByGuideline([c], guideline).length > 0)
                        )
                        .map((comp: any, i) => (
                          <tr key={comp._id || i} className="hover:bg-muted/30 group">
                            <td className="px-4 py-2">
                              <select
                                className="bg-transparent border border-transparent hover:border-border rounded px-1 py-0.5 text-sm w-full focus:ring-1 focus:ring-primary focus:border-primary outline-none cursor-pointer"
                                value={comp.system}
                                onChange={(e) => handleSystemChange(i, e.target.value)}
                              >
                                <option value="Systemløs">Systemløs</option>
                                {doc.systemTags.map(tag => (
                                  <option key={tag} value={tag}>{tag}</option>
                                ))}
                                {!doc.systemTags.includes(comp.system) && comp.system !== "Systemløs" && (
                                  <option value={comp.system}>{comp.system}</option>
                                )}
                              </select>
                            </td>
                            <td className="px-4 py-2 font-mono text-xs">{comp.component}</td>
                            <td className="px-4 py-2 text-right">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteComponent(comp._id || i)}
                                className="h-7 w-7 p-0 text-destructive hover:text-destructive hover:bg-destructive/10 opacity-0 group-hover:opacity-100 transition-opacity"
                              >
                                <Trash2 size={14} />
                              </Button>
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="secondary" onClick={() => setComponentModalOpen(false)}>
              Avbryt
            </Button>
            <Button variant="primary" onClick={handleSaveAndClose}>
              Lagre og lukk
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function AnnotationBoard({
  document,
  members,
}: {
  document: ExtendedDocument;
  members: (any & { user: User })[];
}) {
  return (
    <div className="flex h-40 items-center justify-center rounded-xl border border-dashed border-border text-sm text-muted-foreground">
      Annoteringer og kommentarer kommer her...
    </div>
  );
}
