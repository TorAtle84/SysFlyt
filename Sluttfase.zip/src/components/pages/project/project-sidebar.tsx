"use client";

import { Project, ProjectStatus } from "@prisma/client";
import Link from "next/link";
import { LayoutDashboard, FileSpreadsheet, FileText, ClipboardList, BarChart2 } from "lucide-react";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";

const items = [
  { id: "overview", label: "Hovedside", icon: LayoutDashboard },
  { id: "masslist", label: "Masseliste", icon: ClipboardList },
  { id: "drawings", label: "Arbeidstegninger", icon: FileText },
  { id: "schemas", label: "Systemskjema", icon: FileSpreadsheet },
  { id: "protocols", label: "Protokoller MC", icon: ClipboardList },
  { id: "progress", label: "Fremdrift", icon: BarChart2 },
];

export function ProjectSidebar({ project }: { project: Project }) {
  const [activeSection, setActiveSection] = useState("overview");

  const handleSectionClick = (sectionId: string) => {
    setActiveSection(sectionId);
    // Call global function to update content
    if (typeof window !== "undefined" && (window as any).__setProjectSection) {
      (window as any).__setProjectSection(sectionId);
    }
  };

  return (
    <div className="flex h-full flex-col justify-between bg-gradient-to-b from-card to-card/60 p-4">
      <div className="space-y-4">
        <div className="rounded-2xl border border-border bg-muted/60 p-4">
          <p className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Prosjekt</p>
          <h3 className="text-lg font-semibold text-foreground">{project.name}</h3>
          <p className="text-xs text-muted-foreground">{project.status === ProjectStatus.ARCHIVED ? "Arkivert" : "Aktivt"}</p>
        </div>
        <nav className="space-y-1">
          {items.map((item) => (
            <button
              key={item.id}
              onClick={() => handleSectionClick(item.id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-xl px-3 py-2 text-sm font-semibold transition",
                activeSection === item.id
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-muted hover:text-foreground"
              )}
            >
              <item.icon size={16} />
              {item.label}
            </button>
          ))}
        </nav>
      </div>
      <Link
        href="/dashboard"
        className="rounded-xl border border-border bg-muted px-3 py-2 text-center text-sm font-semibold text-foreground hover:border-primary/40"
      >
        Tilbake til dashboard
      </Link>
    </div>
  );
}
