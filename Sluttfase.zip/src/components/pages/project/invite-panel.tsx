"use client";

import { useState } from "react";
import { Role } from "@prisma/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Users } from "lucide-react";

export function InvitePanel({ projectId }: { projectId: string }) {
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>(Role.USER);
  const [message, setMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function invite() {
    setLoading(true);
    setMessage(null);
    const res = await fetch(`/api/projects/${projectId}/members`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, role }),
    });
    const json = await res.json();
    setLoading(false);
    if (res.ok) {
      setMessage("Bruker invitert");
      setEmail("");
    } else {
      setMessage(json.error || "Kunne ikke invitere");
    }
  }

  return (
    <Card>
      <CardHeader className="flex items-center justify-between">
        <div>
          <CardTitle>Inviter medlemmer</CardTitle>
          <p className="text-sm text-muted-foreground">Tilordne rolle og legg til aktive brukere i prosjektet.</p>
        </div>
        <Users size={18} />
      </CardHeader>
      <CardContent className="grid gap-3 md:grid-cols-[1.2fr,0.7fr,0.4fr]">
        <Input label="E-post" value={email} onChange={(e) => setEmail(e.target.value)} />
        <div className="flex flex-col gap-1.5">
          <label className="text-sm font-medium text-foreground">Rolle</label>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as Role)}
            className="rounded-xl border border-border bg-card px-3 py-2 text-sm text-foreground"
          >
            {[Role.ADMIN, Role.PROJECT_LEADER, Role.USER, Role.READER].map((r) => {
              const labels: Record<Role, string> = {
                [Role.ADMIN]: "Administrator",
                [Role.PROJECT_LEADER]: "Prosjektleder",
                [Role.USER]: "Bruker",
                [Role.READER]: "Leser",
              };
              return (
                <option key={r} value={r}>
                  {labels[r]}
                </option>
              );
            })}
          </select>
        </div>
        <Button onClick={invite} loading={loading} disabled={!email}>
          Send invitasjon
        </Button>
        {message && <p className="md:col-span-3 text-sm text-info">{message}</p>}
      </CardContent>
    </Card>
  );
}
