"use client";

import { useState, useMemo } from "react";
import {
    Table,
    TableBody,
    TableCell,
    TableHead,
    TableHeader,
    TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Trash2, Search, Filter } from "lucide-react";
import { Badge } from "@/components/ui/badge";

type MassListEntry = {
    id: string;
    tfm: string;
    building: string | null;
    system: string | null;
    component: string | null;
    typeCode: string | null;
    productName: string | null;
    location: string | null;
    zone: string | null;
};

export function MassListTable({ data, onDelete, onDeleteAll }: { data: MassListEntry[]; onDelete: (id: string) => void; onDeleteAll: () => void }) {
    const [search, setSearch] = useState("");

    const filteredData = useMemo(() => {
        if (!search) return data;
        const lowerSearch = search.toLowerCase();
        return data.filter((item) =>
            Object.values(item).some((val) =>
                val && val.toString().toLowerCase().includes(lowerSearch)
            )
        );
    }, [data, search]);

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between gap-4">
                <div className="relative flex-1 max-w-md">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                        placeholder="Søk i alle kolonner (f.eks. RT, 360...)"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                        className="pl-9"
                    />
                </div>
                {data.length > 0 && (
                    <Button variant="destructive" size="sm" onClick={onDeleteAll}>
                        <Trash2 className="mr-2 h-4 w-4" />
                        Slett alt
                    </Button>
                )}
            </div>

            <div className="rounded-md border border-border bg-card">
                <Table>
                    <TableHeader>
                        <TableRow>
                            <TableHead>Byggnr</TableHead>
                            <TableHead>System</TableHead>
                            <TableHead>Komponent</TableHead>
                            <TableHead>Typekode</TableHead>
                            <TableHead>Produktnavn</TableHead>
                            <TableHead>Plassering</TableHead>
                            <TableHead>Sone/Del</TableHead>
                            <TableHead className="w-[100px]">Behandle</TableHead>
                        </TableRow>
                    </TableHeader>
                    <TableBody>
                        {filteredData.length === 0 ? (
                            <TableRow>
                                <TableCell colSpan={8} className="text-center h-24 text-muted-foreground">
                                    Ingen data funnet.
                                </TableCell>
                            </TableRow>
                        ) : (
                            filteredData.map((item) => (
                                <TableRow key={item.id}>
                                    <TableCell>{item.building || "-"}</TableCell>
                                    <TableCell>
                                        {item.system ? <Badge variant="outline">{item.system}</Badge> : "-"}
                                    </TableCell>
                                    <TableCell>{item.component || "-"}</TableCell>
                                    <TableCell>{item.typeCode || "-"}</TableCell>
                                    <TableCell>{item.productName || "-"}</TableCell>
                                    <TableCell>{item.location || "-"}</TableCell>
                                    <TableCell>{item.zone || "-"}</TableCell>
                                    <TableCell>
                                        <Button
                                            variant="ghost"
                                            size="icon"
                                            className="text-muted-foreground hover:text-danger"
                                            onClick={() => onDelete(item.id)}
                                        >
                                            <Trash2 size={16} />
                                        </Button>
                                    </TableCell>
                                </TableRow>
                            ))
                        )}
                    </TableBody>
                </Table>
            </div>
            <div className="text-xs text-muted-foreground">
                Viser {filteredData.length} av {data.length} rader
            </div>
        </div>
    );
}
