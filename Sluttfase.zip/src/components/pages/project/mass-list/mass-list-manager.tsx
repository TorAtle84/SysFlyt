"use client";

import { useState, useEffect, useCallback } from "react";
import { MassListUpload } from "./mass-list-upload";
import { MassListTable } from "./mass-list-table";
import { Separator } from "@/components/ui/separator";

export function MassListManager({ projectId }: { projectId: string }) {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(true);

    const loadData = useCallback(async () => {
        setLoading(true);
        try {
            const res = await fetch(`/api/projects/${projectId}/mass-list`);
            if (res.ok) {
                const json = await res.json();
                setData(json);
            }
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    }, [projectId]);

    useEffect(() => {
        loadData();
    }, [loadData]);

    const handleDelete = async (id: string) => {
        try {
            const res = await fetch(`/api/projects/${projectId}/mass-list?id=${id}`, {
                method: "DELETE",
            });
            if (res.ok) {
                setData((prev) => prev.filter((item) => item.id !== id));
            }
        } catch (err) {
            console.error(err);
        }
    };

    const handleDeleteAll = async () => {
        if (!confirm("Er du sikker på at du vil slette HELE masselisten?")) return;
        try {
            const res = await fetch(`/api/projects/${projectId}/mass-list?all=true`, {
                method: "DELETE",
            });
            if (res.ok) {
                setData([]);
            }
        } catch (err) {
            console.error(err);
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold text-foreground">Masseliste</h2>
                <p className="text-sm text-muted-foreground">
                    Last opp og administrer masselister for prosjektet.
                </p>
            </div>

            <MassListUpload projectId={projectId} onUploadComplete={loadData} />

            <Separator />

            <MassListTable data={data} onDelete={handleDelete} onDeleteAll={handleDeleteAll} />
        </div>
    );
}
