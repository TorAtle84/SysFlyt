"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import * as XLSX from "xlsx";
import { Upload, AlertCircle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";

type ColumnMapping = {
    tfm: string;
    productName: string;
    location: string;
    zone: string;
};

export function MassListUpload({ projectId, onUploadComplete }: { projectId: string; onUploadComplete: () => void }) {
    const [file, setFile] = useState<File | null>(null);
    const [columns, setColumns] = useState<string[]>([]);
    const [mapping, setMapping] = useState<ColumnMapping>({
        tfm: "",
        productName: "",
        location: "",
        zone: "",
    });
    const [notApplicable, setNotApplicable] = useState({
        productName: false,
        location: false,
        zone: false,
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState("");

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const selectedFile = e.target.files?.[0];
        if (!selectedFile) return;

        setFile(selectedFile);
        setError("");

        const buffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: "array" });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];

        // Get range to determine number of columns
        const range = XLSX.utils.decode_range(worksheet['!ref'] || "A1");
        const colCount = range.e.c + 1;

        // Generate column letters A-Z, AA-AZ, etc.
        const cols = [];
        for (let i = 0; i < colCount; i++) {
            cols.push(XLSX.utils.encode_col(i));
        }
        setColumns(cols);
    };

    const handleUpload = async () => {
        if (!file) return;
        setLoading(true);
        setError("");

        try {
            const formData = new FormData();
            formData.append("file", file);

            // Filter out fields marked as Not Applicable
            const finalMapping = { ...mapping };
            if (notApplicable.productName) finalMapping.productName = "";
            if (notApplicable.location) finalMapping.location = "";
            if (notApplicable.zone) finalMapping.zone = "";

            formData.append("mapping", JSON.stringify(finalMapping));

            const res = await fetch(`/api/projects/${projectId}/mass-list`, {
                method: "POST",
                body: formData,
            });

            if (!res.ok) throw new Error("Upload failed");

            onUploadComplete();
            setFile(null);
            setMapping({ tfm: "", productName: "", location: "", zone: "" });
            setNotApplicable({ productName: false, location: false, zone: false });
        } catch (err) {
            setError("Kunne ikke laste opp filen. Prøv igjen.");
        } finally {
            setLoading(false);
        }
    };

    return (
        <Card>
            <CardHeader>
                <CardTitle>Last opp Masseliste (Excel)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
                <div className="grid w-full max-w-sm items-center gap-1.5">
                    <Label htmlFor="mass-list">Excel fil</Label>
                    <Input id="mass-list" type="file" accept=".xlsx, .xls" onChange={handleFileChange} />
                </div>

                {file && columns.length > 0 && (
                    <div className="space-y-4 rounded-lg border border-border p-4 bg-muted/20">
                        <h3 className="font-semibold text-sm">Velg kolonner</h3>
                        <p className="text-xs text-muted-foreground">Velg hvilken kolonne i Excel-arket som tilsvarer feltene under.</p>

                        <div className="grid gap-6 sm:grid-cols-2">
                            <div className="space-y-2">
                                <Label>TFM (Tag)</Label>
                                <Select value={mapping.tfm} onValueChange={(v) => setMapping({ ...mapping, tfm: v })}>
                                    <SelectTrigger>
                                        <SelectValue placeholder="Velg kolonne" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {columns.map((col) => (
                                            <SelectItem key={col} value={col}>Kolonne {col}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <Label className={notApplicable.productName ? "text-muted-foreground" : ""}>Produktnavn</Label>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id="na-product"
                                            checked={notApplicable.productName}
                                            onCheckedChange={(c) => {
                                                setNotApplicable(prev => ({ ...prev, productName: !!c }));
                                                if (c) setMapping(prev => ({ ...prev, productName: "" }));
                                            }}
                                        />
                                        <label
                                            htmlFor="na-product"
                                            className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                            I/A
                                        </label>
                                    </div>
                                </div>
                                <Select
                                    value={mapping.productName}
                                    onValueChange={(v) => setMapping({ ...mapping, productName: v })}
                                    disabled={notApplicable.productName}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Velg kolonne" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {columns.map((col) => (
                                            <SelectItem key={col} value={col}>Kolonne {col}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <Label className={notApplicable.location ? "text-muted-foreground" : ""}>Plassering</Label>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id="na-location"
                                            checked={notApplicable.location}
                                            onCheckedChange={(c) => {
                                                setNotApplicable(prev => ({ ...prev, location: !!c }));
                                                if (c) setMapping(prev => ({ ...prev, location: "" }));
                                            }}
                                        />
                                        <label
                                            htmlFor="na-location"
                                            className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                            I/A
                                        </label>
                                    </div>
                                </div>
                                <Select
                                    value={mapping.location}
                                    onValueChange={(v) => setMapping({ ...mapping, location: v })}
                                    disabled={notApplicable.location}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Velg kolonne" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {columns.map((col) => (
                                            <SelectItem key={col} value={col}>Kolonne {col}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>

                            <div className="space-y-2">
                                <div className="flex items-center justify-between">
                                    <Label className={notApplicable.zone ? "text-muted-foreground" : ""}>Sone/Del</Label>
                                    <div className="flex items-center space-x-2">
                                        <Checkbox
                                            id="na-zone"
                                            checked={notApplicable.zone}
                                            onCheckedChange={(c) => {
                                                setNotApplicable(prev => ({ ...prev, zone: !!c }));
                                                if (c) setMapping(prev => ({ ...prev, zone: "" }));
                                            }}
                                        />
                                        <label
                                            htmlFor="na-zone"
                                            className="text-xs font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                                        >
                                            I/A
                                        </label>
                                    </div>
                                </div>
                                <Select
                                    value={mapping.zone}
                                    onValueChange={(v) => setMapping({ ...mapping, zone: v })}
                                    disabled={notApplicable.zone}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder="Velg kolonne" />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {columns.map((col) => (
                                            <SelectItem key={col} value={col}>Kolonne {col}</SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>

                        <Button onClick={handleUpload} disabled={!mapping.tfm || loading} className="w-full">
                            {loading ? "Laster opp..." : (
                                <>
                                    <Upload className="mr-2 h-4 w-4" />
                                    Last opp og parse
                                </>
                            )}
                        </Button>

                        {error && (
                            <div className="flex items-center gap-2 text-sm text-danger">
                                <AlertCircle size={16} />
                                {error}
                            </div>
                        )}
                    </div>
                )}
            </CardContent>
        </Card>
    );
}
