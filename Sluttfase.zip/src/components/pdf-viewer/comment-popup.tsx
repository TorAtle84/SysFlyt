"use client";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useState, useRef, useEffect } from "react";
import { X, Trash2, Send, MessageSquare } from "lucide-react";
import { Avatar } from "@/components/ui/avatar";
import { formatDistanceToNow } from "date-fns";
import { nb } from "date-fns/locale";

interface CommentPopupProps {
    onSave: (content: string, mentions: string[]) => void;
    onCancel: () => void;
    onDelete?: () => void;
    position: { x: number; y: number };
    projectMembers?: { id: string; name: string; email: string }[];
    initialContent?: string;
    initialContentAuthor?: string;
    readOnly?: boolean;
    comments?: any[]; // Threaded comments
    currentUserEmail?: string;
}

export default function CommentPopup({
    onSave,
    onCancel,
    onDelete,
    position,
    projectMembers = [],
    initialContent = "",
    initialContentAuthor,
    readOnly = false,
    comments = [],
    currentUserEmail
}: CommentPopupProps) {
    const [content, setContent] = useState("");
    const [showMentions, setShowMentions] = useState(false);
    const [mentionFilter, setMentionFilter] = useState("");
    const [cursorIndex, setCursorIndex] = useState(0);
    const [mentionedUserIds, setMentionedUserIds] = useState<Set<string>>(new Set());
    const textareaRef = useRef<HTMLTextAreaElement>(null);
    const scrollRef = useRef<HTMLDivElement>(null);

    // Auto-scroll to bottom when comments change
    useEffect(() => {
        if (scrollRef.current) {
            scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
        }
    }, [comments, initialContent]);

    const handleInput = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const val = e.target.value;
        setContent(val);

        const cursor = e.target.selectionStart;
        setCursorIndex(cursor);

        // Check for @ mention
        const textBeforeCursor = val.slice(0, cursor);
        const lastAt = textBeforeCursor.lastIndexOf("@");

        if (lastAt !== -1) {
            const textAfterAt = textBeforeCursor.slice(lastAt + 1);
            if (!textAfterAt.includes(" ")) {
                setShowMentions(true);
                setMentionFilter(textAfterAt.toLowerCase());
                return;
            }
        }
        setShowMentions(false);
    };

    const handleSelectMember = (member: { id: string; name: string }) => {
        const textBeforeCursor = content.slice(0, cursorIndex);
        const lastAt = textBeforeCursor.lastIndexOf("@");

        const newContent =
            content.slice(0, lastAt) +
            "@" + member.name + " " +
            content.slice(cursorIndex);

        setContent(newContent);
        setShowMentions(false);
        setMentionedUserIds(prev => new Set(prev).add(member.id));
        setTimeout(() => textareaRef.current?.focus(), 0);
    };

    const filteredMembers = projectMembers.filter(m =>
        m.name.toLowerCase().includes(mentionFilter) ||
        m.email.toLowerCase().includes(mentionFilter)
    );

    // Helper to render a single comment bubble
    const renderCommentBubble = (text: string, authorName: string, date?: string | Date, isMe: boolean = false) => (
        <div className={`flex gap-3 ${isMe ? 'flex-row-reverse' : ''} mb-4`}>
            <Avatar name={authorName} size={32} className="mt-1 flex-shrink-0" />
            <div className={`flex flex-col max-w-[85%] ${isMe ? 'items-end' : 'items-start'}`}>
                <div className="flex items-baseline gap-2 mb-1">
                    <span className="text-sm font-semibold text-gray-900">{authorName}</span>
                    {date && (
                        <span className="text-xs text-gray-500">
                            {typeof date === 'string' ? date : formatDistanceToNow(new Date(date), { addSuffix: true, locale: nb })}
                        </span>
                    )}
                </div>
                <div className={`p-3 rounded-lg text-sm whitespace-pre-wrap ${isMe
                        ? 'bg-blue-600 text-white rounded-tr-none'
                        : 'bg-gray-100 text-gray-800 rounded-tl-none'
                    }`}>
                    {text}
                </div>
            </div>
        </div>
    );

    return (
        <div
            className="absolute z-50 bg-white rounded-xl shadow-2xl border border-gray-200 w-[400px] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200"
            style={{
                left: position.x,
                top: position.y,
                maxHeight: '600px'
            }}
        >
            {/* Header */}
            <div className="flex justify-between items-center p-4 bg-white border-b border-gray-100">
                <div className="flex items-center gap-2 text-gray-800">
                    <MessageSquare className="h-5 w-5 text-blue-600" />
                    <h3 className="font-semibold">Diskusjon</h3>
                </div>
                <div className="flex items-center gap-1">
                    {onDelete && readOnly && (
                        <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-red-600 hover:bg-red-50" onClick={onDelete} title="Slett tråd">
                            <Trash2 className="h-4 w-4" />
                        </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-400 hover:text-gray-700" onClick={onCancel}>
                        <X className="h-5 w-5" />
                    </Button>
                </div>
            </div>

            {/* Comments List */}
            <div
                ref={scrollRef}
                className="flex-1 overflow-y-auto p-4 bg-white min-h-[200px]"
            >
                {readOnly ? (
                    <>
                        {/* Original Comment (The "Root") */}
                        {initialContent && renderCommentBubble(
                            initialContent,
                            initialContentAuthor || "Ukjent",
                            undefined, // We might not have the date for the root passed in easily, or can add it to props
                            false
                        )}

                        {/* Replies */}
                        {comments.map((comment, i) => {
                            const authorName = comment.author
                                ? `${comment.author.firstName} ${comment.author.lastName}`
                                : "Ukjent";
                            const isMe = currentUserEmail && comment.author?.email === currentUserEmail;

                            return (
                                <div key={comment.id || i}>
                                    {renderCommentBubble(comment.content, authorName, comment.createdAt, isMe)}
                                </div>
                            );
                        })}

                        {comments.length === 0 && !initialContent && (
                            <div className="text-center text-gray-400 py-8 text-sm">
                                Ingen kommentarer enda.
                            </div>
                        )}
                    </>
                ) : (
                    <div className="text-center text-gray-500 py-8 text-sm">
                        Skriv din kommentar nedenfor...
                    </div>
                )}
            </div>

            {/* Input Area */}
            <div className="p-4 border-t border-gray-100 bg-gray-50">
                <div className="relative">
                    <Textarea
                        ref={textareaRef}
                        value={content}
                        onChange={handleInput}
                        placeholder={readOnly ? "Skriv et svar..." : "Skriv en kommentar..."}
                        className="min-h-[80px] max-h-[150px] pr-12 resize-none bg-white text-gray-900 border-gray-200 focus:border-blue-500 focus:ring-1 focus:ring-blue-500 rounded-lg shadow-sm"
                        autoFocus={!readOnly}
                        onKeyDown={(e) => {
                            if (e.key === 'Enter' && !e.shiftKey && !showMentions) {
                                e.preventDefault();
                                if (content.trim()) {
                                    onSave(content, Array.from(mentionedUserIds));
                                    setContent(""); // Clear immediately for better UX
                                }
                            }
                        }}
                    />
                    <Button
                        size="icon"
                        className={`absolute bottom-3 right-3 h-8 w-8 rounded-full transition-all ${content.trim()
                                ? 'bg-blue-600 hover:bg-blue-700 text-white shadow-md'
                                : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                            }`}
                        onClick={() => {
                            if (content.trim()) {
                                onSave(content, Array.from(mentionedUserIds));
                                setContent("");
                            }
                        }}
                        disabled={!content.trim()}
                    >
                        <Send className="h-4 w-4" />
                    </Button>

                    {showMentions && filteredMembers.length > 0 && (
                        <div className="absolute bottom-full left-0 w-full bg-white border border-gray-200 rounded-lg shadow-xl max-h-48 overflow-y-auto mb-2 z-50">
                            {filteredMembers.map(member => (
                                <div
                                    key={member.id}
                                    className="p-3 hover:bg-blue-50 cursor-pointer text-sm flex items-center gap-3 border-b border-gray-50 last:border-0"
                                    onClick={() => handleSelectMember(member)}
                                >
                                    <Avatar name={member.name} size={24} />
                                    <div className="flex flex-col">
                                        <span className="font-medium text-gray-900">{member.name}</span>
                                        <span className="text-xs text-gray-500">{member.email}</span>
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                <div className="flex justify-between items-center mt-2 px-1">
                    <span className="text-[11px] text-gray-400">
                        Trykk Enter for å sende
                    </span>
                </div>
            </div>
        </div>
    );
}
