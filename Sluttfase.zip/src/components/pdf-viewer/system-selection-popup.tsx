"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { X } from "lucide-react";

interface SystemSelectionPopupProps {
    systemTags: string[];
    onSelect: (systemCode: string) => void;
    onCancel: () => void;
    position: { x: number; y: number };
}

export default function SystemSelectionPopup({ systemTags, onSelect, onCancel, position }: SystemSelectionPopupProps) {
    const [search, setSearch] = useState("");

    const filteredTags = systemTags.filter(tag => tag.toLowerCase().includes(search.toLowerCase()));

    return (
        <div
            className="fixed z-50 bg-card border border-border rounded-lg shadow-xl p-4 w-72 flex flex-col gap-3"
            style={{ left: position.x, top: position.y }}
        >
            <div className="flex justify-between items-center">
                <h3 className="font-semibold text-foreground">Velg system</h3>
                <Button variant="ghost" size="icon" className="h-6 w-6" onClick={onCancel}>
                    <X className="h-4 w-4" />
                </Button>
            </div>

            <input
                type="text"
                placeholder="Søk..."
                className="w-full border border-input bg-background p-2 rounded-md text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                autoFocus
            />

            <div className="max-h-60 overflow-y-auto border border-border rounded-md bg-background">
                {filteredTags.map(tag => (
                    <button
                        key={tag}
                        className="w-full text-left px-3 py-2 hover:bg-accent hover:text-accent-foreground block text-sm text-foreground transition-colors"
                        onClick={() => onSelect(tag)}
                    >
                        {tag}
                    </button>
                ))}
                {filteredTags.length === 0 && (
                    <p className="p-3 text-muted-foreground text-sm text-center">Ingen treff</p>
                )}
            </div>

            <div className="flex justify-end gap-2 pt-2">
                <Button variant="outline" size="sm" onClick={onCancel}>
                    Lukk
                </Button>
            </div>
        </div>
    );
}
