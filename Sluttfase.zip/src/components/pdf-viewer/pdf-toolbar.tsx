"use client";

import { Button } from "@/components/ui/button";
import { MousePointer2, MessageSquare, Hexagon, ZoomIn, ZoomOut, Trash2, Hand } from "lucide-react";
import { cn } from "@/lib/utils";

export type Tool = "cursor" | "hand" | "polygon" | "comment";

interface PDFToolbarProps {
    scale: number;
    setScale: (scale: number) => void;
    activeTool: Tool;
    setActiveTool: (tool: Tool) => void;
    onDeleteAnnotation: () => void;
    canDelete: boolean;
}

export default function PDFToolbar({
    scale,
    setScale,
    activeTool,
    setActiveTool,
    onDeleteAnnotation,
    canDelete,
}: PDFToolbarProps) {
    return (
        <div className="flex items-center gap-2 p-2 border-b border-border/60 bg-card/80 backdrop-blur-xl sticky top-0 z-10 shadow-sm">
            <div className="flex items-center gap-1 border-r border-border pr-2">
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setScale(Math.max(0.5, scale - 0.1))}
                    title="Zoom Out"
                    className="text-muted-foreground hover:text-foreground"
                >
                    <ZoomOut className="h-4 w-4" />
                </Button>
                <span className="text-sm w-12 text-center text-foreground font-medium">{Math.round(scale * 100)}%</span>
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setScale(Math.min(3, scale + 0.1))}
                    title="Zoom In"
                    className="text-muted-foreground hover:text-foreground"
                >
                    <ZoomIn className="h-4 w-4" />
                </Button>
            </div>

            <div className="flex items-center gap-1 border-r border-border pr-2">
                <Button
                    variant={activeTool === "cursor" ? "secondary" : "ghost"}
                    size="icon"
                    onClick={() => setActiveTool("cursor")}
                    title="Select / Edit"
                    className={cn(activeTool === "cursor" && "bg-primary text-primary-foreground hover:bg-primary/90")}
                >
                    <MousePointer2 className="h-4 w-4" />
                </Button>
                <Button
                    variant={activeTool === "hand" ? "secondary" : "ghost"}
                    size="icon"
                    onClick={() => setActiveTool("hand")}
                    title="Pan / Move"
                    className={cn(activeTool === "hand" && "bg-primary text-primary-foreground hover:bg-primary/90")}
                >
                    <Hand className="h-4 w-4" />
                </Button>
                <Button
                    variant={activeTool === "polygon" ? "secondary" : "ghost"}
                    size="icon"
                    onClick={() => setActiveTool("polygon")}
                    title="System Boxing (Polygon)"
                    className={cn(activeTool === "polygon" && "bg-primary text-primary-foreground hover:bg-primary/90")}
                >
                    <Hexagon className="h-4 w-4" />
                </Button>
                <Button
                    variant={activeTool === "comment" ? "secondary" : "ghost"}
                    size="icon"
                    onClick={() => setActiveTool("comment")}
                    title="Comment"
                    className={cn(activeTool === "comment" && "bg-primary text-primary-foreground hover:bg-primary/90")}
                >
                    <MessageSquare className="h-4 w-4" />
                </Button>
            </div>

            <div className="flex items-center gap-1 ml-auto">
                <Button
                    variant="ghost"
                    size="icon"
                    onClick={onDeleteAnnotation}
                    disabled={!canDelete}
                    className="text-destructive hover:text-destructive hover:bg-destructive/10"
                    title="Delete Selected"
                >
                    <Trash2 className="h-4 w-4" />
                </Button>
            </div>
        </div>
    );
}
