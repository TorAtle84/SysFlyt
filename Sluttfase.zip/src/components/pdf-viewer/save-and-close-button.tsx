"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Save } from "lucide-react";
import { useRouter } from "next/navigation";
import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";

interface SaveAndCloseButtonProps {
    projectId: string;
    documentId: string;
    systemTags: string[];
}

export default function SaveAndCloseButton({ projectId, documentId, systemTags }: SaveAndCloseButtonProps) {
    const router = useRouter();
    const [isOpen, setIsOpen] = useState(false);
    const [loading, setLoading] = useState(false);
    const [unmappedTags, setUnmappedTags] = useState<string[]>([]);

    const handleSaveAndClose = async () => {
        setLoading(true);
        try {
            // Fetch current annotations to check coverage
            const res = await fetch(`/api/projects/${projectId}/documents/${documentId}/annotations`);
            if (!res.ok) throw new Error("Failed to fetch annotations");

            const annotations = await res.json();
            const mappedSystems = new Set(
                annotations
                    .filter((a: any) => a.type === "SYSTEM" && a.systemCode)
                    .map((a: any) => a.systemCode)
            );

            const missing = systemTags.filter(tag => !mappedSystems.has(tag));

            if (missing.length > 0) {
                setUnmappedTags(missing);
                setIsOpen(true);
                setLoading(false);
            } else {
                // All mapped, just exit
                router.push(`/projects/${projectId}`);
            }
        } catch (error) {
            console.error("Error checking completion:", error);
            // Fallback to exit if check fails
            router.push(`/projects/${projectId}`);
        }
    };

    const handleRemoveUnmapped = async () => {
        setLoading(true);
        try {
            // Calculate new tags (keep only mapped ones)
            const newTags = systemTags.filter(tag => !unmappedTags.includes(tag));

            const res = await fetch(`/api/projects/${projectId}/documents/${documentId}`, {
                method: "PATCH",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ systemTags: newTags }),
            });

            if (!res.ok) throw new Error("Failed to update tags");

            router.push(`/projects/${projectId}`);
        } catch (error) {
            console.error("Error updating tags:", error);
            setLoading(false);
        }
    };

    return (
        <>
            <Button variant="primary" className="gap-2" onClick={handleSaveAndClose} disabled={loading}>
                <Save className="h-4 w-4" />
                Lagre og Lukk
            </Button>

            <Dialog open={isOpen} onOpenChange={setIsOpen}>
                <DialogContent>
                    <DialogHeader>
                        <DialogTitle>Ufullstendig kartlegging</DialogTitle>
                        <DialogDescription>
                            Følgende systemer er registrert på dokumentet men ikke markert i tegningen:
                            <br />
                            <span className="font-medium mt-2 block">
                                {unmappedTags.join(", ")}
                            </span>
                            <br />
                            Vil du fjerne disse systemene fra dokumentet før du avslutter?
                        </DialogDescription>
                    </DialogHeader>
                    <DialogFooter className="flex-col sm:flex-row gap-2">
                        <Button variant="outline" onClick={() => setIsOpen(false)}>
                            Nei, fortsett å jobbe
                        </Button>
                        <Button variant="secondary" onClick={() => router.push(`/projects/${projectId}`)}>
                            Senere (Behold systemer)
                        </Button>
                        <Button variant="primary" onClick={handleRemoveUnmapped}>
                            Ja, fjern umarkerte
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </>
    );
}
