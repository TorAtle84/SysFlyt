"use client";

import { MessageSquare } from "lucide-react";

interface Point {
    x: number;
    y: number;
}

interface AnnotationLayerProps {
    width: number;
    height: number;
    scale: number;
    activeTool: "cursor" | "hand" | "polygon" | "comment";
    annotations: any[];
    selectedAnnotationId: string | null;
    onAnnotationSelect: (id: string | null) => void;
    onAnnotationCreate: (data: any) => void;
}

export default function AnnotationLayer({
    width,
    height,
    scale,
    activeTool,
    annotations,
    selectedAnnotationId,
    onAnnotationSelect,
    onAnnotationCreate,
}: AnnotationLayerProps) {
    // Local state for drawing
    const [points, setPoints] = React.useState<Point[]>([]);
    const [cursorPos, setCursorPos] = React.useState<Point | null>(null);

    // Handle clicks for creating annotations
    const handleSvgClick = (e: React.MouseEvent) => {
        if (activeTool === "cursor" || activeTool === "hand") {
            if (e.target === e.currentTarget) {
                onAnnotationSelect(null);
            }
            return;
        }

        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Convert to percentage relative to original PDF size
        // We need to account for the current scale when calculating percentage
        const percentX = (x / (width * scale)) * 100;
        const percentY = (y / (height * scale)) * 100;

        if (activeTool === "polygon") {
            const newPoint = { x: percentX, y: percentY };
            setPoints([...points, newPoint]);

            // If we have at least 3 points and clicked near the start, close the polygon
            if (points.length >= 3) {
                const start = points[0];
                const dist = Math.sqrt(Math.pow(percentX - start.x, 2) + Math.pow(percentY - start.y, 2));
                if (dist < 2) { // Tolerance for closing
                    onAnnotationCreate({
                        type: "SYSTEM",
                        points: [...points, start] // Close loop
                    });
                    setPoints([]);
                    return;
                }
            }
        } else if (activeTool === "comment") {
            onAnnotationCreate({
                type: "COMMENT",
                x: percentX,
                y: percentY,
                content: "",
                mentions: [],
                clientX: e.clientX,
                clientY: e.clientY
            });
        }
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (activeTool !== "polygon") return;

        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        const percentX = (x / (width * scale)) * 100;
        const percentY = (y / (height * scale)) * 100;

        setCursorPos({ x: percentX, y: percentY });
    };

    // Double click to finish polygon (alternative to clicking start)
    const handleDoubleClick = () => {
        if (activeTool === "polygon" && points.length >= 3) {
            onAnnotationCreate({
                type: "SYSTEM",
                points: points
            });
            setPoints([]);
        }
    };

    return (
        <div className="absolute inset-0 pointer-events-none">
            <svg
                width={width * scale}
                height={height * scale}
                className={`absolute top-0 left-0 ${activeTool !== 'cursor' && activeTool !== 'hand' ? 'pointer-events-auto cursor-crosshair' : ''}`}
                onClick={handleSvgClick}
                onMouseMove={handleMouseMove}
                onDoubleClick={handleDoubleClick}
            >
                {/* Existing Annotations */}
                {annotations.map((ann, i) => {
                    const isSelected = selectedAnnotationId === ann.id;
                    const strokeColor = isSelected ? "#2563eb" : ann.color; // Blue if selected
                    const strokeWidth = isSelected ? 3 * scale : 2 * scale;
                    const isHandTool = activeTool === 'hand';

                    if (ann.type === "SYSTEM" && ann.points) {
                        let points: Point[] = [];
                        if (Array.isArray(ann.points)) {
                            points = ann.points;
                        } else if (typeof ann.points === 'string') {
                            try {
                                points = JSON.parse(ann.points);
                            } catch (e) {
                                console.error("Failed to parse points:", e);
                            }
                        }

                        if (points.length > 0) {
                            const pts = points.map(p => {
                                const px = (p.x / 100) * width * scale;
                                const py = (p.y / 100) * height * scale;
                                if (isNaN(px) || isNaN(py)) {
                                    console.error(`[AnnotationLayer] Invalid point in ${ann.id}:`, p, px, py);
                                    return "0,0";
                                }
                                return `${px},${py}`;
                            }).join(" ");

                            return (
                                <polygon
                                    key={ann.id || i}
                                    points={pts}
                                    fill={ann.color}
                                    fillOpacity={0.2}
                                    stroke={strokeColor}
                                    strokeWidth={strokeWidth}
                                    className={isHandTool ? "" : "pointer-events-auto cursor-pointer hover:opacity-80"}
                                    onClick={(e) => {
                                        if (isHandTool) return;
                                        e.stopPropagation();
                                        if (activeTool === "cursor") onAnnotationSelect?.(ann.id);
                                    }}
                                />
                            );
                        }
                    } else if (ann.type === "COMMENT") {
                        // Render comment icon overlay (handled below in HTML layer for better interactivity)
                        return null;
                    }
                    return null;
                })}

                {/* Current Drawing Polygon */}
                {points.length > 0 && (
                    <>
                        <polyline
                            points={points.map(p => `${(p.x / 100) * width * scale},${(p.y / 100) * height * scale}`).join(" ")}
                            fill="none"
                            stroke="#3b82f6"
                            strokeWidth={2 * scale}
                            strokeDasharray="4"
                        />
                        {cursorPos && (
                            <line
                                x1={(points[points.length - 1].x / 100) * width * scale}
                                y1={(points[points.length - 1].y / 100) * height * scale}
                                x2={(cursorPos.x / 100) * width * scale}
                                y2={(cursorPos.y / 100) * height * scale}
                                stroke="#3b82f6"
                                strokeWidth={1 * scale}
                                strokeDasharray="4"
                            />
                        )}
                    </>
                )}
            </svg>

            {/* HTML Overlay for Comments and Handles */}
            {annotations.map((ann, i) => {
                if (ann.type === "COMMENT") {
                    const isSelected = selectedAnnotationId === ann.id;
                    const isHandTool = activeTool === 'hand';
                    // Check if this is a pending comment (no ID yet)
                    const isPending = !ann.id;

                    if (isPending) {
                        return (
                            <div
                                key={i}
                                className="absolute transform -translate-x-1/2 -translate-y-1/2 pointer-events-none z-50"
                                style={{
                                    left: `${ann.x}%`,
                                    top: `${ann.y}%`,
                                }}
                            >
                                <div className="h-6 w-6 bg-orange-500 rounded-full border-2 border-white shadow-lg animate-pulse" />
                            </div>
                        );
                    }

                    // Render saved comments as dots (same as pending)
                    return (
                        <div
                            key={ann.id || i}
                            className={`absolute transform -translate-x-1/2 -translate-y-1/2 transition-transform ${isHandTool ? '' : 'cursor-pointer'} ${isSelected ? 'scale-125' : 'hover:scale-110'} z-50`}
                            style={{
                                left: `${ann.x}%`,
                                top: `${ann.y}%`,
                                pointerEvents: isHandTool ? 'none' : 'auto'
                            }}
                            title={ann.content || "Kommentar"}
                            onClick={(e) => {
                                if (isHandTool) return;
                                e.stopPropagation();
                                if (activeTool === "cursor") onAnnotationSelect?.(ann.id);
                            }}
                        >
                            <div className={`h-6 w-6 rounded-full border-2 border-white shadow-lg ${isSelected ? 'bg-orange-600 scale-110 ring-2 ring-orange-400 animate-pulse' : 'bg-orange-500'}`} />
                        </div>
                    );
                }
                return null;
            })}
        </div>
    );
}

import React from "react";
