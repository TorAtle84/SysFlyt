"use client";

import { useState, useEffect, useRef } from "react";
import { Document, Page, pdfjs } from "react-pdf";
import "react-pdf/dist/Page/AnnotationLayer.css";
import "react-pdf/dist/Page/TextLayer.css";
import AnnotationLayer from "./annotation-layer";
import SystemSelectionPopup from "./system-selection-popup";
import CommentPopup from "./comment-popup";
import { useParams, useSearchParams } from "next/navigation";
import PDFToolbar, { Tool } from "./pdf-toolbar";
import { stringToColor } from "@/lib/utils";

// Set worker source
pdfjs.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.mjs";

interface PDFViewerProps {
    url: string;
    systemTags?: string[];
    documentId?: string;
    initialAnnotations?: any[];
    projectMembers?: { id: string; name: string; email: string }[];
    currentUserEmail?: string;
}

export default function PDFViewer({ url, systemTags = [], documentId, initialAnnotations = [], projectMembers = [], currentUserEmail }: PDFViewerProps) {
    const params = useParams();
    const searchParams = useSearchParams();
    const projectId = params.projectId as string;
    const initialAnnotationId = searchParams.get("annotationId");

    const [numPages, setNumPages] = useState<number>(0);
    const [pageNumber, setPageNumber] = useState<number>(1);
    const [pageDimensions, setPageDimensions] = useState<{ width: number; height: number } | null>(null);
    const [scale, setScale] = useState<number>(1.0);
    const [activeTool, setActiveTool] = useState<Tool>("cursor");

    const [popupOpen, setPopupOpen] = useState(false);
    const [commentPopupOpen, setCommentPopupOpen] = useState(false);
    const [popupPosition, setPopupPosition] = useState({ x: 0, y: 0 });

    // State for creating annotations
    const [currentBox, setCurrentBox] = useState<{ x: number; y: number; width: number; height: number } | null>(null);
    const [currentPoints, setCurrentPoints] = useState<{ x: number; y: number }[]>([]);
    const [pendingComment, setPendingComment] = useState<any>(null);

    // State for viewing comments
    const [viewComment, setViewComment] = useState<any>(null);

    const [annotations, setAnnotations] = useState<any[]>(initialAnnotations);
    const [selectedAnnotationId, setSelectedAnnotationId] = useState<string | null>(null);

    // Responsive width & Pan
    const [containerRef, setContainerRef] = useState<HTMLDivElement | null>(null);
    const [containerWidth, setContainerWidth] = useState<number>(0);
    const [isPanning, setIsPanning] = useState(false);
    const [lastMousePosition, setLastMousePosition] = useState({ x: 0, y: 0 });

    useEffect(() => {
        if (!containerRef) return;
        const observer = new ResizeObserver((entries) => {
            const entry = entries[0];
            if (entry) {
                setContainerWidth(entry.contentRect.width);
            }
        });
        observer.observe(containerRef);
        return () => observer.disconnect();
    }, [containerRef]);

    // Handle deep linking
    useEffect(() => {
        if (initialAnnotationId && annotations.length > 0 && pageDimensions && containerWidth) {
            const annotation = annotations.find(a => a.id === initialAnnotationId);
            if (annotation && annotation.type === "COMMENT") {
                setSelectedAnnotationId(initialAnnotationId);
                setViewComment(annotation);
            }
        }
    }, [initialAnnotationId, annotations, pageDimensions, containerWidth]);

    // Pan Handlers
    const handleMouseDown = (e: React.MouseEvent) => {
        if (activeTool === "hand" || (activeTool === "cursor" && e.target === containerRef)) {
            setIsPanning(true);
            setLastMousePosition({ x: e.clientX, y: e.clientY });
        }
    };

    const handleMouseMove = (e: React.MouseEvent) => {
        if (!isPanning || !containerRef) return;

        const dx = e.clientX - lastMousePosition.x;
        const dy = e.clientY - lastMousePosition.y;

        containerRef.scrollLeft -= dx;
        containerRef.scrollTop -= dy;

        setLastMousePosition({ x: e.clientX, y: e.clientY });
    };

    const handleMouseUp = () => {
        setIsPanning(false);
    };

    function onDocumentLoadSuccess({ numPages }: { numPages: number }) {
        setNumPages(numPages);
    }

    function onPageLoadSuccess(page: any) {
        console.log(`[PDFViewer] Page Loaded: ${page.width}x${page.height}, Original: ${page.originalWidth}x${page.originalHeight}`);
        setPageDimensions({ width: page.width, height: page.height });
    }

    // Legacy box handler (if needed)
    function handleDrawComplete(box: { x: number; y: number; width: number; height: number }) {
        setPopupPosition({ x: window.innerWidth / 2 - 128, y: window.innerHeight / 2 - 100 });
        setCurrentBox(box);
        setPopupOpen(true);
    }

    // Zoom Handler
    useEffect(() => {
        const container = containerRef;
        if (!container) return;

        const onWheel = (e: WheelEvent) => {
            if (e.ctrlKey) {
                e.preventDefault();
                const delta = e.deltaY * -0.01;
                setScale(prev => Math.min(Math.max(0.5, prev + delta), 5));
            }
        };

        container.addEventListener('wheel', onWheel, { passive: false });
        return () => container.removeEventListener('wheel', onWheel);
    }, [containerRef]);

    async function handleSaveAnnotation(data: any) {
        console.log("💾 Saving annotation:", data);
        if (!documentId) return;

        // Generate color for system annotations
        const color = data.type === "SYSTEM" && data.systemCode
            ? stringToColor(data.systemCode)
            : (data.color || "#ff0000");

        try {
            const payload = {
                pageNumber,
                color: color,
                systemCode: data.systemCode,
                type: data.type || "SYSTEM",
                points: data.points,
                content: data.content,
                mentions: data.mentions || [],
                // Use provided coordinates or fall back to legacy box
                x: data.x ?? currentBox?.x ?? 0,
                y: data.y ?? currentBox?.y ?? 0,
                width: currentBox?.width || 0,
                height: currentBox?.height || 0,
                // If we are viewing a comment, this is a reply
                systemAnnotationId: viewComment ? viewComment.id : undefined
            };
            console.log("📤 Payload:", payload);

            const res = await fetch(`/api/projects/${projectId}/documents/${documentId}/annotations`, {
                method: 'POST',
                body: JSON.stringify(payload)
            });
            if (res.ok) {
                const newAnnotation = await res.json();
                console.log("✅ Annotation saved:", newAnnotation);

                if (viewComment && viewComment.id === newAnnotation.systemAnnotationId) {
                    // It's a reply to the currently viewed comment
                    // We need to update the comments list in viewComment
                    const updatedViewComment = {
                        ...viewComment,
                        comments: [...(viewComment.comments || []), newAnnotation]
                    };
                    setViewComment(updatedViewComment);

                    // Update the annotation in the main list as well
                    setAnnotations(prev => prev.map(a =>
                        a.id === viewComment.id ? { ...a, comments: [...(a.comments || []), newAnnotation] } : a
                    ));

                    // Close the reply input (pending comment) but keep the view open
                    setCommentPopupOpen(false);
                    setPendingComment(null);
                } else {
                    // It's a new top-level annotation
                    setAnnotations(prev => [...prev, newAnnotation]);

                    // Switch to view mode immediately
                    setPopupOpen(false);
                    setCommentPopupOpen(false);
                    setCurrentBox(null);
                    setCurrentPoints([]);
                    setPendingComment(null);

                    // Set as selected and view it ONLY if it's a comment
                    setSelectedAnnotationId(newAnnotation.id);
                    if (newAnnotation.type === "COMMENT") {
                        setViewComment(newAnnotation);
                    } else {
                        setViewComment(null);
                    }
                }
            } else {
                const errorText = await res.text();
                console.error("Failed to save annotation. Status:", res.status, "Response:", errorText);
                alert(`Kunne ikke lagre kommentar. Feil: ${res.status} - ${errorText}`);
            }
        } catch (e) {
            console.error("Exception saving annotation:", e);
            alert("En feil oppstod under lagring: " + (e as Error).message);
        }
    }

    async function handleDeleteAnnotation() {
        if (!selectedAnnotationId) return;
        try {
            const res = await fetch(`/api/annotations/${selectedAnnotationId}`, {
                method: 'DELETE'
            });
            if (res.ok) {
                setAnnotations(annotations.filter(a => a.id !== selectedAnnotationId));
                setSelectedAnnotationId(null);
                setViewComment(null);
            }
        } catch (e) {
            console.error(e);
        }
    }

    // Combine saved annotations with pending comment (if any)
    // Ensure no duplicates by filtering out pendingComment.id from annotations if it exists (e.g. during edit)
    const displayedAnnotations = annotations.filter(a => !pendingComment || a.id !== pendingComment.id);
    const annotationsToRender = pendingComment ? [...displayedAnnotations, pendingComment] : displayedAnnotations;

    // Calculate rendered dimensions (base width before scale)
    const baseWidth = containerWidth ? Math.min(containerWidth - 64, 1200) : 0;
    const baseHeight = (pageDimensions && baseWidth)
        ? baseWidth * (pageDimensions.height / pageDimensions.width)
        : 0;

    return (
        <div className="flex flex-col h-full relative">
            <PDFToolbar
                scale={scale}
                setScale={setScale}
                activeTool={activeTool}
                setActiveTool={setActiveTool}
                onDeleteAnnotation={handleDeleteAnnotation}
                canDelete={!!selectedAnnotationId}
            />

            <div
                className={`flex-1 overflow-auto bg-gray-100 relative ${activeTool === 'hand' ? (isPanning ? 'cursor-grabbing' : 'cursor-grab') : ''}`}
                ref={setContainerRef}
                onMouseDown={handleMouseDown}
                onMouseMove={handleMouseMove}
                onMouseUp={handleMouseUp}
                onMouseLeave={handleMouseUp}
            >
                <div className="min-h-full min-w-full flex p-8">
                    <div className="relative shadow-lg m-auto">
                        {popupOpen && (
                            <SystemSelectionPopup
                                systemTags={systemTags}
                                onSelect={(code) => {
                                    console.log("🎯 System selected:", code, "Points:", currentPoints);
                                    handleSaveAnnotation({ type: "SYSTEM", systemCode: code, points: currentPoints });
                                }}
                                onCancel={() => setPopupOpen(false)}
                                position={popupPosition}
                            />
                        )}
                        {commentPopupOpen && (
                            <CommentPopup
                                onSave={(content, mentions) => handleSaveAnnotation({ ...pendingComment, content, mentions })}
                                onCancel={() => {
                                    setCommentPopupOpen(false);
                                    setPendingComment(null);
                                }}
                                position={popupPosition}
                                projectMembers={projectMembers}
                                currentUserEmail={currentUserEmail}
                            />
                        )}

                        {viewComment && (
                            <CommentPopup
                                position={{
                                    x: Math.max(0, (viewComment.x / 100) * (baseWidth * scale) - 160),
                                    y: Math.max(0, (viewComment.y / 100) * (baseHeight * scale) - 100)
                                }}
                                onSave={(content, mentions) => handleSaveAnnotation({
                                    type: "COMMENT",
                                    content,
                                    mentions,
                                    // Coordinates don't matter for reply, but we need to pass something
                                    x: viewComment.x,
                                    y: viewComment.y
                                })}
                                onCancel={() => setViewComment(null)}
                                onDelete={() => handleDeleteAnnotation()}
                                projectMembers={projectMembers}
                                initialContent={viewComment.content}
                                initialContentAuthor={viewComment.author ? `${viewComment.author.firstName} ${viewComment.author.lastName}` : (viewComment.createdBy ? `${viewComment.createdBy.firstName} ${viewComment.createdBy.lastName}` : "Ukjent bruker")}
                                comments={viewComment.comments} // Pass threads
                                readOnly={true}
                                currentUserEmail={currentUserEmail}
                            />
                        )}

                        <Document
                            file={url}
                            onLoadSuccess={onDocumentLoadSuccess}
                            onLoadError={(error) => console.error("Document load error:", error)}
                            className="border relative"
                        >
                            <Page
                                pageNumber={pageNumber}
                                width={baseWidth ? baseWidth * scale : undefined}
                                onLoadSuccess={onPageLoadSuccess}
                                onLoadError={(error) => console.error("Page load error:", error)}
                                renderAnnotationLayer={false}
                                renderTextLayer={false}
                                className="relative"
                            >
                                {pageDimensions && baseWidth > 0 && (
                                    <AnnotationLayer
                                        width={baseWidth}
                                        height={baseHeight}
                                        scale={scale}
                                        activeTool={activeTool}
                                        annotations={annotationsToRender}
                                        selectedAnnotationId={selectedAnnotationId}
                                        onAnnotationSelect={(id) => {
                                            setSelectedAnnotationId(id);
                                            const annotation = annotations.find(a => a.id === id);
                                            if (annotation && annotation.type === "COMMENT") {
                                                setViewComment(annotation);
                                            }
                                        }}
                                        onAnnotationCreate={(data) => {
                                            if (data.type === "SYSTEM") {
                                                setCurrentPoints(data.points);
                                                setPopupPosition({ x: window.innerWidth / 2 - 128, y: window.innerHeight / 2 - 100 });
                                                setPopupOpen(true);
                                            } else if (data.type === "COMMENT") {
                                                setPendingComment(data);

                                                // Position popup relative to the container
                                                if (containerRef && data.clientX && data.clientY) {
                                                    const rect = containerRef.getBoundingClientRect();
                                                    const x = data.clientX - rect.left + containerRef.scrollLeft;
                                                    const y = data.clientY - rect.top + containerRef.scrollTop;
                                                    // Offset slightly to not cover the dot
                                                    setPopupPosition({ x: x + 20, y: y });
                                                } else {
                                                    // Fallback
                                                    setPopupPosition({ x: window.innerWidth / 2 - 128, y: window.innerHeight / 2 - 100 });
                                                }

                                                setCommentPopupOpen(true);
                                            }
                                        }}
                                    />
                                )}
                            </Page>
                        </Document>
                    </div>
                </div>
            </div>
        </div>
    );
}
