"use client";

import { useEffect, useRef, useState } from "react";
import * as THREE from "three";
// @ts-ignore
import CLOUDS from "vanta/dist/vanta.clouds.min";
import { useTheme } from "./theme-provider";

export function VantaBackground() {
    const vantaRef = useRef<HTMLDivElement>(null);
    const [vantaEffect, setVantaEffect] = useState<any>(null);
    const { theme } = useTheme();

    useEffect(() => {
        // Check if mobile (simple width check) to save battery/performance
        const isMobile = window.innerWidth < 768;
        if (isMobile) {
            console.log("📱 Mobile detected, skipping Vanta effect for performance");
            return;
        }

        console.log("☁️ VantaBackground mounting...", { vantaRef: vantaRef.current, theme });
        if (!vantaEffect && vantaRef.current) {
            try {
                const effect = CLOUDS({
                    el: vantaRef.current,
                    THREE: THREE,
                    mouseControls: true,
                    touchControls: true,
                    gyroControls: false,
                    minHeight: 200.0,
                    minWidth: 200.0,
                    skyColor: theme === "dark" ? 0x0f172a : 0x1E90FF, // Slate-900 vs Dodger Blue (Very clear/vibrant)
                    cloudColor: theme === "dark" ? 0x94a3b8 : 0xffffff, // Slate-400 vs White
                    cloudShadowColor: theme === "dark" ? 0x1e293b : 0x1e3a8a, // Slate-800 vs Blue-900
                    sunColor: theme === "dark" ? 0x000000 : 0xff9900,
                    sunGlareColor: theme === "dark" ? 0x000000 : 0xff6600,
                    sunlightColor: theme === "dark" ? 0x000000 : 0xff9900,
                    speed: 0.8,
                });
                setVantaEffect(effect);
                console.log("☁️ Vanta effect initialized");
            } catch (error) {
                console.error("☁️ Failed to initialize Vanta effect:", error);
                // Fallback is automatic since this div is transparent and body has background
            }
        }

        return () => {
            if (vantaEffect) vantaEffect.destroy();
        };
    }, [vantaEffect]);

    // Update options when theme changes
    useEffect(() => {
        if (vantaEffect) {
            console.log("☁️ Updating Vanta theme:", theme);
            vantaEffect.setOptions({
                skyColor: theme === "dark" ? 0x0f172a : 0x1E90FF, // Slate-900 vs Dodger Blue (Very clear/vibrant)
                cloudColor: theme === "dark" ? 0x94a3b8 : 0xffffff, // Slate-400 vs White
                cloudShadowColor: theme === "dark" ? 0x1e293b : 0x1e3a8a, // Slate-800 vs Blue-900
                sunColor: theme === "dark" ? 0x000000 : 0xff9900,
                sunGlareColor: theme === "dark" ? 0x000000 : 0xff6600,
                sunlightColor: theme === "dark" ? 0x000000 : 0xff9900,
            });
        }
    }, [theme, vantaEffect]);

    return (
        <div
            ref={vantaRef}
            className="fixed inset-0 -z-50 pointer-events-none" // Removed opacity-50
            style={{ width: "100%", height: "100%" }}
        />
    );
}
