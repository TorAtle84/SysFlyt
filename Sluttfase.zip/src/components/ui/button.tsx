import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "outline";
type Size = "sm" | "md" | "lg" | "icon";

const variantStyles: Record<Variant, string> = {
  primary:
    "bg-gradient-to-br from-slate-900 to-slate-800 text-white shadow-[0_10px_40px_rgba(0,0,0,0.15)] hover:scale-[1.01]",
  secondary: "bg-accent text-accent-foreground border border-border hover:-translate-y-[1px]",
  ghost: "bg-transparent text-foreground hover:bg-muted",
  danger: "bg-danger text-white hover:brightness-95",
  outline: "border border-border text-foreground hover:bg-muted",
};

const sizeStyles: Record<Size, string> = {
  sm: "text-sm px-3 py-2 rounded-lg",
  md: "text-sm px-4 py-2.5 rounded-xl",
  lg: "text-base px-5 py-3 rounded-xl",
  icon: "h-9 w-9 p-0 rounded-lg",
};

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant = "primary", size = "md", loading = false, children, disabled, ...props },
  ref
) {
  return (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center gap-2 transition-transform duration-150",
        variantStyles[variant],
        sizeStyles[size],
        disabled || loading ? "opacity-60 cursor-not-allowed" : "cursor-pointer",
        className
      )}
      disabled={disabled || loading}
      {...props}
    >
      {loading && <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/50 border-t-white" />}
      {children}
    </button>
  );
});
