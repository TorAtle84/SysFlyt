import { cn } from "@/lib/utils";

type Tone = "info" | "success" | "warning" | "danger" | "muted";

const toneStyles: Record<Tone, string> = {
  info: "bg-transparent text-success border border-success", // Active: Green border, transparent bg
  success: "bg-success/10 text-success border border-success/30",
  warning: "bg-transparent text-warning border border-warning", // Archived: Orange border, transparent bg
  danger: "bg-danger/10 text-danger border border-danger/30",
  muted: "bg-muted text-muted-foreground border border-border",
};

export function Badge({
  children,
  tone = "muted",
  className,
  title,
}: {
  children: React.ReactNode;
  tone?: Tone;
  className?: string;
  title?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2.5 py-1 text-xs font-semibold uppercase tracking-wide",
        toneStyles[tone],
        className
      )}
      title={title}
    >
      {children}
    </span>
  );
}
