import { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type DivProps = HTMLAttributes<HTMLDivElement>;

export function Card({ children, className, ...rest }: { children: React.ReactNode; className?: string } & DivProps) {
  return (
    <div
      className={cn("rounded-2xl border border-border bg-card/95 shadow-[0_20px_60px_rgba(0,0,0,0.06)]", className)}
      {...rest}
    >
      {children}
    </div>
  );
}

export function CardHeader({ children, className, ...rest }: { children: React.ReactNode; className?: string } & DivProps) {
  return (
    <div
      className={cn("flex items-center justify-between gap-3 border-b border-border/60 px-5 py-4", className)}
      {...rest}
    >
      {children}
    </div>
  );
}

export function CardContent({ children, className, ...rest }: { children: React.ReactNode; className?: string } & DivProps) {
  return (
    <div className={cn("px-5 py-4", className)} {...rest}>
      {children}
    </div>
  );
}

export function CardTitle({ children, className, ...rest }: { children: React.ReactNode; className?: string } & DivProps) {
  return (
    <div className={cn("text-base font-semibold text-foreground tracking-tight", className)} {...rest}>
      {children}
    </div>
  );
}
