import { forwardRef, InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type InputProps = InputHTMLAttributes<HTMLInputElement> & {
  label?: string;
  hint?: string;
};

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, label, hint, ...props },
  ref
) {
  return (
    <label className="flex w-full flex-col gap-1.5 text-sm text-muted-foreground">
      {label && <span className="font-medium text-foreground">{label}</span>}
      <input
        ref={ref}
        className={cn(
          "w-full rounded-xl border border-border bg-card px-3.5 py-2.5 text-foreground shadow-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20",
          className
        )}
        {...props}
      />
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </label>
  );
});
