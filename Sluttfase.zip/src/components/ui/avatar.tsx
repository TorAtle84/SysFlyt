import { cn } from "@/lib/utils";

export function Avatar({
  name,
  className,
  size = 38,
}: {
  name?: string | null;
  className?: string;
  size?: number;
}) {
  const initials = (name || "")
    .split(" ")
    .map((n) => n[0])
    .filter(Boolean)
    .join("")
    .slice(0, 2)
    .toUpperCase() || "SF";

  return (
    <div
      style={{ width: size, height: size }}
      className={cn(
        "flex items-center justify-center rounded-full bg-gradient-to-br from-slate-900 to-slate-700 text-white text-xs font-semibold shadow-lg",
        className
      )}
    >
      {initials}
    </div>
  );
}
